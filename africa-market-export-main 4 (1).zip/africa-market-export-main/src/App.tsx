import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/contexts/AuthContext";
import { HelmetProvider } from 'react-helmet-async';
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import { useEffect, useState } from "react";
import { initializeStorage, showOfflineToasts } from "@/lib/supabase";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import CooperativeRegistration from "./pages/CooperativeRegistration";
import Login from "./pages/Login";
import Admin from "./pages/Admin";

// Create queryClient inside the component to avoid initialization issues
function App() {
  const queryClient = new QueryClient();
  const [isInitialized, setIsInitialized] = useState(false);
  
  // Initialize storage once the application is mounted
  useEffect(() => {
    const initApp = async () => {
      try {
        // Initialize storage before displaying toasts
        await initializeStorage().catch(error => {
          console.warn('Storage bucket initialization not available:', error);
        });
        
        // Display offline mode toasts if applicable
        showOfflineToasts();
        
        // Mark the application as initialized
        setIsInitialized(true);
      } catch (error) {
        console.error("Error initializing application:", error);
        // Even in case of error, consider the app as initialized to display content
        setIsInitialized(true);
      }
    };
    
    initApp();
  }, []);
  
  // Display a loading indicator during initialization
  if (!isInitialized) {
    return (
      <div className="h-screen w-screen flex items-center justify-center">
        <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  return (
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Index />} />
                {/* Redirect routes to homepage with hash for section navigation */}
                <Route path="/products" element={<Navigate replace to="/#products" />} />
                <Route path="/why-us" element={<Navigate replace to="/#why-us" />} />
                <Route path="/how-it-works" element={<Navigate replace to="/#how-it-works" />} />
                <Route path="/cooperatives" element={<Navigate replace to="/#cooperatives" />} />
                <Route path="/contact" element={<Navigate replace to="/#contact" />} />
                
                {/* Keep original routes for direct access */}
                <Route path="/register-cooperative" element={<CooperativeRegistration />} />
                <Route path="/login" element={<Login />} />
                <Route path="/admin" element={
                  <ProtectedRoute>
                    <Admin />
                  </ProtectedRoute>
                } />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </HelmetProvider>
  );
}

export default App;
