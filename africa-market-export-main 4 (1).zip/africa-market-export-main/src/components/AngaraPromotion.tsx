
import { useRef, useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { ArrowRight, Smartphone } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function AngaraPromotion() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { t } = useTranslation();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section ref={sectionRef} className="bg-gradient-to-r from-forest-50 to-green-50 py-16 md:py-24">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8 items-center">
          <div className="lg:col-span-3 space-y-6">
            <h2 className={`text-3xl md:text-4xl font-bold ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
              {t('angaraApp.title')}
            </h2>
            <p className={`text-lg text-muted-foreground ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
              {t('angaraApp.description')}
            </p>
            <div className={`${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
              <a 
                href="https://play.google.com/store/apps/details?id=com.angara.superapp" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-2 bg-black text-white px-6 py-3 rounded-lg hover:bg-gray-800 transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3.9,21.5l0.8-1.3L4.9,19l0,0l5.5-9.6L4.8,2.5C4.3,3,4,3.7,4,4.5v15C4,20.3,4.1,21,3.9,21.5z M15.9,9.8l-2-1.1 l-5,8.5L15.9,9.8z M16.9,9.2L16.9,9.2l-2-1.1L13,9.7L14.9,11L16.9,9.2z M6.3,2.6L12,12.3l5.7-9.8c-0.2-0.1-0.4-0.2-0.6-0.2 c-0.2-0.1-0.6-0.1-0.7-0.1c-0.3,0-1,0-1.1,0h-7c-0.4,0-0.7,0-1.1,0.1C6.7,2.4,6.5,2.5,6.3,2.6z M16.9,14.9l-5.6,3.2l0.6,1.1 l0.8,1.3c0.7-0.3,1.3-0.8,1.7-1.4l2.9-5C17.3,14.4,17.1,14.7,16.9,14.9z"/>
                </svg>
                <div className="flex flex-col">
                  <span className="text-xs">{t('angaraApp.downloadButton')}</span>
                  <span className="text-sm font-semibold">Google Play</span>
                </div>
              </a>
            </div>
            <ul className={`space-y-3 pt-4 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.4s' }}>
              <li className="flex items-center space-x-2">
                <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-green-500"></div>
                </div>
                <span>{t('angaraApp.feature1')}</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-green-500"></div>
                </div>
                <span>{t('angaraApp.feature2')}</span>
              </li>
              <li className="flex items-center space-x-2">
                <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center">
                  <div className="h-2 w-2 rounded-full bg-green-500"></div>
                </div>
                <span>{t('angaraApp.feature3')}</span>
              </li>
            </ul>
          </div>
          <div className={`lg:col-span-2 ${isVisible ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.5s' }}>
            <div className="relative mx-auto max-w-xs">
              <div className="absolute inset-0 rounded-3xl bg-gradient-to-tr from-forest-200 to-green-200 transform rotate-6"></div>
              <div className="relative bg-white rounded-3xl overflow-hidden border-8 border-white shadow-xl aspect-[9/16]">
                <img 
                  src="/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png" 
                  alt="Angara Super App" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white smooth-shadow rounded-lg p-3">
                <Smartphone className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
