
import { useRef, useState, useEffect } from 'react';
import { Send, Phone, Mail, MapPin } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function ContactSection() {
  const { t } = useTranslation();
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
    type: 'buyer'
  });

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real implementation, you'd send this data to your backend
    console.log('Form submitted:', formData);
    alert(t('contact.formAlertSuccess'));
    setFormData({
      name: '',
      email: '',
      company: '',
      message: '',
      type: 'buyer'
    });
  };

  return (
    <section id="contact" ref={sectionRef} className="section-padding">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 bg-forest-800/20 text-forest-800 dark:text-forest-300 rounded-full text-sm font-medium mb-4">
            {t('contact.subtitle')}
          </span>
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
            {t('contact.sectionTitle')}
          </h2>
          <p className={`text-muted-foreground ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            {t('contact.description')}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className={`bg-white rounded-xl p-6 md:p-8 smooth-shadow ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
            <h3 className="text-2xl font-bold mb-6">{t('contact.formTitle')}</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('contact.formLabels.name')}
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-forest-700 focus:outline-none"
                    placeholder={t('contact.placeholders.name')}
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('contact.formLabels.email')}
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-forest-700 focus:outline-none"
                    placeholder={t('contact.placeholders.email')}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="company" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('contact.formLabels.company')}
                  </label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-forest-700 focus:outline-none"
                    placeholder={t('contact.placeholders.company')}
                  />
                </div>
                <div>
                  <label htmlFor="type" className="block text-sm font-medium text-gray-700 mb-1">
                    {t('contact.formLabels.type')}
                  </label>
                  <select
                    id="type"
                    name="type"
                    value={formData.type}
                    onChange={handleChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-forest-700 focus:outline-none"
                  >
                    <option value="buyer">{t('contact.typeOptions.buyer')}</option>
                    <option value="producer">{t('contact.typeOptions.producer')}</option>
                    <option value="other">{t('contact.typeOptions.other')}</option>
                  </select>
                </div>
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                  {t('contact.formLabels.message')}
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={4}
                  required
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-forest-700 focus:outline-none"
                  placeholder={t('contact.placeholders.message')}
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full bg-forest-700 hover:bg-forest-800 text-white px-6 py-3 rounded-md transition-all btn-hover flex items-center justify-center space-x-2"
              >
                <span>{t('contact.formLabels.sendMessage')}</span>
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className={`space-y-8 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.5s' }}>
            <div className="bg-forest-800 text-white rounded-xl p-6 md:p-8 smooth-shadow">
              <h3 className="text-2xl font-bold mb-6">{t('contact.offices.title')}</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{t('contact.offices.headquarters')}</h4>
                    <p className="text-forest-100">123 Business Avenue, Nairobi, Kenya</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{t('contact.offices.europeanOffice')}</h4>
                    <p className="text-forest-100">456 Trade Street, Brussels, Belgium</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium">{t('contact.offices.asianOffice')}</h4>
                    <p className="text-forest-100">789 Market Road, Singapore</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-xl p-6 md:p-8 smooth-shadow">
              <h3 className="text-2xl font-bold mb-6">{t('contact.contactInfo.title')}</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <div className="bg-forest-100 p-3 rounded-full">
                    <Phone className="h-5 w-5 text-forest-800" />
                  </div>
                  <div>
                    <h4 className="text-sm text-muted-foreground">{t('contact.contactInfo.callUs')}</h4>
                    <p className="font-medium">+254 123 456 789</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="bg-forest-100 p-3 rounded-full">
                    <Mail className="h-5 w-5 text-forest-800" />
                  </div>
                  <div>
                    <h4 className="text-sm text-muted-foreground">{t('contact.contactInfo.emailUs')}</h4>
                    <p className="font-medium">info@africamarket.com</p>
                  </div>
                </div>
              </div>
              <div className="mt-8 pt-6 border-t border-gray-200">
                <h4 className="font-medium mb-4">{t('contact.contactInfo.connect')}</h4>
                <div className="flex space-x-4">
                  {['facebook', 'twitter', 'linkedin', 'instagram'].map((social) => (
                    <a 
                      key={social}
                      href={`https://${social}.com`} 
                      className="bg-muted hover:bg-muted/80 p-3 rounded-full transition-colors"
                      aria-label={`Visit our ${social} page`}
                    >
                      <span className="sr-only">{social}</span>
                      <div className="w-5 h-5 bg-foreground mask-social-icon"></div>
                    </a>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
