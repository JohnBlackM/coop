import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/lib/supabase';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';

export default function CooperativeRegistration() {
  const { t } = useTranslation();
  const navigate = useNavigate();

  const [name, setName] = useState('');
  const [country, setCountry] = useState('');
  const [region, setRegion] = useState('');
  const [yearFounded, setYearFounded] = useState('');
  const [members, setMembers] = useState('');
  const [hectares, setHectares] = useState('');
  const [certifications, setCertifications] = useState<string[]>([]);
  const [varieties, setVarieties] = useState('');
  const [description, setDescription] = useState('');
  const [contactInfo, setContactInfo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [nextId, setNextId] = useState<number>(0);
  const { toast } = useToast();

  const countries = [
    { value: 'ivoryCoast', label: t('countries.ivoryCoast', 'Côte d\'Ivoire') },
    { value: 'ghana', label: t('countries.ghana', 'Ghana') },
    { value: 'cameroon', label: t('countries.cameroon', 'Cameroun') },
    { value: 'ecuador', label: t('countries.ecuador', 'Équateur') },
    { value: 'peru', label: t('countries.peru', 'Pérou') },
    { value: 'madagascar', label: t('countries.madagascar', 'Madagascar') },
    { value: 'colombia', label: t('countries.colombia', 'Colombie') },
    { value: 'indonesia', label: t('countries.indonesia', 'Indonésie') },
    { value: 'dominicanRepublic', label: t('countries.dominicanRepublic', 'République Dominicaine') },
    { value: 'uganda', label: t('countries.uganda', 'Ouganda') },
  ];

  const certificationOptions = [
    { value: 'organic', label: t('certifications.organic', 'Biologique') },
    { value: 'fairTrade', label: t('certifications.fairTrade', 'Commerce Équitable') },
    { value: 'rainforestAlliance', label: t('certifications.rainforestAlliance', 'Rainforest Alliance') },
    { value: 'utz', label: t('certifications.utz', 'UTZ') },
    { value: 'demeter', label: t('certifications.demeter', 'Demeter') },
    { value: 'birdFriendly', label: t('certifications.birdFriendly', 'Bird Friendly') },
  ];

  useEffect(() => {
    const getNextCooperativeId = async () => {
      try {
        // Change this to a simpler query that doesn't use order()
        const { data } = await supabase
          .from('cooperatives')
          .select('id');
        
        // Manually find the highest ID
        let highestId = 0;
        if (data && data.length > 0) {
          data.forEach(coop => {
            if (coop.id > highestId) {
              highestId = coop.id;
            }
          });
        }
        
        setNextId(highestId + 1);
      } catch (error) {
        console.error("Failed to get next cooperative ID:", error);
        // Fallback to a random ID
        setNextId(Math.floor(Math.random() * 1000) + 100);
      }
    };
    
    getNextCooperativeId();
  }, []);

  const handleCertificationChange = (certification: string) => {
    setCertifications(prev => {
      if (prev.includes(certification)) {
        return prev.filter(c => c !== certification);
      } else {
        return [...prev, certification];
      }
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form
    if (!name || !country || !region || !yearFounded || !members || !hectares || !description) {
      toast({
        title: t('cooperativeRegistration.errorTitle', 'Erreur'),
        description: t('cooperativeRegistration.fillAllFields', 'Veuillez remplir tous les champs obligatoires.'),
        variant: 'destructive',
      });
      return;
    }

    const newCooperative = {
      id: nextId,
      name,
      country,
      region,
      yearFounded: parseInt(yearFounded, 10),
      members: parseInt(members, 10),
      hectares: parseInt(hectares, 10),
      certifications,
      varieties: varieties.split(',').map(v => v.trim()),
      description,
      contactInfo,
      mainImage: '',  // Set default or handle image upload separately
      gallery: [],     // Set default or handle gallery uploads separately
      story: '',        // Can be empty initially
      featured: false,
      status: 'pending', // Or 'draft'
      createdAt: new Date().toISOString(),
      media: { photos: [], videos: [] }
    };
    
    try {
      setIsSubmitting(true);
      
      // Submit to Supabase
      const { error } = await supabase
        .from('cooperatives')
        .insert(newCooperative);
      
      if (error) throw error;
      
      toast({
        title: t('cooperativeRegistration.success', 'Demande envoyée'),
        description: t('cooperativeRegistration.successMessage', 'Votre demande d\'enregistrement a été envoyée avec succès. Nous vous contacterons prochainement.'),
      });
      
      // Redirect to thank you page or homepage
      navigate('/');
    } catch (error) {
      console.error("Error submitting cooperative registration:", error);
      toast({
        title: t('cooperativeRegistration.errorTitle', 'Erreur'),
        description: t('cooperativeRegistration.errorSubmitting', 'Une erreur est survenue lors de l\'envoi du formulaire. Veuillez réessayer.'),
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>{t('cooperativeRegistration.pageTitle', 'Enregistrement Coopérative | Angara')}</title>
        <meta
          name="description"
          content={t('cooperativeRegistration.metaDescription', 'Enregistrez votre coopérative sur Angara pour rejoindre notre réseau de partenaires engagés.')}
        />
      </Helmet>

      <div className="flex flex-col min-h-screen">
        <Navbar />

        <main className="container mx-auto px-4 py-8 flex-grow">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-3xl font-bold text-center mb-6">{t('cooperativeRegistration.title', 'Enregistrement de votre Coopérative')}</h1>
            <p className="text-muted-foreground text-center mb-8">{t('cooperativeRegistration.subtitle', 'Rejoignez notre réseau de coopératives partenaires et bénéficiez d\'une visibilité accrue.')}</p>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="name">{t('cooperativeRegistration.name', 'Nom de la Coopérative')} *</Label>
                <Input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={t('cooperativeRegistration.namePlaceholder', 'Entrez le nom de la coopérative')}
                  required
                />
              </div>

              <div>
                <Label htmlFor="country">{t('cooperativeRegistration.country', 'Pays')} *</Label>
                <Select value={country} onValueChange={setCountry}>
                  <SelectTrigger>
                    <SelectValue placeholder={t('cooperativeRegistration.selectCountry', 'Sélectionnez un pays')} />
                  </SelectTrigger>
                  <SelectContent>
                    {countries.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="region">{t('cooperativeRegistration.region', 'Région')} *</Label>
                <Input
                  type="text"
                  id="region"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  placeholder={t('cooperativeRegistration.regionPlaceholder', 'Entrez la région')}
                  required
                />
              </div>

              <div>
                <Label htmlFor="yearFounded">{t('cooperativeRegistration.yearFounded', 'Année de Fondation')} *</Label>
                <Input
                  type="number"
                  id="yearFounded"
                  value={yearFounded}
                  onChange={(e) => setYearFounded(e.target.value)}
                  placeholder={t('cooperativeRegistration.yearFoundedPlaceholder', 'Entrez l\'année de fondation')}
                  required
                />
              </div>

              <div>
                <Label htmlFor="members">{t('cooperativeRegistration.members', 'Nombre de Membres')} *</Label>
                <Input
                  type="number"
                  id="members"
                  value={members}
                  onChange={(e) => setMembers(e.target.value)}
                  placeholder={t('cooperativeRegistration.membersPlaceholder', 'Entrez le nombre de membres')}
                  required
                />
              </div>

              <div>
                <Label htmlFor="hectares">{t('cooperativeRegistration.hectares', 'Hectares de Culture')} *</Label>
                <Input
                  type="number"
                  id="hectares"
                  value={hectares}
                  onChange={(e) => setHectares(e.target.value)}
                  placeholder={t('cooperativeRegistration.hectaresPlaceholder', 'Entrez la superficie en hectares')}
                  required
                />
              </div>

              <div>
                <Label>{t('cooperativeRegistration.certifications', 'Certifications')}</Label>
                <div className="space-y-2">
                  {certificationOptions.map(option => (
                    <div key={option.value} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.value}
                        checked={certifications.includes(option.value)}
                        onCheckedChange={() => handleCertificationChange(option.value)}
                      />
                      <Label htmlFor={option.value} className="cursor-pointer">
                        {option.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label htmlFor="varieties">{t('cooperativeRegistration.varieties', 'Variétés Cultivées')}</Label>
                <Input
                  type="text"
                  id="varieties"
                  value={varieties}
                  onChange={(e) => setVarieties(e.target.value)}
                  placeholder={t('cooperativeRegistration.varietiesPlaceholder', 'Entrez les variétés séparées par des virgules')}
                />
              </div>

              <div>
                <Label htmlFor="description">{t('cooperativeRegistration.description', 'Description de la Coopérative')} *</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={t('cooperativeRegistration.descriptionPlaceholder', 'Décrivez votre coopérative, ses valeurs et ses pratiques')}
                  required
                />
              </div>

              <div>
                <Label htmlFor="contactInfo">{t('cooperativeRegistration.contactInfo', 'Informations de Contact')}</Label>
                <Input
                  type="text"
                  id="contactInfo"
                  value={contactInfo}
                  onChange={(e) => setContactInfo(e.target.value)}
                  placeholder={t('cooperativeRegistration.contactInfoPlaceholder', 'Entrez les informations de contact (email, téléphone)')}
                />
              </div>

              <Button disabled={isSubmitting}>
                {isSubmitting ? (
                  <>
                    {t('cooperativeRegistration.submitting', 'Envoi en cours...')}
                  </>
                ) : (
                  t('cooperativeRegistration.submit', 'Envoyer la Demande')
                )}
              </Button>
            </form>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}
