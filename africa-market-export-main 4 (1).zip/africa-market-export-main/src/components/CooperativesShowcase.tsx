import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { useToast } from '@/hooks/use-toast';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CooperativeHero from '@/components/cooperatives/CooperativeHero';
import AboutCooperatives from '@/components/cooperatives/AboutCooperatives';
import FeaturedCooperatives from '@/components/cooperatives/FeaturedCooperatives';
import AllCooperatives from '@/components/cooperatives/AllCooperatives';
import BecomePartner from '@/components/cooperatives/BecomePartner';

import { Cooperative } from '@/types/cooperative';
import { supabase } from '@/lib/supabase';
import { cooperatives as localCooperatives } from '@/data/cooperatives';

const CooperativesShowcase = () => {
  const { t } = useTranslation();
  const [cooperatives, setCooperatives] = useState<Cooperative[]>(localCooperatives);
  const [isLoading, setIsLoading] = useState(true);
  const [isSupabaseAvailable, setIsSupabaseAvailable] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCertification, setFilterCertification] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const fetchCooperatives = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('cooperatives')
          .select('*')
          .eq('status', 'published');

        if (error) {
          console.warn("Error loading cooperatives from Supabase:", error);
          setIsSupabaseAvailable(false);
          // Utiliser les données locales
          setCooperatives(localCooperatives);
          return;
        }

        if (data && data.length > 0) {
          // Convertir le type de status pour qu'il corresponde à l'interface Cooperative
          const typedData = data.map(coop => {
            return {
              ...coop,
              status: coop.status as Cooperative['status']
            };
          });
          setCooperatives(typedData);
        } else {
          // Si aucune coopérative n'est trouvée, utiliser les données locales
          console.info("No cooperatives found in database, using local data");
          setCooperatives(localCooperatives);
        }
      } catch (error) {
        console.error("Failed to fetch cooperatives:", error);
        setIsSupabaseAvailable(false);
        // Utiliser les données locales en cas d'erreur
        setCooperatives(localCooperatives);
        toast({
          title: t('cooperativesShowcase.error', 'Erreur'),
          description: t('cooperativesShowcase.errorLoading', 'Erreur lors du chargement des coopératives'),
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchCooperatives();
  }, [t, toast]);

  return (
    <>
      <Helmet>
        <title>{t('cooperativesShowcase.pageTitle', 'Nos Coopératives | Angara')}</title>
        <meta 
          name="description" 
          content={t('cooperativesShowcase.metaDescription', 'Découvrez les coopératives partenaires d\'Angara, engagées dans une agriculture durable et équitable.')} 
        />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow">
          <CooperativeHero 
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filterCertification={filterCertification}
            setFilterCertification={setFilterCertification}
          />
          
          {isLoading ? (
            <div className="py-20 flex justify-center">
              <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <>
              {!isSupabaseAvailable && (
                <div className="container mx-auto px-4 mt-4">
                  <div className="p-3 bg-amber-100 text-amber-800 rounded-md text-sm text-center">
                    {t('cooperativesShowcase.offlineMode', 'Mode déconnecté: Affichage des données locales')}
                  </div>
                </div>
              )}
              
              <AboutCooperatives />
              <FeaturedCooperatives cooperatives={cooperatives.filter(coop => coop.featured)} />
              <AllCooperatives cooperatives={cooperatives} />
              <BecomePartner />
            </>
          )}
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default CooperativesShowcase;
