
import { ArrowUp } from 'lucide-react';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-earth-900 text-black py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-serif text-xl mb-6">Africa Market Export</h3>
            <p className="mb-6">
              Connecting international buyers with premium African resources through a transparent and efficient B2B platform.
            </p>
            <div className="flex space-x-4">
              {['facebook', 'twitter', 'linkedin', 'instagram'].map((social) => (
                <a 
                  key={social}
                  href={`https://${social}.com`} 
                  className="hover:text-gray-700 transition-colors"
                  aria-label={`Visit our ${social} page`}
                >
                  <span className="sr-only">{social}</span>
                  <div className="w-5 h-5"></div>
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {[
                { name: 'Products', href: '#products' },
                { name: 'Why Choose Us', href: '#why-us' },
                { name: 'How It Works', href: '#how-it-works' },
                { name: 'Contact Us', href: '#contact' }
              ].map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-gray-700 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-lg mb-6">Resources</h4>
            <ul className="space-y-3">
              {[
                { name: 'Blog', href: '#' },
                { name: 'Market Reports', href: '#' },
                { name: 'Success Stories', href: '#' },
                { name: 'FAQ', href: '#' }
              ].map((link) => (
                <li key={link.name}>
                  <a 
                    href={link.href} 
                    className="hover:text-gray-700 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-medium text-lg mb-6">Contact</h4>
            <address className="not-italic space-y-3">
              <p>123 Business Avenue, Nairobi, Kenya</p>
              <p>
                <a href="mailto:info@africamarketexport.com" className="hover:text-gray-700 transition-colors">
                  info@africamarketexport.com
                </a>
              </p>
              <p>
                <a href="tel:+254123456789" className="hover:text-gray-700 transition-colors">
                  +254 123 456 789
                </a>
              </p>
            </address>
          </div>
        </div>

        <div className="pt-6 border-t border-earth-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} Africa Market Export. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm">
            <a href="#" className="hover:text-gray-700 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-gray-700 transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-gray-700 transition-colors">Cookie Policy</a>
          </div>
        </div>

        <button 
          onClick={scrollToTop}
          className="fixed bottom-8 right-8 bg-primary hover:bg-primary/90 text-white p-3 rounded-full shadow-lg transition-all btn-hover"
          aria-label="Scroll to top"
        >
          <ArrowUp className="h-5 w-5" />
        </button>
      </div>
    </footer>
  );
}
