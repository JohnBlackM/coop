
import { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false);
  const { t } = useTranslation();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  // Handle smooth scrolling
  const scrollToSection = (sectionId: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80, // Offset for navbar height
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center py-16 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 -z-10 opacity-40">
        <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-b from-forest-50 to-transparent"></div>
        <div className="absolute grid grid-cols-10 grid-rows-10 gap-4 w-full h-full">
          {Array.from({ length: 100 }).map((_, i) => (
            <div
              key={i}
              className="bg-forest-100 rounded-full opacity-20"
              style={{
                animationDelay: `${(i % 10) * 0.1}s`,
                animationDuration: `${5 + (i % 5)}s`,
              }}
            ></div>
          ))}
        </div>
      </div>

      <div className="container mx-auto px-4 md:px-6 pt-16 md:pt-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className={`space-y-6 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
            <span className="inline-block py-1 px-3 bg-forest-100 text-forest-800 rounded-full text-sm font-medium">
              {t('hero.tagline')}
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight">
              {t('hero.title')}
              <span className="bg-clip-text text-transparent bg-gradient-to-r from-forest-700 to-green-700"> {t('hero.titleHighlight')}</span>
            </h1>
            <p className="text-lg text-muted-foreground">
              {t('hero.description')}
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
              <a
                href="#contact"
                onClick={scrollToSection('contact')}
                className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-md transition-all btn-hover flex items-center justify-center space-x-2 text-center"
              >
                <span>{t('hero.getStarted')}</span>
                <ArrowRight size={18} />
              </a>
              <a
                href="#how-it-works"
                onClick={scrollToSection('how-it-works')}
                className="bg-transparent hover:bg-forest-50 text-foreground border border-border px-6 py-3 rounded-md transition-all btn-hover text-center"
              >
                {t('hero.howItWorks')}
              </a>
            </div>
          </div>

          <div className={`relative ${isVisible ? 'animate-fade-in' : 'opacity-0'}`} style={{ animationDelay: '0.3s' }}>
            <div className="relative rounded-2xl overflow-hidden shadow-xl aspect-square">
              <div className="absolute inset-0 bg-gradient-to-br from-forest-300/20 to-green-300/20 mix-blend-overlay"></div>
              <img
                src="/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png"
                alt="African trade marketplace with shopping cart"
                className="w-full h-full object-contain"
              />
              <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2 text-center w-[120%]">
                <h3 className="text-black font-bold text-3xl md:text-4xl animate-pulse">
                  Africa Market Export
                </h3>
              </div>
            </div>
            <div className="absolute -bottom-6 -right-6 bg-white smooth-shadow rounded-lg p-4 w-48 animate-fade-up" style={{ animationDelay: '0.8s' }}>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-green-500"></div>
                <span className="text-sm font-medium">{t('hero.verifiedProducers')}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{t('hero.transparentSupplyChain')}</p>
            </div>
            <div className="absolute -top-6 -left-6 bg-white smooth-shadow rounded-lg p-4 w-48 animate-fade-up" style={{ animationDelay: '1s' }}>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 rounded-full bg-forest-500"></div>
                <span className="text-sm font-medium">{t('hero.qualityAssured')}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-1">{t('hero.premiumResources')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
