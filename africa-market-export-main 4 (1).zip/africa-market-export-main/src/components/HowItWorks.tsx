
import { useRef, useState, useEffect } from 'react';
import { 
  UserCheck, 
  Search, 
  FileText, 
  Truck, 
  ArrowRight 
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function HowItWorks() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { t } = useTranslation();

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  // Handle smooth scrolling to contact section
  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      window.scrollTo({
        top: contactSection.offsetTop - 80, // Offset for navbar height
        behavior: 'smooth'
      });
    }
  };

  return (
    <div ref={sectionRef} className="bg-forest-50">
      <div className="container mx-auto px-4 md:px-6 py-16 md:py-24">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-4">
            {t('howItWorks.subtitle')}
          </span>
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
            {t('howItWorks.sectionTitle')}
          </h2>
          <p className={`text-muted-foreground ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            {t('howItWorks.description')}
          </p>
        </div>

        <div className="relative">
          {/* Timeline connector line for desktop */}
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-green-200 z-0 hidden md:block"></div>

          <div className="space-y-12 md:space-y-0 relative z-10">
            {[
              {
                icon: UserCheck,
                title: t('howItWorks.steps.register.title'),
                description: t('howItWorks.steps.register.description')
              },
              {
                icon: Search,
                title: t('howItWorks.steps.browse.title'),
                description: t('howItWorks.steps.browse.description')
              },
              {
                icon: FileText,
                title: t('howItWorks.steps.request.title'),
                description: t('howItWorks.steps.request.description')
              },
              {
                icon: Truck,
                title: t('howItWorks.steps.track.title'),
                description: t('howItWorks.steps.track.description')
              }
            ].map((step, index) => (
              <div 
                key={step.title}
                className={`${isVisible ? 'animate-fade-up' : 'opacity-0'}`}
                style={{ animationDelay: `${0.3 + index * 0.2}s` }}
              >
                <div className={`md:grid md:grid-cols-2 ${index % 2 === 0 ? 'md:text-right' : ''} items-center gap-8`}>
                  {/* Step Content */}
                  <div className={index % 2 === 0 ? 'md:order-1' : 'md:order-2'}>
                    <div className="bg-white rounded-xl p-6 smooth-shadow">
                      <div className="flex md:hidden items-center space-x-4 mb-4">
                        <div className="bg-green-100 p-3 rounded-full">
                          <step.icon className="h-6 w-6 text-green-700" />
                        </div>
                        <div className="font-bold text-xl">{step.title}</div>
                      </div>
                      <div className="hidden md:block mb-4">
                        <div className={`font-bold text-xl mb-2 ${index % 2 === 0 ? 'text-right' : 'text-left'}`}>{step.title}</div>
                      </div>
                      <p className={`text-muted-foreground ${index % 2 === 0 ? 'md:text-right' : 'md:text-left'}`}>{step.description}</p>
                    </div>
                  </div>

                  {/* Step Icon (Desktop) */}
                  <div className={`hidden md:flex ${index % 2 === 0 ? 'md:justify-start' : 'md:justify-end'} md:items-center md:order-${index % 2 === 0 ? 2 : 1}`}>
                    <div className="relative">
                      <div className="absolute top-1/2 transform -translate-y-1/2 bg-white h-0.5 w-8 z-0"></div>
                      <div className="bg-green-700 p-4 rounded-full z-10 relative">
                        <step.icon className="h-6 w-6 text-white" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className={`mt-16 text-center ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '1s' }}>
          <a 
            href="#contact" 
            onClick={scrollToContact}
            className="inline-flex items-center space-x-2 bg-green-700 text-white px-6 py-3 rounded-md hover:bg-green-800 transition-all btn-hover"
          >
            <span>{t('howItWorks.startJourney')}</span>
            <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </div>
  );
}
