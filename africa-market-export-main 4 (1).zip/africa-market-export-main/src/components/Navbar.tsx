
import { useTranslation } from 'react-i18next';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Coffee, Menu } from 'lucide-react';
import LanguageSwitcher from './LanguageSwitcher';
import NavbarAuthMenu from './auth/NavbarAuthMenu';

const Navbar = () => {
  const { t } = useTranslation();
  const location = useLocation();
  
  // Function to handle smooth scrolling to sections
  const scrollToSection = (sectionId: string) => (e: React.MouseEvent) => {
    // Only handle scrolling on the home page
    if (location.pathname === '/') {
      e.preventDefault();
      const element = document.getElementById(sectionId);
      if (element) {
        window.scrollTo({
          top: element.offsetTop - 80, // Offset for navbar height
          behavior: 'smooth'
        });
      }
    }
  };

  return (
    <nav className="bg-background/95 supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 w-full border-b backdrop-blur">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center gap-6 md:gap-8">
          <Link to="/" className="flex items-center space-x-2">
            <Coffee className="h-6 w-6" />
            <span className="font-bold">{t('general.siteName', 'Africa Market Export')}</span>
          </Link>
          
          <div className="hidden md:flex md:items-center md:gap-6">
            <Link to={location.pathname === '/' ? '#products' : '/'} onClick={scrollToSection('products')}>
              <Button variant="ghost">
                {t('navbar.products', 'Produits')}
              </Button>
            </Link>
            <Link to={location.pathname === '/' ? '#why-us' : '/'} onClick={scrollToSection('why-us')}>
              <Button variant="ghost">
                {t('navbar.whyUs', 'Pourquoi Nous')}
              </Button>
            </Link>
            <Link to={location.pathname === '/' ? '#how-it-works' : '/'} onClick={scrollToSection('how-it-works')}>
              <Button variant="ghost">
                {t('navbar.howItWorks', 'Comment Ça Marche')}
              </Button>
            </Link>
            <Link to={location.pathname === '/' ? '#cooperatives' : '/'} onClick={scrollToSection('cooperatives')}>
              <Button variant="ghost">
                {t('navbar.cooperatives', 'Coopératives')}
              </Button>
            </Link>
            <Link to={location.pathname === '/' ? '#register-cooperative' : '/'} onClick={scrollToSection('register-cooperative')}>
              <Button variant="ghost">
                {t('navbar.register', 'Enregistrer une coopérative')}
              </Button>
            </Link>
            <Link to={location.pathname === '/' ? '#contact' : '/'} onClick={scrollToSection('contact')}>
              <Button variant="ghost">
                {t('navbar.contact', 'Contact')}
              </Button>
            </Link>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <NavbarAuthMenu />
          <LanguageSwitcher />
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-6 w-6" />
          </Button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
