import { useState, useEffect, useRef } from 'react';
import { ChevronRight } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Product, validateProduct } from '@/types/product';
import { useToast } from '@/hooks/use-toast';
import { supabase, isOfflineMode, getImageUrl } from '@/lib/supabase/client';

const fallbackProducts: Product[] = [
  {
    id: "1",
    name: "Cacao bio équitable",
    description: "Un cacao d'exception cultivé dans le respect de l'environnement",
    category: "cocoa",
    price: 15.99,
    imageUrl: "/lovable-uploads/33886502-c848-4c37-9814-27298f58e5a2.png",
    featured: true,
    origin: "Côte d'Ivoire",
    status: "published",
    createdAt: new Date().toISOString()
  },
  {
    id: "2",
    name: "Café arabica",
    description: "Un café aux notes fruitées, cultivé en altitude",
    category: "coffee",
    price: 12.99,
    imageUrl: "/lovable-uploads/3e076b32-7d8b-4490-80c2-be3c753ee051.png",
    featured: true,
    origin: "Colombie",
    status: "published",
    createdAt: new Date().toISOString()
  }
];

export default function ProductShowcase() {
  const { t, i18n } = useTranslation();
  const [selectedCategoryId, setSelectedCategoryId] = useState('cocoa');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);
  const [products, setProducts] = useState<Product[]>(fallbackProducts);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  const loadProducts = async () => {
    setIsLoading(true);
    try {
      const localProductsStr = localStorage.getItem('products');
      if (localProductsStr) {
        try {
          const localProducts = JSON.parse(localProductsStr);
          if (Array.isArray(localProducts) && localProducts.length > 0) {
            console.info("Using products from localStorage");
            const processedProducts = localProducts.map(prod => {
              const validated = validateProduct(prod);
              validated.imageUrl = validated.imageUrl ? getImageUrl(validated.imageUrl) : '';
              return validated;
            });
            setProducts(processedProducts);
            setIsLoading(false);
            return;
          }
        } catch (e) {
          console.warn("Error reading products from localStorage:", e);
        }
      }
      
      if (!isOfflineMode) {
        try {
          const { data, error } = await supabase
            .from('products')
            .select('*');
            
          if (error) {
            throw error;
          }
          
          if (data && data.length > 0) {
            const processedProducts = data.map(prod => {
              const validated = validateProduct(prod);
              validated.imageUrl = validated.imageUrl ? getImageUrl(validated.imageUrl) : '';
              return validated;
            });
            setProducts(processedProducts);
            localStorage.setItem('products', JSON.stringify(processedProducts));
            return;
          } else {
            console.info("No products found in database, using fallback data");
          }
        } catch (supabaseError) {
          console.error("Supabase query error:", supabaseError);
          throw supabaseError;
        }
      } else {
        console.info("Offline mode, using fallback products");
      }
      
      const processedFallbackProducts = fallbackProducts.map(prod => {
        return {
          ...prod,
          imageUrl: getImageUrl(prod.imageUrl)
        };
      });
      setProducts(processedFallbackProducts);
      localStorage.setItem('products', JSON.stringify(processedFallbackProducts));
      
    } catch (error) {
      console.error("Error loading products:", error);
      
      if (products.length === 0) {
        const processedFallbackProducts = fallbackProducts.map(prod => {
          return {
            ...prod,
            imageUrl: getImageUrl(prod.imageUrl)
          };
        });
        setProducts(processedFallbackProducts);
        localStorage.setItem('products', JSON.stringify(processedFallbackProducts));
      }
      
      toast({
        title: t('products.error', 'Error'),
        description: t('products.errorLoading', 'Error loading products'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadProducts().catch(error => {
      console.error("Failed to load products:", error);
      setProducts(fallbackProducts);
      setIsLoading(false);
    });
    
    let subscription: { unsubscribe: () => void } | null = null;
    
    if (!isOfflineMode) {
      try {
        subscription = supabase
          .channel('product-changes')
          .on('broadcast', { event: 'product_updated' }, () => {
            loadProducts().catch(console.error);
          })
          .subscribe();
      } catch (error) {
        console.error("Error setting up realtime subscription:", error);
      }
    }
    
    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  function getFirstProductImageByCategory(category: string): string | undefined {
    const firstProduct = products.find(p => p.category === category && p.imageUrl);
    return firstProduct?.imageUrl;
  }

  useEffect(() => {
    setSelectedCategoryId(prev => prev);
  }, [i18n.language]);

  const productCategories = [
    {
      id: 'cocoa',
      name: t('products.categories.cocoa.name'),
      description: t('products.categories.cocoa.description'),
      image: getFirstProductImageByCategory('cocoa') || '/lovable-uploads/33886502-c848-4c37-9814-27298f58e5a2.png',
      products: products.filter(p => p.category === 'cocoa').map(p => p.name)
    },
    {
      id: 'coffee',
      name: t('products.categories.coffee.name'),
      description: t('products.categories.coffee.description'),
      image: getFirstProductImageByCategory('coffee') || '/lovable-uploads/3e076b32-7d8b-4490-80c2-be3c753ee051.png',
      products: products.filter(p => p.category === 'coffee').map(p => p.name)
    }
  ];

  const selectedCategory = productCategories.find(cat => cat.id === selectedCategoryId) || productCategories[0];
  const hasProducts = selectedCategory.products.length > 0;

  return (
    <section id="products" ref={sectionRef} className="section-padding bg-forest-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-4">
            {t('products.subtitle')}
          </span>
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
            {t('products.sectionTitle')}
          </h2>
          <p className={`text-muted-foreground ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            {t('products.description')}
          </p>
          
          {isOfflineMode && (
            <div className="mt-4 p-2 bg-amber-100 text-amber-800 rounded-md text-sm">
              {t('products.offlineMode', 'Offline mode: Displaying local data')}
            </div>
          )}
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              {productCategories.map((category, index) => (
                <div
                  key={category.id}
                  className={`rounded-xl overflow-hidden smooth-shadow bg-white cursor-pointer transform transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${
                    selectedCategoryId === category.id ? 'ring-2 ring-green-700' : ''
                  } ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}
                  style={{ animationDelay: `${0.3 + index * 0.1}s` }}
                  onClick={() => setSelectedCategoryId(category.id)}
                >
                  <div className="relative h-48 overflow-hidden">
                    <img
                      src={category.image}
                      alt={category.name}
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                    <h3 className="absolute bottom-4 left-4 text-white text-xl font-bold">{category.name}</h3>
                  </div>
                  <div className="p-5">
                    <p className="text-muted-foreground mb-4">{category.description}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium text-green-700">
                        {category.products.length} {t('products.productsCount')}
                      </span>
                      <ChevronRight className="h-5 w-5 text-green-700" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className={`bg-white rounded-xl p-6 md:p-8 smooth-shadow ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4">{selectedCategory.name} {t('products.productsCount')}</h3>
                  <p className="text-muted-foreground mb-6">{selectedCategory.description}</p>
                  
                  {hasProducts ? (
                    <ul className="space-y-3">
                      {selectedCategory.products.map((product) => (
                        <li key={product} className="flex items-center space-x-2">
                          <div className="w-2 h-2 rounded-full bg-green-700"></div>
                          <span>{product}</span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-muted-foreground italic">
                      {t('products.noProductsInCategory', 'No products available in this category')}
                    </p>
                  )}
                  
                  <button className="mt-8 bg-green-700 hover:bg-green-800 text-white px-6 py-3 rounded-md transition-all btn-hover flex items-center space-x-2">
                    <span>{t('products.viewAll')}</span>
                    <ChevronRight className="h-4 w-4" />
                  </button>
                </div>
                <div className="rounded-xl overflow-hidden">
                  <img
                    src={selectedCategory.image}
                    alt={selectedCategory.name}
                    className="w-full h-64 object-cover"
                  />
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </section>
  );
}
