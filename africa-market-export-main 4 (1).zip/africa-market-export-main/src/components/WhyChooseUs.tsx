
import { useRef, useState, useEffect } from 'react';
import { 
  CheckCircle, 
  Shield, 
  TrendingUp, 
  Globe, 
  Award, 
  BarChart
} from 'lucide-react';
import { useTranslation } from 'react-i18next';

export default function WhyChooseUs() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const { t } = useTranslation();

  const features = [
    {
      icon: CheckCircle,
      title: t('whyUs.features.qualityAssurance.title'),
      description: t('whyUs.features.qualityAssurance.description'),
      color: 'bg-green-100 text-green-700'
    },
    {
      icon: Shield,
      title: t('whyUs.features.transparency.title'),
      description: t('whyUs.features.transparency.description'),
      color: 'bg-green-100 text-green-700'
    },
    {
      icon: TrendingUp,
      title: t('whyUs.features.costEfficiency.title'),
      description: t('whyUs.features.costEfficiency.description'),
      color: 'bg-green-100 text-green-700'
    },
    {
      icon: Globe,
      title: t('whyUs.features.ethicalSourcing.title'),
      description: t('whyUs.features.ethicalSourcing.description'),
      color: 'bg-green-100 text-green-700'
    },
    {
      icon: Award,
      title: t('whyUs.features.verifiedProducers.title'),
      description: t('whyUs.features.verifiedProducers.description'),
      color: 'bg-green-100 text-green-700'
    },
    {
      icon: BarChart,
      title: t('whyUs.features.marketInsights.title'),
      description: t('whyUs.features.marketInsights.description'),
      color: 'bg-green-100 text-green-700'
    }
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  // Handle smooth scrolling to contact section
  const scrollToContact = (e: React.MouseEvent) => {
    e.preventDefault();
    const contactSection = document.getElementById('contact');
    if (contactSection) {
      window.scrollTo({
        top: contactSection.offsetTop - 80, // Offset for navbar height
        behavior: 'smooth'
      });
    }
  };

  return (
    <div ref={sectionRef} className="section-padding">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block py-1 px-3 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-4">
            {t('whyUs.subtitle')}
          </span>
          <h2 className={`text-3xl md:text-4xl font-bold mb-4 ${isVisible ? 'animate-fade-up' : 'opacity-0'}`}>
            {t('whyUs.sectionTitle')}
          </h2>
          <p className={`text-muted-foreground ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.2s' }}>
            {t('whyUs.description')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className={`bg-white rounded-xl p-6 smooth-shadow transition-all duration-300 hover:-translate-y-1 hover:shadow-lg ${
                isVisible ? 'animate-fade-up' : 'opacity-0'
              }`}
              style={{ animationDelay: `${0.3 + index * 0.1}s` }}
            >
              <div className={`p-3 rounded-full inline-flex ${feature.color} mb-4`}>
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className={`mt-16 bg-gradient-to-r from-green-700 to-green-900 rounded-xl p-8 md:p-12 text-white overflow-hidden relative ${isVisible ? 'animate-fade-up' : 'opacity-0'}`} style={{ animationDelay: '0.8s' }}>
          {/* Background Pattern */}
          <div className="absolute inset-0 overflow-hidden opacity-10">
            <div className="absolute -right-10 -top-10 w-40 h-40 bg-white rounded-full"></div>
            <div className="absolute -left-12 -bottom-12 w-60 h-60 bg-white rounded-full"></div>
          </div>
          
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl md:text-3xl font-bold mb-4">{t('whyUs.cta')}</h3>
              <p className="text-green-50 mb-6">
                {t('whyUs.ctaDescription')}
              </p>
              <button 
                className="bg-white text-green-900 hover:bg-green-50 px-6 py-3 rounded-md transition-all btn-hover inline-flex items-center"
                onClick={scrollToContact}
              >
                <span>{t('whyUs.ctaButton')}</span>
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <div className="text-2xl md:text-3xl font-bold mb-1">97%</div>
                <p className="text-green-50 text-sm">{t('whyUs.stats.satisfaction')}</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <div className="text-2xl md:text-3xl font-bold mb-1">35+</div>
                <p className="text-green-50 text-sm">{t('whyUs.stats.countries')}</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <div className="text-2xl md:text-3xl font-bold mb-1">500+</div>
                <p className="text-green-50 text-sm">{t('whyUs.stats.producers')}</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <div className="text-2xl md:text-3xl font-bold mb-1">20%</div>
                <p className="text-green-50 text-sm">{t('whyUs.stats.savings')}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
