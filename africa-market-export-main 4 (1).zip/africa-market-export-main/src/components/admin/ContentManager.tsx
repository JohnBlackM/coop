
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { Plus, Trash, Check, X, Edit, Upload, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';

// Types pour les éléments de contenu
interface ContentItem {
  id: string;
  title: string;
  type: 'page' | 'product' | 'article';
  content: string;
  status: 'draft' | 'published';
  lastUpdated: Date;
  imageUrl?: string;
}

// Données de démonstration
const demoContent: ContentItem[] = [
  {
    id: '1',
    title: 'Page d\'accueil',
    type: 'page',
    content: 'Contenu de la page d\'accueil',
    status: 'published',
    lastUpdated: new Date('2023-08-15'),
  },
  {
    id: '2',
    title: 'À propos',
    type: 'page',
    content: 'Contenu de la page à propos',
    status: 'published',
    lastUpdated: new Date('2023-07-20'),
  },
  {
    id: '3',
    title: 'Cacao Premium',
    type: 'product',
    content: 'Description du produit cacao premium',
    status: 'published',
    lastUpdated: new Date('2023-08-10'),
    imageUrl: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png'
  },
  {
    id: '4',
    title: 'Café Robusta',
    type: 'product',
    content: 'Description du produit café robusta',
    status: 'draft',
    lastUpdated: new Date('2023-08-05'),
    imageUrl: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png'
  },
];

export default function ContentManager() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [contentItems, setContentItems] = useState<ContentItem[]>(demoContent);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [filter, setFilter] = useState<string>('all');
  const [isImageDialogOpen, setIsImageDialogOpen] = useState(false);
  const [selectedContentId, setSelectedContentId] = useState<string | null>(null);
  
  // État temporaire pour l'édition
  const [editTitle, setEditTitle] = useState<string>('');
  const [editContent, setEditContent] = useState<string>('');
  const [editImage, setEditImage] = useState<string>('');
  
  // Fonction pour commencer l'édition d'un élément
  const startEditing = (item: ContentItem) => {
    setIsEditing(item.id);
    setEditTitle(item.title);
    setEditContent(item.content);
    setEditImage(item.imageUrl || '');
  };
  
  // Fonction pour sauvegarder les modifications
  const saveEdit = (id: string) => {
    setContentItems(contentItems.map(item => 
      item.id === id 
        ? { ...item, title: editTitle, content: editContent, imageUrl: editImage, lastUpdated: new Date() } 
        : item
    ));
    setIsEditing(null);
    toast({
      title: t('admin.contentUpdated', 'Contenu mis à jour'),
      description: t('admin.changesSuccessfullySaved', 'Les modifications ont été enregistrées avec succès.'),
    });
  };
  
  // Fonction pour annuler l'édition
  const cancelEdit = () => {
    setIsEditing(null);
  };
  
  // Fonction pour supprimer un élément
  const deleteItem = (id: string) => {
    setContentItems(contentItems.filter(item => item.id !== id));
    toast({
      title: t('admin.contentDeleted', 'Contenu supprimé'),
      description: t('admin.contentDeletedSuccess', 'L\'élément a été supprimé avec succès.'),
    });
  };
  
  // Fonction pour changer le statut d'un élément
  const toggleStatus = (id: string) => {
    setContentItems(contentItems.map(item => 
      item.id === id 
        ? { 
            ...item, 
            status: item.status === 'published' ? 'draft' : 'published',
            lastUpdated: new Date() 
          } 
        : item
    ));
    
    const newStatus = contentItems.find(item => item.id === id)?.status === 'published' ? 'draft' : 'published';
    
    toast({
      title: t('admin.statusUpdated', 'Statut mis à jour'),
      description: t(
        'admin.contentNowStatus', 
        'Le contenu est maintenant {{status}}', 
        { status: newStatus === 'published' ? t('admin.published', 'publié') : t('admin.draft', 'en brouillon') }
      ),
    });
  };

  // Fonction pour ouvrir la boîte de dialogue de gestion d'image
  const openImageDialog = (id: string) => {
    const item = contentItems.find(item => item.id === id);
    if (item) {
      setEditImage(item.imageUrl || '');
      setSelectedContentId(id);
      setIsImageDialogOpen(true);
    }
  };

  // Fonction pour enregistrer l'URL de l'image
  const saveImageUrl = () => {
    if (selectedContentId) {
      setContentItems(contentItems.map(item => 
        item.id === selectedContentId 
          ? { ...item, imageUrl: editImage, lastUpdated: new Date() } 
          : item
      ));
      setIsImageDialogOpen(false);
      setSelectedContentId(null);
      toast({
        title: t('admin.imageUpdated', 'Image mise à jour'),
        description: t('admin.imageUpdatedDesc', 'L\'image a été mise à jour avec succès.'),
      });
    }
  };

  // Fonction pour supprimer l'image
  const deleteImage = () => {
    if (selectedContentId) {
      setContentItems(contentItems.map(item => 
        item.id === selectedContentId 
          ? { ...item, imageUrl: '', lastUpdated: new Date() } 
          : item
      ));
      setIsImageDialogOpen(false);
      setSelectedContentId(null);
      toast({
        title: t('admin.imageRemoved', 'Image supprimée'),
        description: t('admin.imageRemovedDesc', 'L\'image a été supprimée avec succès.'),
      });
    }
  };
  
  // Filtrer les éléments de contenu
  const filteredContent = filter === 'all' 
    ? contentItems 
    : contentItems.filter(item => item.type === filter || item.status === filter);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('admin.contentManagement', 'Gestion de contenu')}</h2>
          <p className="text-muted-foreground">{t('admin.manageAllContent', 'Gérez tout le contenu de votre site')}</p>
        </div>
        
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                {t('admin.filter', 'Filtrer')}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-background">
              <DropdownMenuItem onClick={() => setFilter('all')}>{t('admin.all', 'Tous')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('page')}>{t('admin.pages', 'Pages')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('product')}>{t('admin.products', 'Produits')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('article')}>{t('admin.articles', 'Articles')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('published')}>{t('admin.published', 'Publiés')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('draft')}>{t('admin.drafts', 'Brouillons')}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button onClick={() => toast({
            title: t('admin.comingSoon', 'Fonctionnalité à venir'),
            description: t('admin.addContentNotAvailable', 'L\'ajout de contenu n\'est pas encore disponible.')
          })}>
            <Plus className="mr-2 h-4 w-4" />
            {t('admin.addContent', 'Ajouter du contenu')}
          </Button>
        </div>
      </div>
      
      <div className="grid gap-4">
        {filteredContent.map(item => (
          <Card key={item.id}>
            {isEditing === item.id ? (
              // Mode édition
              <>
                <CardHeader>
                  <Label htmlFor={`title-${item.id}`}>{t('admin.title', 'Titre')}</Label>
                  <Input
                    id={`title-${item.id}`}
                    value={editTitle}
                    onChange={(e) => setEditTitle(e.target.value)}
                    className="mt-1"
                  />
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor={`content-${item.id}`}>{t('admin.content', 'Contenu')}</Label>
                      <Textarea
                        id={`content-${item.id}`}
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="mt-1 min-h-[150px]"
                      />
                    </div>
                    
                    {item.type === 'product' && (
                      <div>
                        <Label htmlFor={`image-${item.id}`}>{t('admin.image', 'Image')}</Label>
                        <div className="flex items-center gap-2 mt-1">
                          <Input
                            id={`image-${item.id}`}
                            value={editImage}
                            onChange={(e) => setEditImage(e.target.value)}
                            placeholder="/lovable-uploads/image.png"
                          />
                          {editImage && (
                            <Button 
                              variant="destructive" 
                              size="sm"
                              onClick={() => setEditImage('')}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        {editImage && (
                          <div className="mt-2 w-40 h-40 border rounded">
                            <img
                              src={editImage}
                              alt="Preview"
                              className="w-full h-full object-cover rounded"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = '/placeholder.svg';
                              }}
                            />
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={cancelEdit}>
                    <X className="mr-2 h-4 w-4" />
                    {t('admin.cancel', 'Annuler')}
                  </Button>
                  <Button onClick={() => saveEdit(item.id)}>
                    <Check className="mr-2 h-4 w-4" />
                    {t('admin.save', 'Enregistrer')}
                  </Button>
                </CardFooter>
              </>
            ) : (
              // Mode affichage
              <>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{item.title}</CardTitle>
                      <CardDescription>
                        {t('admin.type', 'Type')}: {t(`admin.${item.type}`, item.type)}{' • '}
                        {t('admin.lastUpdated', 'Dernière mise à jour')}: {item.lastUpdated.toLocaleDateString()}
                      </CardDescription>
                    </div>
                    <div className="flex items-center">
                      <span className={`px-2 py-1 rounded-full text-xs mr-2 ${
                        item.status === 'published' 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100'
                      }`}>
                        {item.status === 'published' 
                          ? t('admin.published', 'Publié') 
                          : t('admin.draft', 'Brouillon')}
                      </span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-col md:flex-row gap-4">
                    {item.imageUrl && item.type === 'product' && (
                      <div className="w-full md:w-40 h-40">
                        <img 
                          src={item.imageUrl} 
                          alt={item.title} 
                          className="w-full h-full object-cover rounded border" 
                        />
                      </div>
                    )}
                    <div className="flex-1">
                      <p className="line-clamp-2">{item.content}</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-end space-x-2">
                  {item.type === 'product' && (
                    <Button variant="outline" onClick={() => openImageDialog(item.id)}>
                      <ImageIcon className="mr-2 h-4 w-4" />
                      {item.imageUrl 
                        ? t('admin.manageImage', 'Gérer l\'image') 
                        : t('admin.addImage', 'Ajouter une image')}
                    </Button>
                  )}
                  <Button variant="outline" onClick={() => toggleStatus(item.id)}>
                    {item.status === 'published' 
                      ? t('admin.unpublish', 'Dépublier') 
                      : t('admin.publish', 'Publier')}
                  </Button>
                  <Button variant="outline" onClick={() => startEditing(item)}>
                    <Edit className="mr-2 h-4 w-4" />
                    {t('admin.edit', 'Modifier')}
                  </Button>
                  <Button variant="destructive" onClick={() => deleteItem(item.id)}>
                    <Trash className="mr-2 h-4 w-4" />
                    {t('admin.delete', 'Supprimer')}
                  </Button>
                </CardFooter>
              </>
            )}
          </Card>
        ))}
        
        {filteredContent.length === 0 && (
          <Card className="py-8">
            <CardContent className="flex flex-col items-center justify-center text-center">
              <p className="text-muted-foreground mb-4">
                {t('admin.noContentFound', 'Aucun contenu trouvé pour ce filtre')}
              </p>
              <Button variant="outline" onClick={() => setFilter('all')}>
                {t('admin.showAllContent', 'Afficher tout le contenu')}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Dialogue de gestion d'image */}
      <Dialog open={isImageDialogOpen} onOpenChange={setIsImageDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{t('admin.manageImage', 'Gérer l\'image')}</DialogTitle>
            <DialogDescription>
              {t('admin.imageUrlDesc', 'Entrez l\'URL de l\'image ou supprimez l\'image existante')}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="image-url">{t('admin.imageUrl', 'URL de l\'image')}</Label>
              <Input
                id="image-url"
                value={editImage}
                onChange={(e) => setEditImage(e.target.value)}
                placeholder="/lovable-uploads/image.png"
              />
            </div>
            
            {editImage && (
              <div className="mt-2 w-full h-40 border rounded">
                <img
                  src={editImage}
                  alt="Preview"
                  className="w-full h-full object-cover rounded"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = '/placeholder.svg';
                  }}
                />
              </div>
            )}
          </div>
          
          <DialogFooter>
            {editImage && (
              <Button variant="destructive" onClick={deleteImage}>
                <Trash className="mr-2 h-4 w-4" />
                {t('admin.deleteImage', 'Supprimer l\'image')}
              </Button>
            )}
            <Button variant="outline" onClick={() => setIsImageDialogOpen(false)}>
              {t('admin.cancel', 'Annuler')}
            </Button>
            <Button onClick={saveImageUrl}>
              <Check className="mr-2 h-4 w-4" />
              {t('admin.save', 'Enregistrer')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
