
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { CheckIcon, PencilIcon, PlusIcon, TrashIcon, ImageIcon, FileVideo, MessageSquare, Award } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Cooperative, MediaItem, Testimonial, SuccessStory } from '@/types/cooperative';
import { cooperatives as initialCooperatives } from '@/data/cooperatives';
import { useToast } from '@/hooks/use-toast';
import TestimonialsManager from './TestimonialsManager';

interface CooperativeManagerProps {
  initialTab?: string;
}

export default function CooperativeManager({ initialTab = "published" }: CooperativeManagerProps) {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [cooperatives, setCooperatives] = useState<Cooperative[]>(() => {
    // Get initial cooperatives and merge with any from localStorage
    let coops = [...initialCooperatives];
    
    try {
      const pendingCoops = localStorage.getItem('pendingCooperatives');
      if (pendingCoops) {
        const parsedPendingCoops = JSON.parse(pendingCoops) as Cooperative[];
        coops = [...coops, ...parsedPendingCoops];
      }
    } catch (error) {
      console.error("Error loading pending cooperatives:", error);
    }
    
    return coops;
  });
  
  const [selectedCooperative, setSelectedCooperative] = useState<Cooperative | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddMediaDialogOpen, setIsAddMediaDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(initialTab === "pending" ? "pending" : "published");
  const [displayTab, setDisplayTab] = useState(activeTab);
  const [mediaType, setMediaType] = useState<'photo' | 'video'>('photo');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [newMediaCaption, setNewMediaCaption] = useState('');
  const [newMediaCategory, setNewMediaCategory] = useState<'plantation' | 'work' | 'product'>('plantation');
  
  // Filter cooperatives based on active tab
  const filteredCooperatives = cooperatives.filter(coop => {
    if (displayTab === "pending") {
      return coop.status === "pending";
    } else if (displayTab === "published") {
      return coop.status === "published" || !coop.status; // Include coops without status for backwards compatibility
    } else if (displayTab === "rejected") {
      return coop.status === "rejected";
    } else {
      return true; // Show all by default
    }
  });
  
  const [newCooperative, setNewCooperative] = useState<Partial<Cooperative>>({
    name: '',
    country: '',
    region: '',
    yearFounded: new Date().getFullYear(),
    members: 0,
    hectares: 0,
    certifications: [],
    varieties: [],
    description: '',
    mainImage: '',
    gallery: [],
    media: { photos: [], videos: [] },
    story: '',
    featured: false,
    testimonials: [],
    successStories: [],
    status: 'draft'
  });

  // Update localStorage when cooperatives change
  const updateLocalStorage = (updatedCoops: Cooperative[]) => {
    try {
      const pendingCoops = updatedCoops.filter(coop => coop.status === "pending");
      localStorage.setItem('pendingCooperatives', JSON.stringify(pendingCoops));
    } catch (error) {
      console.error("Error updating localStorage:", error);
    }
  };

  const handleAddCooperative = () => {
    const id = Math.max(0, ...cooperatives.map(c => c.id)) + 1;
    const cooperative: Cooperative = {
      ...newCooperative as Cooperative,
      id,
      certifications: newCooperative.certifications || [],
      varieties: newCooperative.varieties || [],
      gallery: newCooperative.gallery || [],
      media: newCooperative.media || { photos: [], videos: [] },
      testimonials: newCooperative.testimonials || [],
      successStories: newCooperative.successStories || [],
      status: newCooperative.status || 'draft'
    };
    
    const updatedCoops = [...cooperatives, cooperative];
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    setIsAddDialogOpen(false);
    setNewCooperative({
      name: '',
      country: '',
      region: '',
      yearFounded: new Date().getFullYear(),
      members: 0,
      hectares: 0,
      certifications: [],
      varieties: [],
      description: '',
      mainImage: '',
      gallery: [],
      media: { photos: [], videos: [] },
      story: '',
      featured: false,
      testimonials: [],
      successStories: [],
      status: 'draft'
    });
    
    toast({
      title: t('admin.cooperativeAdded', 'Coopérative ajoutée'),
      description: t('admin.cooperativeAddedDesc', 'La coopérative a été ajoutée avec succès.'),
    });
  };

  const handleDeleteCooperative = (id: number) => {
    const updatedCoops = cooperatives.filter(coop => coop.id !== id);
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    toast({
      title: t('admin.cooperativeDeleted', 'Coopérative supprimée'),
      description: t('admin.cooperativeDeletedDesc', 'La coopérative a été supprimée avec succès.'),
    });
  };

  const handleEditCooperative = () => {
    if (!selectedCooperative) return;
    
    const updatedCoops = cooperatives.map(coop => 
      coop.id === selectedCooperative.id ? selectedCooperative : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    setIsEditDialogOpen(false);
    toast({
      title: t('admin.cooperativeUpdated', 'Coopérative mise à jour'),
      description: t('admin.cooperativeUpdatedDesc', 'Les informations de la coopérative ont été mises à jour.'),
    });
  };

  const handleChangeStatus = (id: number, newStatus: 'draft' | 'pending' | 'published' | 'rejected') => {
    const updatedCoops = cooperatives.map(coop => 
      coop.id === id ? { ...coop, status: newStatus } : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    toast({
      title: t('admin.statusUpdated', 'Statut mis à jour'),
      description: t('admin.statusUpdatedDesc', 'Le statut de la coopérative a été mis à jour.'),
    });
  };

  const handleAddMedia = () => {
    if (!selectedCooperative) return;
    
    const mediaId = `${mediaType[0]}${Date.now()}`;
    
    const newMediaItem: MediaItem = {
      id: mediaId,
      url: newMediaUrl,
      caption: newMediaCaption,
      category: newMediaCategory
    };
    
    const updatedCooperative = { ...selectedCooperative };
    
    if (mediaType === 'photo') {
      updatedCooperative.media.photos = [...updatedCooperative.media.photos, newMediaItem];
    } else {
      updatedCooperative.media.videos = [...updatedCooperative.media.videos, newMediaItem];
    }
    
    setSelectedCooperative(updatedCooperative);
    const updatedCoops = cooperatives.map(coop => 
      coop.id === selectedCooperative.id ? updatedCooperative : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    setNewMediaUrl('');
    setNewMediaCaption('');
    setIsAddMediaDialogOpen(false);
    
    toast({
      title: t('admin.mediaAdded', 'Média ajouté'),
      description: t('admin.mediaAddedDesc', 'Le média a été ajouté à la coopérative avec succès.'),
    });
  };

  const handleDeleteMedia = (mediaId: string, type: 'photo' | 'video') => {
    if (!selectedCooperative) return;
    
    const updatedCooperative = { ...selectedCooperative };
    
    if (type === 'photo') {
      updatedCooperative.media.photos = updatedCooperative.media.photos.filter(
        photo => photo.id !== mediaId
      );
    } else {
      updatedCooperative.media.videos = updatedCooperative.media.videos.filter(
        video => video.id !== mediaId
      );
    }
    
    setSelectedCooperative(updatedCooperative);
    const updatedCoops = cooperatives.map(coop => 
      coop.id === selectedCooperative.id ? updatedCooperative : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    toast({
      title: t('admin.mediaDeleted', 'Média supprimé'),
      description: t('admin.mediaDeletedDesc', 'Le média a été supprimé de la coopérative.'),
    });
  };

  const handleUpdateTestimonials = (testimonials: Testimonial[]) => {
    if (!selectedCooperative) return;
    
    const updatedCooperative = { 
      ...selectedCooperative,
      testimonials 
    };
    
    setSelectedCooperative(updatedCooperative);
    const updatedCoops = cooperatives.map(coop => 
      coop.id === selectedCooperative.id ? updatedCooperative : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    toast({
      title: t('admin.testimonialsUpdated', 'Témoignages mis à jour'),
      description: t('admin.testimonialsUpdatedDesc', 'Les témoignages ont été mis à jour avec succès.'),
    });
  };

  const handleUpdateSuccessStories = (successStories: SuccessStory[]) => {
    if (!selectedCooperative) return;
    
    const updatedCooperative = { 
      ...selectedCooperative,
      successStories 
    };
    
    setSelectedCooperative(updatedCooperative);
    const updatedCoops = cooperatives.map(coop => 
      coop.id === selectedCooperative.id ? updatedCooperative : coop
    );
    
    setCooperatives(updatedCoops);
    updateLocalStorage(updatedCoops);
    
    toast({
      title: t('admin.successStoriesUpdated', 'Histoires de réussite mises à jour'),
      description: t('admin.successStoriesUpdatedDesc', 'Les histoires de réussite ont été mises à jour avec succès.'),
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t('admin.cooperativeManagement', 'Gestion des coopératives')}</CardTitle>
        <CardDescription>
          {t('admin.cooperativeManagementDesc', 'Ajoutez, modifiez ou supprimez des coopératives et leurs médias')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue={initialTab} value={displayTab} onValueChange={setDisplayTab} className="mb-6">
          <TabsList className="mb-4">
            <TabsTrigger value="published">
              {t('admin.published', 'Publiées')}
            </TabsTrigger>
            <TabsTrigger value="pending">
              {t('admin.pending', 'En attente')}
            </TabsTrigger>
            <TabsTrigger value="rejected">
              {t('admin.rejected', 'Rejetées')}
            </TabsTrigger>
            <TabsTrigger value="all">
              {t('admin.all', 'Toutes')}
            </TabsTrigger>
          </TabsList>
        </Tabs>
        
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-medium">
            {t('admin.cooperativesList', 'Liste des coopératives')} ({filteredCooperatives.length})
          </h3>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="flex items-center gap-1">
                <PlusIcon className="h-4 w-4" />
                {t('admin.addCooperative', 'Ajouter une coopérative')}
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t('admin.newCooperative', 'Nouvelle coopérative')}</DialogTitle>
                <DialogDescription>
                  {t('admin.newCooperativeDesc', 'Entrez les informations de la nouvelle coopérative')}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="name">{t('admin.cooperativeName', 'Nom')}</Label>
                  <Input 
                    id="name" 
                    value={newCooperative.name} 
                    onChange={(e) => setNewCooperative({...newCooperative, name: e.target.value})}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  <div className="grid gap-2">
                    <Label htmlFor="country">{t('admin.cooperativeCountry', 'Pays')}</Label>
                    <Input 
                      id="country" 
                      value={newCooperative.country} 
                      onChange={(e) => setNewCooperative({...newCooperative, country: e.target.value})}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="region">{t('admin.cooperativeRegion', 'Région')}</Label>
                    <Input 
                      id="region" 
                      value={newCooperative.region} 
                      onChange={(e) => setNewCooperative({...newCooperative, region: e.target.value})}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-2">
                  <div className="grid gap-2">
                    <Label htmlFor="yearFounded">{t('admin.cooperativeYear', 'Année de fondation')}</Label>
                    <Input 
                      id="yearFounded" 
                      type="number" 
                      value={newCooperative.yearFounded} 
                      onChange={(e) => setNewCooperative({...newCooperative, yearFounded: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="members">{t('admin.cooperativeMembers', 'Membres')}</Label>
                    <Input 
                      id="members" 
                      type="number" 
                      value={newCooperative.members} 
                      onChange={(e) => setNewCooperative({...newCooperative, members: parseInt(e.target.value)})}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="hectares">{t('admin.cooperativeHectares', 'Hectares')}</Label>
                    <Input 
                      id="hectares" 
                      type="number" 
                      value={newCooperative.hectares} 
                      onChange={(e) => setNewCooperative({...newCooperative, hectares: parseInt(e.target.value)})}
                    />
                  </div>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="description">{t('admin.cooperativeDescription', 'Description')}</Label>
                  <Textarea 
                    id="description" 
                    value={newCooperative.description} 
                    onChange={(e) => setNewCooperative({...newCooperative, description: e.target.value})}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="story">{t('admin.cooperativeStory', 'Histoire')}</Label>
                  <Textarea 
                    id="story" 
                    value={newCooperative.story} 
                    onChange={(e) => setNewCooperative({...newCooperative, story: e.target.value})}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="mainImage">{t('admin.cooperativeMainImage', 'Image principale')}</Label>
                  <Input 
                    id="mainImage" 
                    value={newCooperative.mainImage} 
                    onChange={(e) => setNewCooperative({...newCooperative, mainImage: e.target.value})}
                    placeholder="/lovable-uploads/image.png"
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="status">{t('admin.cooperativeStatus', 'Statut')}</Label>
                  <Select 
                    value={newCooperative.status as string} 
                    onValueChange={(value) => setNewCooperative({
                      ...newCooperative, 
                      status: value as 'draft' | 'pending' | 'published' | 'rejected'
                    })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder={t('admin.selectStatus', 'Sélectionnez un statut')} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">{t('admin.draft', 'Brouillon')}</SelectItem>
                      <SelectItem value="pending">{t('admin.pending', 'En attente')}</SelectItem>
                      <SelectItem value="published">{t('admin.published', 'Publié')}</SelectItem>
                      <SelectItem value="rejected">{t('admin.rejected', 'Rejeté')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex items-center gap-2">
                  <Label htmlFor="featured" className="flex-grow">{t('admin.cooperativeFeatured', 'Mise en avant')}</Label>
                  <input 
                    id="featured" 
                    type="checkbox" 
                    checked={newCooperative.featured} 
                    onChange={(e) => setNewCooperative({...newCooperative, featured: e.target.checked})}
                    className="h-4 w-4"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  {t('admin.cancel', 'Annuler')}
                </Button>
                <Button onClick={handleAddCooperative}>
                  {t('admin.add', 'Ajouter')}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
        
        <div className="space-y-4">
          {filteredCooperatives.length > 0 ? (
            filteredCooperatives.map((coop) => (
              <Card key={coop.id} className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 rounded-md overflow-hidden">
                      <img src={coop.mainImage} alt={coop.name} className="h-full w-full object-cover" />
                    </div>
                    <div>
                      <h4 className="font-medium flex items-center gap-2">
                        {coop.name}
                        {coop.status && (
                          <Badge className={
                            coop.status === 'published' ? 'bg-green-500' : 
                            coop.status === 'pending' ? 'bg-amber-500' : 
                            coop.status === 'rejected' ? 'bg-red-500' : 'bg-gray-500'
                          }>
                            {coop.status === 'published' && t('admin.published', 'Publié')}
                            {coop.status === 'pending' && t('admin.pending', 'En attente')}
                            {coop.status === 'rejected' && t('admin.rejected', 'Rejeté')}
                            {coop.status === 'draft' && t('admin.draft', 'Brouillon')}
                          </Badge>
                        )}
                        {coop.featured && (
                          <Badge className="bg-blue-500">
                            {t('admin.featured', 'Mise en avant')}
                          </Badge>
                        )}
                      </h4>
                      <p className="text-sm text-muted-foreground">{coop.country}, {coop.region}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* Status change buttons */}
                    {coop.status === 'pending' && (
                      <>
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleChangeStatus(coop.id, 'published')}
                          className="bg-green-500 hover:bg-green-600"
                        >
                          <CheckIcon className="h-4 w-4 mr-1" />
                          {t('admin.approve', 'Approuver')}
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleChangeStatus(coop.id, 'rejected')}
                        >
                          <TrashIcon className="h-4 w-4 mr-1" />
                          {t('admin.reject', 'Rejeter')}
                        </Button>
                      </>
                    )}
                    {coop.status === 'rejected' && (
                      <Button
                        variant="default"
                        size="sm"
                        onClick={() => handleChangeStatus(coop.id, 'published')}
                        className="bg-green-500 hover:bg-green-600"
                      >
                        <CheckIcon className="h-4 w-4 mr-1" />
                        {t('admin.publish', 'Publier')}
                      </Button>
                    )}
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedCooperative(coop);
                        setIsEditDialogOpen(true);
                      }}
                    >
                      <PencilIcon className="h-4 w-4 mr-1" />
                      {t('admin.edit', 'Éditer')}
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleDeleteCooperative(coop.id)}
                    >
                      <TrashIcon className="h-4 w-4 mr-1" />
                      {t('admin.delete', 'Supprimer')}
                    </Button>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <Tabs defaultValue="photos" className="w-full" value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="mb-4">
                    <TabsTrigger value="photos" className="flex items-center gap-2">
                      <ImageIcon className="h-4 w-4" />
                      {t('admin.photos', 'Photos')} ({coop.media.photos.length})
                    </TabsTrigger>
                    <TabsTrigger value="videos" className="flex items-center gap-2">
                      <FileVideo className="h-4 w-4" />
                      {t('admin.videos', 'Vidéos')} ({coop.media.videos.length})
                    </TabsTrigger>
                    <TabsTrigger value="testimonials" className="flex items-center gap-2">
                      <MessageSquare className="h-4 w-4" />
                      {t('admin.testimonials', 'Témoignages')} ({coop.testimonials?.length || 0})
                    </TabsTrigger>
                    <TabsTrigger value="successStories" className="flex items-center gap-2">
                      <Award className="h-4 w-4" />
                      {t('admin.successStories', 'Réussites')} ({coop.successStories?.length || 0})
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="photos">
                    <div className="mb-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedCooperative(coop);
                          setMediaType('photo');
                          setIsAddMediaDialogOpen(true);
                        }}
                      >
                        <PlusIcon className="h-4 w-4 mr-1" />
                        {t('admin.addPhoto', 'Ajouter une photo')}
                      </Button>
                    </div>
                    
                    {coop.media.photos.length > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {coop.media.photos.map((photo) => (
                          <div key={photo.id} className="relative group">
                            <div className="aspect-square overflow-hidden rounded-md border">
                              <img 
                                src={photo.url} 
                                alt={photo.caption} 
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <div className="absolute inset-0 flex flex-col justify-between p-2 bg-black/0 group-hover:bg-black/40 transition-all opacity-0 group-hover:opacity-100">
                              <Badge className="self-start bg-white/80 text-black w-fit">
                                {photo.category}
                              </Badge>
                              <div className="flex justify-between items-end w-full">
                                <span className="text-white text-sm bg-black/60 p-1 rounded truncate max-w-[80%]">
                                  {photo.caption}
                                </span>
                                <Button
                                  variant="destructive"
                                  size="icon"
                                  className="h-7 w-7"
                                  onClick={() => handleDeleteMedia(photo.id, 'photo')}
                                >
                                  <TrashIcon className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-4">
                        {t('admin.noPhotos', 'Aucune photo disponible')}
                      </p>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="videos">
                    <div className="mb-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedCooperative(coop);
                          setMediaType('video');
                          setIsAddMediaDialogOpen(true);
                        }}
                      >
                        <PlusIcon className="h-4 w-4 mr-1" />
                        {t('admin.addVideo', 'Ajouter une vidéo')}
                      </Button>
                    </div>
                    
                    {coop.media.videos.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {coop.media.videos.map((video) => (
                          <div key={video.id} className="relative">
                            <div className="aspect-video overflow-hidden rounded-md border">
                              <iframe
                                src={video.url}
                                title={video.caption}
                                className="h-full w-full"
                                allowFullScreen
                              ></iframe>
                            </div>
                            <div className="flex justify-between items-center mt-2">
                              <div className="flex items-center gap-2">
                                <Badge>{video.category}</Badge>
                                <span className="text-sm truncate">{video.caption}</span>
                              </div>
                              <Button
                                variant="destructive"
                                size="icon"
                                className="h-7 w-7"
                                onClick={() => handleDeleteMedia(video.id, 'video')}
                              >
                                <TrashIcon className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-center text-muted-foreground py-4">
                        {t('admin.noVideos', 'Aucune vidéo disponible')}
                      </p>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="testimonials">
                    <TestimonialsManager 
                      testimonials={coop.testimonials || []} 
                      successStories={[]} 
                      onUpdateTestimonials={(testimonials) => handleUpdateTestimonials(testimonials)}
                      onUpdateSuccessStories={() => {}} 
                    />
                  </TabsContent>
                  
                  <TabsContent value="successStories">
                    <TestimonialsManager 
                      testimonials={[]} 
                      successStories={coop.successStories || []} 
                      onUpdateTestimonials={() => {}} 
                      onUpdateSuccessStories={(stories) => handleUpdateSuccessStories(stories)}
                    />
                  </TabsContent>
                </Tabs>
              </Card>
            ))
          ) : (
            <div className="text-center p-8 border rounded-md">
              <p className="text-muted-foreground">
                {displayTab === "pending" 
                  ? t('admin.noPendingCooperatives', 'Aucune coopérative en attente')
                  : displayTab === "rejected"
                  ? t('admin.noRejectedCooperatives', 'Aucune coopérative rejetée')
                  : t('admin.noCooperatives', 'Aucune coopérative disponible')}
              </p>
            </div>
          )}
        </div>
      </CardContent>
      
      {/* Add Media Dialog */}
      <Dialog open={isAddMediaDialogOpen} onOpenChange={setIsAddMediaDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {mediaType === 'photo' 
                ? t('admin.addPhoto', 'Ajouter une photo') 
                : t('admin.addVideo', 'Ajouter une vidéo')}
            </DialogTitle>
            <DialogDescription>
              {mediaType === 'photo'
                ? t('admin.addPhotoDesc', 'Ajoutez une nouvelle photo à la galerie de la coopérative')
                : t('admin.addVideoDesc', 'Ajoutez une nouvelle vidéo à la galerie de la coopérative')}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="mediaUrl">
                {mediaType === 'photo' 
                  ? t('admin.photoUrl', 'URL de la photo') 
                  : t('admin.videoUrl', 'URL de la vidéo')}
              </Label>
              <Input 
                id="mediaUrl" 
                value={newMediaUrl} 
                onChange={(e) => setNewMediaUrl(e.target.value)}
                placeholder={mediaType === 'photo' 
                  ? "/lovable-uploads/image.png" 
                  : "https://www.youtube.com/embed/video-id"}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="mediaCaption">
                {t('admin.mediaCaption', 'Légende')}
              </Label>
              <Input 
                id="mediaCaption" 
                value={newMediaCaption} 
                onChange={(e) => setNewMediaCaption(e.target.value)}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="mediaCategory">
                {t('admin.mediaCategory', 'Catégorie')}
              </Label>
              <Select 
                value={newMediaCategory} 
                onValueChange={(value) => setNewMediaCategory(value as 'plantation' | 'work' | 'product')}
              >
                <SelectTrigger id="mediaCategory">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="plantation">
                    {t('admin.categoryPlantation', 'Plantation')}
                  </SelectItem>
                  <SelectItem value="work">
                    {t('admin.categoryWork', 'Travail')}
                  </SelectItem>
                  <SelectItem value="product">
                    {t('admin.categoryProduct', 'Produit')}
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddMediaDialogOpen(false)}>
              {t('admin.cancel', 'Annuler')}
            </Button>
            <Button onClick={handleAddMedia}>
              {t('admin.add', 'Ajouter')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Cooperative Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{t('admin.editCooperative', 'Modifier la coopérative')}</DialogTitle>
            <DialogDescription>
              {t('admin.editCooperativeDesc', 'Modifiez les informations de la coopérative')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedCooperative && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">{t('admin.cooperativeName', 'Nom')}</Label>
                <Input 
                  id="edit-name" 
                  value={selectedCooperative.name} 
                  onChange={(e) => setSelectedCooperative({...selectedCooperative, name: e.target.value})}
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div className="grid gap-2">
                  <Label htmlFor="edit-country">{t('admin.cooperativeCountry', 'Pays')}</Label>
                  <Input 
                    id="edit-country" 
                    value={selectedCooperative.country} 
                    onChange={(e) => setSelectedCooperative({...selectedCooperative, country: e.target.value})}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-region">{t('admin.cooperativeRegion', 'Région')}</Label>
                  <Input 
                    id="edit-region" 
                    value={selectedCooperative.region} 
                    onChange={(e) => setSelectedCooperative({...selectedCooperative, region: e.target.value})}
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-3 gap-2">
                <div className="grid gap-2">
                  <Label htmlFor="edit-yearFounded">{t('admin.cooperativeYear', 'Année de fondation')}</Label>
                  <Input 
                    id="edit-yearFounded" 
                    type="number" 
                    value={selectedCooperative.yearFounded} 
                    onChange={(e) => setSelectedCooperative({
                      ...selectedCooperative, 
                      yearFounded: parseInt(e.target.value)
                    })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-members">{t('admin.cooperativeMembers', 'Membres')}</Label>
                  <Input 
                    id="edit-members" 
                    type="number" 
                    value={selectedCooperative.members} 
                    onChange={(e) => setSelectedCooperative({
                      ...selectedCooperative, 
                      members: parseInt(e.target.value)
                    })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-hectares">{t('admin.cooperativeHectares', 'Hectares')}</Label>
                  <Input 
                    id="edit-hectares" 
                    type="number" 
                    value={selectedCooperative.hectares} 
                    onChange={(e) => setSelectedCooperative({
                      ...selectedCooperative, 
                      hectares: parseInt(e.target.value)
                    })}
                  />
                </div>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-description">{t('admin.cooperativeDescription', 'Description')}</Label>
                <Textarea 
                  id="edit-description" 
                  value={selectedCooperative.description} 
                  onChange={(e) => setSelectedCooperative({...selectedCooperative, description: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-story">{t('admin.cooperativeStory', 'Histoire')}</Label>
                <Textarea 
                  id="edit-story" 
                  value={selectedCooperative.story} 
                  onChange={(e) => setSelectedCooperative({...selectedCooperative, story: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-mainImage">{t('admin.cooperativeMainImage', 'Image principale')}</Label>
                <Input 
                  id="edit-mainImage" 
                  value={selectedCooperative.mainImage} 
                  onChange={(e) => setSelectedCooperative({...selectedCooperative, mainImage: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-status">{t('admin.cooperativeStatus', 'Statut')}</Label>
                <Select 
                  value={selectedCooperative.status || 'published'} 
                  onValueChange={(value) => setSelectedCooperative({
                    ...selectedCooperative, 
                    status: value as 'draft' | 'pending' | 'published' | 'rejected'
                  })}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue placeholder={t('admin.selectStatus', 'Sélectionnez un statut')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">{t('admin.draft', 'Brouillon')}</SelectItem>
                    <SelectItem value="pending">{t('admin.pending', 'En attente')}</SelectItem>
                    <SelectItem value="published">{t('admin.published', 'Publié')}</SelectItem>
                    <SelectItem value="rejected">{t('admin.rejected', 'Rejeté')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2">
                <Label htmlFor="edit-featured" className="flex-grow">
                  {t('admin.cooperativeFeatured', 'Mise en avant')}
                </Label>
                <input 
                  id="edit-featured" 
                  type="checkbox" 
                  checked={selectedCooperative.featured} 
                  onChange={(e) => setSelectedCooperative({...selectedCooperative, featured: e.target.checked})}
                  className="h-4 w-4"
                />
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              {t('admin.cancel', 'Annuler')}
            </Button>
            <Button onClick={handleEditCooperative}>
              {t('admin.save', 'Enregistrer')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
