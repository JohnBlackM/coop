
// Only updating the problematic part
import { useState, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Image, FileVideo, X, Plus, Upload, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';

export default function ImageManager() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  
  // Liste des emplacements d'images du site
  const imageLocations = [
    { id: 'logo', name: t('admin.logoImage', 'Logo du site'), currentUrl: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png' },
    { id: 'hero', name: t('admin.heroImage', 'Image principale (hero)'), currentUrl: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png' },
    { id: 'product1', name: t('admin.product1Image', 'Produit 1'), currentUrl: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png' },
    { id: 'product2', name: t('admin.product2Image', 'Produit 2'), currentUrl: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png' },
    { id: 'coop1', name: t('admin.coop1Image', 'Coopérative 1'), currentUrl: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png' },
    { id: 'coop2', name: t('admin.coop2Image', 'Coopérative 2'), currentUrl: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png' },
    { id: 'coop3', name: t('admin.coop3Image', 'Coopérative 3'), currentUrl: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png' },
  ];
  
  const [selectedLocation, setSelectedLocation] = useState(imageLocations[0].id);
  const [newImageUrl, setNewImageUrl] = useState('');
  const [newImageFile, setNewImageFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  
  // Cooperative media management states
  const [activeMediaTab, setActiveMediaTab] = useState('photos');
  const [selectedCooperative, setSelectedCooperative] = useState('1');
  
  // Mock cooperative data
  const cooperatives = [
    { id: '1', name: 'Cacao Equitable', country: 'Ivory Coast' },
    { id: '2', name: 'Association des Producteurs de Cacao Bio', country: 'Ghana' },
    { id: '3', name: 'Coopérative des Cultivateurs de Cacao', country: 'Cameroon' },
  ];
  
  // Mock media data
  const [cooperativeMedia, setCooperativeMedia] = useState({
    '1': {
      photos: [
        { id: 'p1', url: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png', caption: 'Plantation de cacao', category: 'plantation' },
        { id: 'p2', url: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png', caption: 'Récolte des cabosses', category: 'work' },
        { id: 'p3', url: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png', caption: 'Cacao séché', category: 'product' },
      ],
      videos: [
        { id: 'v1', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Visite de la plantation', category: 'plantation' },
        { id: 'v2', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Processus de fermentation', category: 'work' },
      ]
    },
    '2': {
      photos: [
        { id: 'p4', url: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png', caption: 'Vue aérienne', category: 'plantation' },
        { id: 'p5', url: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png', caption: 'Fèves de cacao', category: 'product' },
      ],
      videos: []
    },
    '3': {
      photos: [
        { id: 'p6', url: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png', caption: 'Cabosses de cacao', category: 'product' },
      ],
      videos: [
        { id: 'v3', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Processus d\'écabossage', category: 'work' },
      ]
    }
  });
  
  const [newMediaCaption, setNewMediaCaption] = useState('');
  const [newMediaCategory, setNewMediaCategory] = useState('plantation');
  const [newVideoUrl, setNewVideoUrl] = useState('');
  
  const currentImage = imageLocations.find(img => img.id === selectedLocation);
  
  // Fonction pour télécharger l'image sur Supabase Storage
  const uploadImageToSupabase = async (file: File) => {
    try {
      setUploading(true);
      
      // Générer un nom de fichier unique basé sur l'heure actuelle et un nombre aléatoire
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
      const filePath = `media/${fileName}`;
      
      // Télécharger le fichier sur Supabase Storage
      const { data, error } = await supabase
        .storage
        .from('images') // Assurez-vous que ce bucket existe dans votre compte Supabase
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (error) {
        throw error;
      }
      
      // Récupérer l'URL public du fichier
      const { data: urlData } = supabase
        .storage
        .from('images')
        .getPublicUrl(filePath);
      
      return urlData.publicUrl;
    } catch (error) {
      console.error("Erreur de téléchargement :", error);
      throw error;
    } finally {
      setUploading(false);
    }
  };
  
  const handleImageChange = async () => {
    if (!newImageFile) {
      toast({
        title: t('admin.noFileSelected', 'Aucun fichier sélectionné'),
        description: t('admin.pleaseSelectFile', 'Veuillez sélectionner un fichier à télécharger.'),
        variant: 'destructive'
      });
      return;
    }
    
    try {
      setUploading(true);
      const imageUrl = await uploadImageToSupabase(newImageFile);
      
      // Simuler la mise à jour de l'emplacement d'image (à remplacer par l'API réelle)
      setTimeout(() => {
        toast({
          title: t('admin.imageUpdated', 'Image mise à jour'),
          description: t('admin.imageUpdateSuccess', 'L\'image a été mise à jour avec succès.'),
        });
        // Reset state
        setNewImageUrl('');
        setNewImageFile(null);
        setUploading(false);
      }, 500);
    } catch (error) {
      console.error("Erreur lors de la mise à jour de l'image:", error);
      toast({
        title: t('admin.uploadError', 'Erreur de téléchargement'),
        description: t('admin.uploadErrorMessage', 'Une erreur s\'est produite lors du téléchargement de l\'image.'),
        variant: 'destructive'
      });
      setUploading(false);
    }
  };
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      const file = files[0];
      
      // Vérifier si c'est bien une image
      if (!file.type.startsWith('image/')) {
        toast({
          title: t('admin.invalidFileType', 'Type de fichier invalide'),
          description: t('admin.pleaseSelectImage', 'Veuillez sélectionner un fichier image.'),
          variant: 'destructive'
        });
        return;
      }
      
      // Créer une URL temporaire pour l'aperçu
      const previewUrl = URL.createObjectURL(file);
      setNewImageUrl(previewUrl);
      setNewImageFile(file);
      
      // Réinitialiser le champ de fichier pour permettre la sélection du même fichier
      e.target.value = '';
    }
  };
  
  const handleAddCooperativePhoto = async () => {
    if (!newImageFile || !newMediaCaption) {
      toast({
        title: t('admin.formIncomplete', 'Formulaire incomplet'),
        description: t('admin.pleaseCompleteForm', 'Veuillez remplir tous les champs requis.'),
        variant: 'destructive'
      });
      return;
    }
    
    try {
      setUploading(true);
      
      // Upload de l'image vers Supabase
      const imageUrl = await uploadImageToSupabase(newImageFile);
      
      // Ajouter la nouvelle photo au média de la coopérative
      const newMedia = {
        id: `p${Date.now()}`,
        url: imageUrl,
        caption: newMediaCaption,
        category: newMediaCategory as 'plantation' | 'work' | 'product'
      };
      
      setCooperativeMedia(prev => ({
        ...prev,
        [selectedCooperative]: {
          ...prev[selectedCooperative],
          photos: [...prev[selectedCooperative].photos, newMedia]
        }
      }));
      
      // Reset states
      setNewImageUrl('');
      setNewImageFile(null);
      setNewMediaCaption('');
      
      toast({
        title: t('admin.photoAdded', 'Photo ajoutée'),
        description: t('admin.photoAddedSuccess', 'La photo a été ajoutée avec succès.'),
      });
    } catch (error) {
      console.error("Erreur lors de l'ajout de la photo:", error);
      toast({
        title: t('admin.uploadError', 'Erreur de téléchargement'),
        description: t('admin.uploadErrorMessage', 'Une erreur s\'est produite lors du téléchargement de l\'image.'),
        variant: 'destructive'
      });
    } finally {
      setUploading(false);
    }
  };
  
  const handleAddCooperativeVideo = () => {
    if (!newVideoUrl || !newMediaCaption) {
      toast({
        title: t('admin.formIncomplete', 'Formulaire incomplet'),
        description: t('admin.pleaseCompleteForm', 'Veuillez remplir tous les champs requis.'),
        variant: 'destructive'
      });
      return;
    }
    
    setUploading(true);
    
    // Simulate upload delay
    setTimeout(() => {
      const newMedia = {
        id: `v${Date.now()}`,
        url: newVideoUrl,
        caption: newMediaCaption,
        category: newMediaCategory as 'plantation' | 'work' | 'product'
      };
      
      setCooperativeMedia(prev => ({
        ...prev,
        [selectedCooperative]: {
          ...prev[selectedCooperative],
          videos: [...prev[selectedCooperative].videos, newMedia]
        }
      }));
      
      setNewVideoUrl('');
      setNewMediaCaption('');
      setUploading(false);
      
      toast({
        title: t('admin.videoAdded', 'Vidéo ajoutée'),
        description: t('admin.videoAddedSuccess', 'La vidéo a été ajoutée avec succès.'),
      });
    }, 1000);
  };
  
  const handleRemoveMedia = (type: 'photos' | 'videos', id: string) => {
    setCooperativeMedia(prev => ({
      ...prev,
      [selectedCooperative]: {
        ...prev[selectedCooperative],
        [type]: prev[selectedCooperative][type].filter(item => item.id !== id)
      }
    }));
    
    toast({
      title: type === 'photos' ? t('admin.photoRemoved', 'Photo supprimée') : t('admin.videoRemoved', 'Vidéo supprimée'),
      description: type === 'photos' ? 
        t('admin.photoRemovedSuccess', 'La photo a été supprimée avec succès.') : 
        t('admin.videoRemovedSuccess', 'La vidéo a été supprimée avec succès.'),
    });
  };

  const openFilePicker = (type: 'photo' | 'video') => {
    if (type === 'photo') {
      fileInputRef.current?.click();
    } else {
      videoInputRef.current?.click();
    }
  };

  return (
    <div className="space-y-6">
      <Tabs defaultValue="site" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="site">{t('admin.siteImages', 'Images du site')}</TabsTrigger>
          <TabsTrigger value="cooperatives">{t('admin.cooperativeMedia', 'Médias des coopératives')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="site" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.imageManagement', 'Gestion des images')}</CardTitle>
              <CardDescription>
                {t('admin.imageManagementDescription', 'Mettez à jour les images de votre site')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <Label htmlFor="image-location">{t('admin.selectImageLocation', 'Sélectionnez l\'emplacement de l\'image')}</Label>
                <Select 
                  value={selectedLocation} 
                  onValueChange={setSelectedLocation}
                >
                  <SelectTrigger id="image-location" className="w-full">
                    <SelectValue placeholder={t('admin.selectImageLocation', 'Sélectionnez l\'emplacement de l\'image')} />
                  </SelectTrigger>
                  <SelectContent>
                    {imageLocations.map(location => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {currentImage && (
                <div className="pt-4 space-y-4">
                  <h3 className="font-medium">{t('admin.currentImage', 'Image actuelle')}</h3>
                  <div className="border rounded-md overflow-hidden max-w-md">
                    <img 
                      src={currentImage.currentUrl} 
                      alt={currentImage.name} 
                      className="w-full h-48 object-contain"
                    />
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <h3 className="font-medium">{t('admin.uploadNewImage', 'Télécharger une nouvelle image')}</h3>
                  
                  <div className="space-y-4">
                    <Button 
                      variant="outline"
                      onClick={() => openFilePicker('photo')}
                      className="flex items-center gap-2 w-full justify-center py-8 border-dashed"
                    >
                      <Upload className="h-6 w-6 text-muted-foreground" />
                      <span>{t('admin.clickToUpload', 'Cliquez pour sélectionner une image')}</span>
                    </Button>
                    <Input 
                      ref={fileInputRef}
                      type="file" 
                      accept="image/*" 
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    
                    {newImageUrl && (
                      <div className="pt-2">
                        <p className="text-sm mb-2">{t('admin.preview', 'Aperçu')}</p>
                        <div className="border rounded-md overflow-hidden max-w-md">
                          <img 
                            src={newImageUrl} 
                            alt="Preview" 
                            className="w-full h-48 object-contain" 
                          />
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                onClick={handleImageChange} 
                disabled={!newImageFile || uploading}
                className="flex items-center gap-2"
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    {t('admin.updating', 'Mise à jour...')}
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    {t('admin.updateImage', 'Mettre à jour l\'image')}
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.bulkImageUpload', 'Téléchargement en masse')}</CardTitle>
              <CardDescription>
                {t('admin.bulkImageUploadDescription', 'Téléchargez plusieurs images à la fois')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline"
                onClick={() => {
                  toast({
                    title: t('admin.comingSoon', 'Fonctionnalité à venir'),
                    description: t('admin.featureNotAvailable', 'Cette fonctionnalité n\'est pas encore disponible.'),
                  });
                }}
              >
                {t('admin.bulkUpload', 'Téléchargement en masse')}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="cooperatives" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.cooperativeMediaManagement', 'Gestion des médias des coopératives')}</CardTitle>
              <CardDescription>
                {t('admin.cooperativeMediaDescription', 'Ajoutez et gérez les photos et vidéos des coopératives')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4">
                <Label htmlFor="cooperative-select">{t('admin.selectCooperative', 'Sélectionnez une coopérative')}</Label>
                <Select 
                  value={selectedCooperative} 
                  onValueChange={setSelectedCooperative}
                >
                  <SelectTrigger id="cooperative-select" className="w-full">
                    <SelectValue placeholder={t('admin.selectCooperative', 'Sélectionnez une coopérative')} />
                  </SelectTrigger>
                  <SelectContent>
                    {cooperatives.map(coop => (
                      <SelectItem key={coop.id} value={coop.id}>
                        {coop.name} ({coop.country})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <Tabs value={activeMediaTab} onValueChange={setActiveMediaTab} className="w-full">
                <TabsList className="grid grid-cols-2 mb-4">
                  <TabsTrigger value="photos" className="flex items-center gap-2">
                    <Image className="h-4 w-4" />
                    <span>{t('admin.photos', 'Photos')}</span>
                  </TabsTrigger>
                  <TabsTrigger value="videos" className="flex items-center gap-2">
                    <FileVideo className="h-4 w-4" />
                    <span>{t('admin.videos', 'Vidéos')}</span>
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="photos" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {cooperativeMedia[selectedCooperative]?.photos.map(photo => (
                      <div key={photo.id} className="border rounded-md overflow-hidden bg-white">
                        <div className="relative">
                          <img 
                            src={photo.url} 
                            alt={photo.caption} 
                            className="w-full h-48 object-cover"
                          />
                          <Button
                            variant="destructive"
                            size="icon"
                            className="absolute top-2 right-2 h-8 w-8"
                            onClick={() => handleRemoveMedia('photos', photo.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                          <Badge className="absolute bottom-2 left-2 bg-black/60">{photo.category}</Badge>
                        </div>
                        <div className="p-3">
                          <p className="text-sm font-medium truncate">{photo.caption}</p>
                        </div>
                      </div>
                    ))}
                    
                    <div 
                      className="border rounded-md overflow-hidden bg-gray-50 flex flex-col items-center justify-center p-6 h-48 text-center cursor-pointer hover:bg-gray-100 transition-colors"
                      onClick={() => openFilePicker('photo')}
                    >
                      <Plus className="h-10 w-10 text-gray-400 mb-2" />
                      <p className="text-sm text-gray-500 mb-2">{t('admin.addNewPhoto', 'Ajouter une nouvelle photo')}</p>
                      <Button variant="outline" size="sm">
                        {t('admin.browseFiles', 'Parcourir les fichiers')}
                      </Button>
                      <Input 
                        ref={fileInputRef}
                        id="add-photo-input"
                        type="file" 
                        accept="image/*" 
                        className="hidden"
                        onChange={handleFileUpload}
                      />
                    </div>
                  </div>
                  
                  {newImageUrl && (
                    <Card className="mt-6">
                      <CardHeader>
                        <CardTitle>{t('admin.addNewPhoto', 'Ajouter une nouvelle photo')}</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="border rounded-md overflow-hidden max-w-md">
                          <img 
                            src={newImageUrl} 
                            alt="Preview" 
                            className="w-full h-48 object-contain" 
                          />
                        </div>
                        
                        <div className="grid gap-4">
                          <div>
                            <Label htmlFor="photo-caption">{t('admin.photoCaption', 'Légende de la photo')}</Label>
                            <Input 
                              id="photo-caption"
                              value={newMediaCaption}
                              onChange={(e) => setNewMediaCaption(e.target.value)}
                              placeholder={t('admin.enterCaption', 'Entrez une légende descriptive')}
                              className="mt-1"
                            />
                          </div>
                          
                          <div>
                            <Label htmlFor="photo-category">{t('admin.photoCategory', 'Catégorie')}</Label>
                            <Select value={newMediaCategory} onValueChange={setNewMediaCategory}>
                              <SelectTrigger id="photo-category" className="mt-1">
                                <SelectValue placeholder={t('admin.selectCategory', 'Sélectionnez une catégorie')} />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="plantation">{t('admin.categoryPlantation', 'Plantation')}</SelectItem>
                                <SelectItem value="work">{t('admin.categoryWork', 'Travail')}</SelectItem>
                                <SelectItem value="product">{t('admin.categoryProduct', 'Produit')}</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter>
                        <Button 
                          onClick={handleAddCooperativePhoto} 
                          disabled={uploading || !newMediaCaption}
                          className="flex items-center gap-2"
                        >
                          {uploading ? (
                            <>
                              <Loader2 className="h-4 w-4 animate-spin" />
                              {t('admin.adding', 'Ajout en cours...')}
                            </>
                          ) : (
                            <>
                              <Upload className="h-4 w-4" />
                              {t('admin.addPhoto', 'Ajouter la photo')}
                            </>
                          )}
                        </Button>
                      </CardFooter>
                    </Card>
                  )}
                </TabsContent>
                
                <TabsContent value="videos" className="space-y-4">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t('admin.addVideo', 'Ajouter une vidéo')}</CardTitle>
                      <CardDescription>
                        {t('admin.addVideoDescription', 'Ajoutez des vidéos YouTube ou d\'autres plateformes')}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <Label htmlFor="video-url">{t('admin.videoUrl', 'URL de la vidéo')}</Label>
                        <Input
                          id="video-url"
                          placeholder="https://www.youtube.com/embed/..."
                          value={newVideoUrl}
                          onChange={(e) => setNewVideoUrl(e.target.value)}
                          className="mt-1"
                        />
                        <p className="text-sm text-gray-500 mt-1">
                          {t('admin.videoUrlHelp', 'Pour YouTube, utilisez le format d\'URL incorporable (embed)')}
                        </p>
                      </div>
                      
                      <div>
                        <Label htmlFor="video-caption">{t('admin.videoCaption', 'Légende de la vidéo')}</Label>
                        <Input 
                          id="video-caption"
                          value={newMediaCaption}
                          onChange={(e) => setNewMediaCaption(e.target.value)}
                          placeholder={t('admin.enterCaption', 'Entrez une légende descriptive')}
                          className="mt-1"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor="video-category">{t('admin.videoCategory', 'Catégorie')}</Label>
                        <Select value={newMediaCategory} onValueChange={setNewMediaCategory}>
                          <SelectTrigger id="video-category" className="mt-1">
                            <SelectValue placeholder={t('admin.selectCategory', 'Sélectionnez une catégorie')} />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="plantation">{t('admin.categoryPlantation', 'Plantation')}</SelectItem>
                            <SelectItem value="work">{t('admin.categoryWork', 'Travail')}</SelectItem>
                            <SelectItem value="product">{t('admin.categoryProduct', 'Produit')}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <Button 
                        onClick={handleAddCooperativeVideo}
                        disabled={uploading || !newVideoUrl || !newMediaCaption}
                        className="mt-2 flex items-center gap-2"
                      >
                        {uploading ? (
                          <>
                            <Loader2 className="h-4 w-4 animate-spin" />
                            {t('admin.adding', 'Ajout en cours...')}
                          </>
                        ) : (
                          <>
                            <Upload className="h-4 w-4" />
                            {t('admin.addVideo', 'Ajouter la vidéo')}
                          </>
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                  
                  <div className="grid grid-cols-1 gap-4">
                    {cooperativeMedia[selectedCooperative]?.videos.map(video => (
                      <Card key={video.id}>
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{video.caption}</CardTitle>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 text-red-500 hover:text-red-700 hover:bg-red-50"
                              onClick={() => handleRemoveMedia('videos', video.id)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                          <Badge>{video.category}</Badge>
                        </CardHeader>
                        <CardContent>
                          <div className="relative overflow-hidden pt-[56.25%]">
                            <iframe
                              className="absolute top-0 left-0 w-full h-full border-0"
                              src={video.url}
                              title={video.caption}
                              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                              allowFullScreen
                            ></iframe>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
