import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Product, validateProduct } from '@/types/product';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Plus, Pencil, Trash, Check, X, Image, ImagePlus, Upload } from 'lucide-react';
import { supabase, isOfflineMode } from '@/lib/supabase';

const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Cacao bio premium',
    category: 'cocoa',
    description: 'Cacao bio de qualité exceptionnelle provenant de nos coopératives partenaires.',
    imageUrl: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png',
    featured: true,
    status: 'published',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Café Robusta',
    category: 'coffee',
    description: 'Café Robusta aux notes intenses et au corps généreux.',
    imageUrl: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png',
    featured: false,
    status: 'published',
    createdAt: new Date().toISOString()
  }
];

export default function ProductManager() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedTab, setSelectedTab] = useState('all');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const editFileInputRef = useRef<HTMLInputElement>(null);
  
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    category: 'cocoa',
    description: '',
    imageUrl: '',
    featured: false,
    status: 'draft'
  });

  const saveProductsToLocalStorage = (productsData: Product[]) => {
    try {
      localStorage.setItem('products', JSON.stringify(productsData));
      console.info('Products saved to localStorage');
    } catch (error) {
      console.error('Error saving products to localStorage:', error);
    }
  };

  const loadProducts = async () => {
    setIsLoading(true);
    try {
      const localProductsStr = localStorage.getItem('products');
      if (localProductsStr) {
        try {
          const localProducts = JSON.parse(localProductsStr);
          if (Array.isArray(localProducts) && localProducts.length > 0) {
            console.info("Utilisation des produits depuis localStorage");
            setProducts(localProducts.map(prod => validateProduct(prod)));
            setIsLoading(false);
            return;
          }
        } catch (localError) {
          console.warn("Erreur lors de la lecture des produits depuis localStorage:", localError);
        }
      }
      
      if (!isOfflineMode) {
        try {
          const { data, error } = await supabase
            .from('products')
            .select('*');
          
          if (error) {
            throw error;
          }
          
          if (data && data.length > 0) {
            const validatedProducts = data.map(prod => validateProduct(prod));
            setProducts(validatedProducts);
            saveProductsToLocalStorage(validatedProducts);
            return;
          } else {
            await initializeProducts();
            return;
          }
        } catch (supabaseError) {
          console.error("Supabase query error:", supabaseError);
          throw supabaseError;
        }
      }
      
      console.info("Using initial products data");
      setProducts(initialProducts);
      saveProductsToLocalStorage(initialProducts);
      toast({
        title: t('admin.defaultProducts', 'Produits par défaut'),
        description: t('admin.usingDefaultProducts', 'Utilisation des produits par défaut'),
        variant: 'default'
      });
    } catch (error) {
      console.error("Error loading products:", error);
      setProducts(initialProducts);
      saveProductsToLocalStorage(initialProducts);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorLoadingProducts', 'Erreur lors du chargement des produits'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const initializeProducts = async () => {
    try {
      if (isOfflineMode) {
        console.info("Offline mode: Using initial products");
        setProducts(initialProducts);
        saveProductsToLocalStorage(initialProducts);
        return;
      }
      
      const { data, error } = await supabase
        .from('products')
        .select('*');
      
      if (error) {
        throw error;
      }
      
      if (!data || data.length === 0) {
        const { error: insertError } = await supabase
          .from('products')
          .insert(initialProducts);
        
        if (insertError) {
          throw insertError;
        }
        
        setProducts(initialProducts);
        saveProductsToLocalStorage(initialProducts);
      } else {
        const validatedProducts = data.map(prod => validateProduct(prod));
        setProducts(validatedProducts);
        saveProductsToLocalStorage(validatedProducts);
      }
    } catch (error) {
      console.error("Error initializing products:", error);
      setProducts(initialProducts);
      saveProductsToLocalStorage(initialProducts);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorInitializingProducts', 'Erreur lors de l\'initialisation des produits'),
        variant: 'destructive'
      });
    }
  };

  useEffect(() => {
    loadProducts().catch(error => {
      console.error("Failed to load products initially:", error);
      setProducts(initialProducts);
      setIsLoading(false);
    });
    
    let subscription: { unsubscribe: () => void } | null = null;
    
    if (!isOfflineMode) {
      try {
        subscription = supabase
          .channel('products-changes')
          .on('broadcast', { event: 'products_update' }, () => {
            loadProducts().catch(console.error);
          })
          .subscribe();
      } catch (error) {
        console.error("Error setting up realtime subscription:", error);
      }
    }
    
    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const updateProductsLocally = (updatedProduct: Product, action: 'add' | 'edit' | 'delete' | 'toggle') => {
    let updatedProducts: Product[] = [];
    
    switch (action) {
      case 'add':
        updatedProducts = [...products, updatedProduct];
        break;
      case 'edit':
        updatedProducts = products.map(p => p.id === updatedProduct.id ? updatedProduct : p);
        break;
      case 'delete':
        updatedProducts = products.filter(p => p.id !== updatedProduct.id);
        break;
      case 'toggle':
        updatedProducts = products.map(p => 
          p.id === updatedProduct.id 
            ? {...p, status: p.status === 'published' ? 'draft' : 'published'} 
            : p
        );
        break;
    }
    
    setProducts(updatedProducts);
    saveProductsToLocalStorage(updatedProducts);
  };

  const handleAddProduct = async () => {
    setIsLoading(true);
    try {
      const newProductWithId = validateProduct({
        ...newProduct,
        id: `prod_${Date.now()}`,
        createdAt: new Date().toISOString()
      });
      
      if (!isOfflineMode) {
        const { error } = await supabase
          .from('products')
          .insert(newProductWithId);
        
        if (error) {
          throw error;
        }
      }
      
      updateProductsLocally(newProductWithId, 'add');
      
      setIsAddDialogOpen(false);
      setNewProduct({
        name: '',
        category: 'cocoa',
        description: '',
        imageUrl: '',
        featured: false,
        status: 'draft'
      });
      
      toast({
        title: t('admin.productAdded', 'Produit ajouté'),
        description: t('admin.productAddedDesc', 'Le produit a été ajouté avec succès.')
      });
      
      if (!isOfflineMode) {
        loadProducts().catch(console.error);
      }
    } catch (error) {
      console.error("Error adding product:", error);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorAddingProduct', 'Erreur lors de l\'ajout du produit'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditProduct = async () => {
    if (!selectedProduct) return;
    
    setIsLoading(true);
    try {
      const validatedProduct = validateProduct(selectedProduct);
      
      if (!isOfflineMode) {
        const { error } = await supabase
          .from('products')
          .update(validatedProduct)
          .eq('id', validatedProduct.id);
        
        if (error) {
          throw error;
        }
      }
      
      updateProductsLocally(validatedProduct, 'edit');
      
      setIsEditDialogOpen(false);
      toast({
        title: t('admin.productUpdated', 'Produit mis à jour'),
        description: t('admin.productUpdatedDesc', 'Le produit a été mis à jour avec succès.')
      });
      
      if (!isOfflineMode) {
        loadProducts().catch(console.error);
      }
    } catch (error) {
      console.error("Error updating product:", error);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorUpdatingProduct', 'Erreur lors de la mise à jour du produit'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    setIsLoading(true);
    try {
      const productToDelete = products.find(p => p.id === id);
      if (!productToDelete) {
        throw new Error("Product not found");
      }
      
      if (!isOfflineMode) {
        const { error } = await supabase
          .from('products')
          .delete()
          .eq('id', id);
        
        if (error) {
          throw error;
        }
      }
      
      updateProductsLocally(productToDelete, 'delete');
      
      toast({
        title: t('admin.productDeleted', 'Produit supprimé'),
        description: t('admin.productDeletedDesc', 'Le produit a été supprimé avec succès.')
      });
      
      if (!isOfflineMode) {
        loadProducts().catch(console.error);
      }
    } catch (error) {
      console.error("Error deleting product:", error);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorDeletingProduct', 'Erreur lors de la suppression du produit'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleStatus = async (id: string) => {
    setIsLoading(true);
    try {
      const product = products.find(p => p.id === id);
      if (!product) return;
      
      const newStatus = product.status === 'published' ? 'draft' : 'published';
      const updatedProduct = validateProduct({...product, status: newStatus});
      
      if (!isOfflineMode) {
        const { error } = await supabase
          .from('products')
          .update({ status: newStatus })
          .eq('id', id);
        
        if (error) {
          throw error;
        }
      }
      
      updateProductsLocally(updatedProduct, 'toggle');
      
      toast({
        title: t('admin.statusUpdated', 'Statut mis à jour'),
        description: t(
          'admin.productNowStatus', 
          'Le produit est maintenant {{status}}', 
          { status: newStatus === 'published' ? t('admin.published', 'publié') : t('admin.draft', 'en brouillon') }
        )
      });
      
      if (!isOfflineMode) {
        loadProducts().catch(console.error);
      }
    } catch (error) {
      console.error("Error toggling product status:", error);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorTogglingStatus', 'Erreur lors de la modification du statut'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, isEdit = false) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsLoading(true);
    try {
      let imageUrl = '';
      
      if (!isOfflineMode) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(2, 15)}.${fileExt}`;
        const filePath = `product-images/${fileName}`;
        
        const { data, error } = await supabase
          .storage
          .from('images')
          .upload(filePath, file);
        
        if (error) {
          throw error;
        }
        
        const { data: publicUrlData } = supabase
          .storage
          .from('images')
          .getPublicUrl(filePath);
        
        imageUrl = publicUrlData.publicUrl;
      } else {
        imageUrl = URL.createObjectURL(file);
      }
      
      if (isEdit && selectedProduct) {
        setSelectedProduct({
          ...selectedProduct,
          imageUrl: imageUrl
        });
      } else {
        setNewProduct({
          ...newProduct,
          imageUrl: imageUrl
        });
      }
      
      toast({
        title: t('admin.imageUploaded', 'Image téléchargée'),
        description: t('admin.imageUploadedDesc', 'L\'image a été téléchargée avec succès.')
      });
    } catch (error) {
      console.error("Error uploading image:", error);
      toast({
        title: t('admin.error', 'Erreur'),
        description: t('admin.errorUploadingImage', 'Erreur lors du téléchargement de l\'image'),
        variant: 'destructive'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteImage = (isEdit = false) => {
    if (isEdit && selectedProduct) {
      setSelectedProduct({
        ...selectedProduct,
        imageUrl: '',
      });
    } else {
      setNewProduct({
        ...newProduct,
        imageUrl: '',
      });
    }
    
    toast({
      title: t('admin.imageRemoved', 'Image supprimée'),
      description: t('admin.imageRemovedDesc', 'L\'image a été supprimée du produit.')
    });
  };

  const triggerFileInput = (isEdit = false) => {
    if (isEdit) {
      editFileInputRef.current?.click();
    } else {
      fileInputRef.current?.click();
    }
  };

  const filteredProducts = selectedTab === 'all' 
    ? products 
    : products.filter(product => 
        selectedTab === 'published' 
          ? product.status === 'published' 
          : selectedTab === 'draft' 
            ? product.status === 'draft' 
            : product.category === selectedTab
      );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('admin.productManagement', 'Gestion des produits')}</h2>
          <p className="text-muted-foreground">{t('admin.manageProducts', 'Gérez les produits affichés sur votre site')}</p>
          
          {isOfflineMode && (
            <div className="mt-2 p-2 bg-amber-100 text-amber-800 rounded-md text-sm">
              {t('admin.offlineMode', 'Mode hors ligne: Modifications enregistrées localement')}
            </div>
          )}
        </div>
        
        <Button 
          onClick={() => setIsAddDialogOpen(true)}
          className="flex items-center gap-2"
          disabled={isLoading}
        >
          {isLoading ? (
            <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <Plus className="h-4 w-4" />
          )}
          {t('admin.addProduct', 'Ajouter un produit')}
        </Button>
      </div>
      
      <Tabs defaultValue="all" value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">{t('admin.all', 'Tous')}</TabsTrigger>
          <TabsTrigger value="cocoa">{t('admin.cocoa', 'Cacao')}</TabsTrigger>
          <TabsTrigger value="coffee">{t('admin.coffee', 'Café')}</TabsTrigger>
          <TabsTrigger value="published">{t('admin.published', 'Publiés')}</TabsTrigger>
          <TabsTrigger value="draft">{t('admin.draft', 'Brouillons')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value={selectedTab} className="space-y-4">
          {isLoading && products.length === 0 ? (
            <Card className="p-8 text-center">
              <div className="flex justify-center mb-4">
                <div className="h-8 w-8 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              </div>
              <p className="text-muted-foreground">
                {t('admin.loadingProducts', 'Chargement des produits...')}
              </p>
            </Card>
          ) : filteredProducts.length > 0 ? (
            filteredProducts.map(product => (
              <Card key={product.id} className="overflow-hidden">
                <div className="flex flex-col md:flex-row">
                  <div className="w-full md:w-48 h-48 bg-muted relative group">
                    {product.imageUrl ? (
                      <>
                        <img 
                          src={product.imageUrl} 
                          alt={product.name} 
                          className="w-full h-full object-cover" 
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center opacity-0 group-hover:opacity-100">
                          <Button 
                            variant="secondary" 
                            size="sm" 
                            className="m-1"
                            onClick={() => {
                              setSelectedProduct(product);
                              setIsEditDialogOpen(true);
                            }}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </div>
                      </>
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gray-100">
                        <Image className="h-10 w-10 text-gray-400" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-lg font-semibold">{product.name}</h3>
                          <Badge variant={product.status === 'published' ? 'default' : 'outline'}>
                            {product.status === 'published' 
                              ? t('admin.published', 'Publié') 
                              : t('admin.draft', 'Brouillon')}
                          </Badge>
                          {product.featured && (
                            <Badge variant="secondary">
                              {t('admin.featured', 'Mise en avant')}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {t('admin.category', 'Catégorie')}: {product.category === 'cocoa' 
                            ? t('admin.cocoa', 'Cacao') 
                            : t('admin.coffee', 'Café')}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleToggleStatus(product.id)}
                          disabled={isLoading}
                        >
                          {product.status === 'published' 
                            ? t('admin.unpublish', 'Dépublier') 
                            : t('admin.publish', 'Publier')}
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsEditDialogOpen(true);
                          }}
                          disabled={isLoading}
                        >
                          <Pencil className="h-4 w-4 mr-1" />
                          {t('admin.edit', 'Modifier')}
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => handleDeleteProduct(product.id)}
                          disabled={isLoading}
                        >
                          <Trash className="h-4 w-4 mr-1" />
                          {t('admin.delete', 'Supprimer')}
                        </Button>
                      </div>
                    </div>
                    <p className="mt-2">{product.description}</p>
                  </div>
                </div>
              </Card>
            ))
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground mb-4">
                {t('admin.noProductsFound', 'Aucun produit trouvé')}
              </p>
              <Button onClick={() => setIsAddDialogOpen(true)} disabled={isLoading}>
                <Plus className="h-4 w-4 mr-1" />
                {t('admin.addProduct', 'Ajouter un produit')}
              </Button>
            </Card>
          )}
        </TabsContent>
      </Tabs>
      
      <input 
        type="file" 
        ref={fileInputRef} 
        style={{ display: 'none' }} 
        accept="image/*" 
        onChange={(e) => handleFileChange(e)}
      />
      
      <input 
        type="file" 
        ref={editFileInputRef} 
        style={{ display: 'none' }} 
        accept="image/*" 
        onChange={(e) => handleFileChange(e, true)}
      />
      
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{t('admin.addProduct', 'Ajouter un produit')}</DialogTitle>
            <DialogDescription>
              {t('admin.addProductDescription', 'Créez un nouveau produit à afficher sur le site')}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">{t('admin.productName', 'Nom du produit')}</Label>
              <Input 
                id="name" 
                value={newProduct.name}
                onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="category">{t('admin.category', 'Catégorie')}</Label>
              <Select 
                value={newProduct.category} 
                onValueChange={(value: 'cocoa' | 'coffee') => setNewProduct({...newProduct, category: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('admin.selectCategory', 'Sélectionner une catégorie')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cocoa">{t('admin.cocoa', 'Cacao')}</SelectItem>
                  <SelectItem value="coffee">{t('admin.coffee', 'Café')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="description">{t('admin.description', 'Description')}</Label>
              <Textarea 
                id="description" 
                value={newProduct.description}
                onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="imageUpload">{t('admin.productImage', 'Image du produit')}</Label>
              <div className="flex items-center gap-2">
                {newProduct.imageUrl ? (
                  <div className="relative w-40 h-40 border rounded">
                    <img
                      src={newProduct.imageUrl}
                      alt="Preview"
                      className="w-full h-full object-cover rounded"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-1 right-1"
                      onClick={() => handleDeleteImage()}
                      disabled={isLoading}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <Button onClick={() => triggerFileInput()} className="flex items-center gap-2" disabled={isLoading}>
                    <Upload className="h-4 w-4" />
                    {t('admin.uploadImage', 'Télécharger une image')}
                  </Button>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Label htmlFor="featured" className="flex-grow">{t('admin.featured', 'Mise en avant')}</Label>
              <input 
                id="featured" 
                type="checkbox" 
                checked={newProduct.featured}
                onChange={(e) => setNewProduct({...newProduct, featured: e.target.checked})}
                className="h-4 w-4"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="status">{t('admin.status', 'Statut')}</Label>
              <Select 
                value={newProduct.status} 
                onValueChange={(value: 'draft' | 'published') => setNewProduct({...newProduct, status: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder={t('admin.selectStatus', 'Sélectionner un statut')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">{t('admin.draft', 'Brouillon')}</SelectItem>
                  <SelectItem value="published">{t('admin.published', 'Publié')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)} disabled={isLoading}>
              {t('admin.cancel', 'Annuler')}
            </Button>
            <Button onClick={handleAddProduct} disabled={!newProduct.name || isLoading}>
              {isLoading ? (
                <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
              ) : null}
              {t('admin.add', 'Ajouter')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>{t('admin.editProduct', 'Modifier le produit')}</DialogTitle>
            <DialogDescription>
              {t('admin.editProductDescription', 'Modifiez les informations du produit')}
            </DialogDescription>
          </DialogHeader>
          
          {selectedProduct && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-name">{t('admin.productName', 'Nom du produit')}</Label>
                <Input 
                  id="edit-name" 
                  value={selectedProduct.name}
                  onChange={(e) => setSelectedProduct({...selectedProduct, name: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-category">{t('admin.category', 'Catégorie')}</Label>
                <Select 
                  value={selectedProduct.category} 
                  onValueChange={(value: 'cocoa' | 'coffee') => setSelectedProduct({...selectedProduct, category: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t('admin.selectCategory', 'Sélectionner une catégorie')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cocoa">{t('admin.cocoa', 'Cacao')}</SelectItem>
                    <SelectItem value="coffee">{t('admin.coffee', 'Café')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-description">{t('admin.description', 'Description')}</Label>
                <Textarea 
                  id="edit-description" 
                  value={selectedProduct.description}
                  onChange={(e) => setSelectedProduct({...selectedProduct, description: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-imageUpload">{t('admin.productImage', 'Image du produit')}</Label>
                <div className="flex items-center gap-2">
                  {selectedProduct.imageUrl ? (
                    <div className="relative w-40 h-40 border rounded">
                      <img
                        src={selectedProduct.imageUrl}
                        alt="Preview"
                        className="w-full h-full object-cover rounded"
                      />
                      <Button
                        variant="destructive"
                        size="sm"
                        className="absolute top-1 right-1"
                        onClick={() => handleDeleteImage(true)}
                        disabled={isLoading}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button onClick={() => triggerFileInput(true)} className="flex items-center gap-2" disabled={isLoading}>
                      <Upload className="h-4 w-4" />
                      {t('admin.uploadImage', 'Télécharger une image')}
                    </Button>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Label htmlFor="edit-featured" className="flex-grow">{t('admin.featured', 'Mise en avant')}</Label>
                <input 
                  id="edit-featured" 
                  type="checkbox" 
                  checked={selectedProduct.featured}
                  onChange={(e) => setSelectedProduct({...selectedProduct, featured: e.target.checked})}
                  className="h-4 w-4"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-status">{t('admin.status', 'Statut')}</Label>
                <Select 
                  value={selectedProduct.status} 
                  onValueChange={(value: 'draft' | 'published') => setSelectedProduct({...selectedProduct, status: value})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder={t('admin.selectStatus', 'Sélectionner un statut')} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">{t('admin.draft', 'Brouillon')}</SelectItem>
                    <SelectItem value="published">{t('admin.published', 'Publié')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} disabled={isLoading}>
              {t('admin.cancel', 'Annuler')}
            </Button>
            <Button onClick={handleEditProduct} disabled={!selectedProduct?.name || isLoading}>
              {isLoading ? (
                <div className="h-4 w-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2"></div>
              ) : (
                <Check className="h-4 w-4 mr-1" />
              )}
              {t('admin.save', 'Enregistrer')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
