
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';

export default function SettingsPanel() {
  const { t } = useTranslation();
  const { toast } = useToast();
  
  // États pour les formulaires
  const [siteName, setSiteName] = useState('Africa Market Export');
  const [siteDescription, setSiteDescription] = useState('Plateforme de commerce équitable pour les produits africains');
  const [contactEmail, setContactEmail] = useState('contact@africamarketexport.com');
  const [logoUrl, setLogoUrl] = useState('/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png');
  
  const [analyticsId, setAnalyticsId] = useState('');
  const [apiKey, setApiKey] = useState('');
  
  // Nouveaux états
  const [registrationEmail, setRegistrationEmail] = useState('registrations@africamarketexport.com');
  const [cooperativeDescription, setCooperativeDescription] = useState(
    'Nos coopératives partenaires jouent un rôle essentiel dans notre chaîne d\'approvisionnement. Elles garantissent la qualité exceptionnelle de notre cacao tout en assurant des pratiques durables et équitables.'
  );
  const [cooperativeImpact, setCooperativeImpact] = useState(
    'Nos coopératives partenaires créent un impact positif significatif dans leurs communautés. Grâce au commerce équitable, les producteurs reçoivent une rémunération juste qui leur permet d\'améliorer leurs conditions de vie.'
  );
  const [cooperativeQuality, setCooperativeQuality] = useState(
    'La qualité exceptionnelle de notre cacao provient du savoir-faire traditionnel de nos producteurs, enrichi par des techniques modernes de fermentation et de séchage qui développent des profils aromatiques complexes.'
  );
  const [cooperativeSustainability, setCooperativeSustainability] = useState(
    'Nos coopératives s\'engagent pour un cacao respectueux de l\'environnement. Beaucoup pratiquent l\'agroforesterie, cultivant le cacao sous couvert forestier pour préserver la biodiversité et lutter contre la déforestation.'
  );
  
  // Fonction pour sauvegarder les paramètres généraux
  const saveGeneralSettings = () => {
    toast({
      title: t('admin.settingsSaved', 'Paramètres enregistrés'),
      description: t('admin.generalSettingsUpdated', 'Les paramètres généraux ont été mis à jour avec succès.')
    });
  };
  
  // Fonction pour sauvegarder les paramètres d'intégration
  const saveIntegrationSettings = () => {
    toast({
      title: t('admin.settingsSaved', 'Paramètres enregistrés'),
      description: t('admin.integrationSettingsUpdated', 'Les paramètres d\'intégration ont été mis à jour avec succès.')
    });
  };

  // Fonction pour sauvegarder les paramètres de coopératives
  const saveCooperativeSettings = () => {
    toast({
      title: t('admin.settingsSaved', 'Paramètres enregistrés'),
      description: t('admin.cooperativeSettingsUpdated', 'Les informations des coopératives ont été mises à jour avec succès.')
    });
  };
  
  return (
    <div className="space-y-6">
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="general">{t('admin.generalTab', 'Général')}</TabsTrigger>
          <TabsTrigger value="cooperatives">{t('admin.cooperativesTab', 'Coopératives')}</TabsTrigger>
          <TabsTrigger value="integrations">{t('admin.integrationsTab', 'Intégrations')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.generalSettings', 'Paramètres généraux')}</CardTitle>
              <CardDescription>
                {t('admin.generalSettingsDescription', 'Configurez les paramètres de base de votre site')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="site-name">{t('admin.siteName', 'Nom du site')}</Label>
                <Input
                  id="site-name"
                  value={siteName}
                  onChange={(e) => setSiteName(e.target.value)}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="site-description">{t('admin.siteDescription', 'Description du site')}</Label>
                <Textarea
                  id="site-description"
                  value={siteDescription}
                  onChange={(e) => setSiteDescription(e.target.value)}
                  rows={3}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="contact-email">{t('admin.contactEmail', 'Email de contact')}</Label>
                <Input
                  id="contact-email"
                  type="email"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="registration-email">{t('admin.registrationEmail', 'Email de réception des enregistrements')}</Label>
                <Input
                  id="registration-email"
                  type="email"
                  value={registrationEmail}
                  onChange={(e) => setRegistrationEmail(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  {t('admin.registrationEmailDescription', 'Adresse email qui recevra les notifications lors de l\'enregistrement de nouvelles coopératives')}
                </p>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="logo-url">{t('admin.logoUrl', 'URL du logo')}</Label>
                <Input
                  id="logo-url"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                />
                {logoUrl && (
                  <div className="mt-2">
                    <p className="text-sm text-muted-foreground mb-1">{t('admin.preview', 'Aperçu')}:</p>
                    <img src={logoUrl} alt="Logo" className="h-16 object-contain" />
                  </div>
                )}
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveGeneralSettings}>
                {t('admin.saveSettings', 'Enregistrer les paramètres')}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="cooperatives" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.cooperativesSettings', 'Paramètres des coopératives')}</CardTitle>
              <CardDescription>
                {t('admin.cooperativesSettingsDescription', 'Configurez les informations affichées sur la page des coopératives')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="cooperative-description">{t('admin.mainDescription', 'Description principale')}</Label>
                <Textarea
                  id="cooperative-description"
                  value={cooperativeDescription}
                  onChange={(e) => setCooperativeDescription(e.target.value)}
                  rows={3}
                />
                <p className="text-xs text-muted-foreground">
                  {t('admin.mainDescriptionHelp', 'Cette description apparaît en haut de la page des coopératives')}
                </p>
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="cooperative-impact">{t('admin.impactDescription', 'Description de l\'impact social')}</Label>
                <Textarea
                  id="cooperative-impact"
                  value={cooperativeImpact}
                  onChange={(e) => setCooperativeImpact(e.target.value)}
                  rows={3}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="cooperative-quality">{t('admin.qualityDescription', 'Description de la qualité')}</Label>
                <Textarea
                  id="cooperative-quality"
                  value={cooperativeQuality}
                  onChange={(e) => setCooperativeQuality(e.target.value)}
                  rows={3}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="cooperative-sustainability">{t('admin.sustainabilityDescription', 'Description de la durabilité')}</Label>
                <Textarea
                  id="cooperative-sustainability"
                  value={cooperativeSustainability}
                  onChange={(e) => setCooperativeSustainability(e.target.value)}
                  rows={3}
                />
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveCooperativeSettings}>
                {t('admin.saveCooperativeSettings', 'Enregistrer les informations')}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.integrationSettings', 'Paramètres d\'intégration')}</CardTitle>
              <CardDescription>
                {t('admin.integrationSettingsDescription', 'Configurez les intégrations avec des services externes')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="analytics-id">{t('admin.analyticsId', 'ID Google Analytics')}</Label>
                <Input
                  id="analytics-id"
                  value={analyticsId}
                  onChange={(e) => setAnalyticsId(e.target.value)}
                  placeholder="UA-XXXXXXXXX-X ou G-XXXXXXXXXX"
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="api-key">{t('admin.apiKey', 'Clé API')}</Label>
                <Input
                  id="api-key"
                  value={apiKey}
                  onChange={(e) => setApiKey(e.target.value)}
                  type="password"
                  placeholder="xxxx-xxxx-xxxx-xxxx"
                />
                <p className="text-xs text-muted-foreground">
                  {t('admin.apiKeyDescription', 'Utilisée pour l\'intégration avec des services externes')}
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={saveIntegrationSettings}>
                {t('admin.saveSettings', 'Enregistrer les paramètres')}
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>{t('admin.dangerZone', 'Zone dangereuse')}</CardTitle>
              <CardDescription>
                {t('admin.dangerZoneDescription', 'Actions irréversibles qui peuvent affecter votre site')}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border border-destructive/20 rounded-md p-4">
                <h3 className="font-medium text-destructive mb-2">
                  {t('admin.resetSettings', 'Réinitialiser tous les paramètres')}
                </h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {t('admin.resetSettingsDescription', 'Cette action réinitialisera tous les paramètres à leurs valeurs par défaut.')}
                </p>
                <Button 
                  variant="destructive"
                  onClick={() => {
                    toast({
                      title: t('admin.comingSoon', 'Fonctionnalité à venir'),
                      description: t('admin.resetNotAvailable', 'La réinitialisation des paramètres n\'est pas encore disponible.')
                    });
                  }}
                >
                  {t('admin.resetSettings', 'Réinitialiser les paramètres')}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
