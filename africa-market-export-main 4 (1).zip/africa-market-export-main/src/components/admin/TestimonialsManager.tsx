
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Testimonial, SuccessStory } from '@/types/cooperative';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { PlusIcon, TrashIcon, PencilIcon, MessageSquare, Award } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';

interface TestimonialsManagerProps {
  testimonials: Testimonial[];
  successStories: SuccessStory[];
  onUpdateTestimonials: (testimonials: Testimonial[]) => void;
  onUpdateSuccessStories: (stories: SuccessStory[]) => void;
}

export default function TestimonialsManager({ 
  testimonials = [], 
  successStories = [], 
  onUpdateTestimonials, 
  onUpdateSuccessStories 
}: TestimonialsManagerProps) {
  const { t } = useTranslation();
  
  // State for testimonials
  const [isAddTestimonialOpen, setIsAddTestimonialOpen] = useState(false);
  const [isEditTestimonialOpen, setIsEditTestimonialOpen] = useState(false);
  const [selectedTestimonial, setSelectedTestimonial] = useState<Testimonial | null>(null);
  const [newTestimonial, setNewTestimonial] = useState<Partial<Testimonial>>({
    personName: '',
    role: '',
    content: '',
    date: format(new Date(), 'yyyy-MM-dd')
  });
  
  // State for success stories
  const [isAddStoryOpen, setIsAddStoryOpen] = useState(false);
  const [isEditStoryOpen, setIsEditStoryOpen] = useState(false);
  const [selectedStory, setSelectedStory] = useState<SuccessStory | null>(null);
  const [newStory, setNewStory] = useState<Partial<SuccessStory>>({
    title: '',
    description: '',
    imageUrl: '',
    date: format(new Date(), 'yyyy-MM-dd'),
    impact: ''
  });
  
  // Testimonial handlers
  const handleAddTestimonial = () => {
    const id = `t${Date.now()}`;
    const testimonial: Testimonial = {
      id,
      personName: newTestimonial.personName || '',
      role: newTestimonial.role || '',
      content: newTestimonial.content || '',
      date: newTestimonial.date || format(new Date(), 'yyyy-MM-dd')
    };
    
    const updatedTestimonials = [...testimonials, testimonial];
    onUpdateTestimonials(updatedTestimonials);
    
    setIsAddTestimonialOpen(false);
    setNewTestimonial({
      personName: '',
      role: '',
      content: '',
      date: format(new Date(), 'yyyy-MM-dd')
    });
  };
  
  const handleUpdateTestimonial = () => {
    if (!selectedTestimonial) return;
    
    const updatedTestimonials = testimonials.map(item => 
      item.id === selectedTestimonial.id ? selectedTestimonial : item
    );
    
    onUpdateTestimonials(updatedTestimonials);
    setIsEditTestimonialOpen(false);
  };
  
  const handleDeleteTestimonial = (id: string) => {
    const updatedTestimonials = testimonials.filter(item => item.id !== id);
    onUpdateTestimonials(updatedTestimonials);
  };
  
  // Success story handlers
  const handleAddStory = () => {
    const id = `s${Date.now()}`;
    const story: SuccessStory = {
      id,
      title: newStory.title || '',
      description: newStory.description || '',
      imageUrl: newStory.imageUrl,
      date: newStory.date || format(new Date(), 'yyyy-MM-dd'),
      impact: newStory.impact
    };
    
    const updatedStories = [...successStories, story];
    onUpdateSuccessStories(updatedStories);
    
    setIsAddStoryOpen(false);
    setNewStory({
      title: '',
      description: '',
      imageUrl: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      impact: ''
    });
  };
  
  const handleUpdateStory = () => {
    if (!selectedStory) return;
    
    const updatedStories = successStories.map(item => 
      item.id === selectedStory.id ? selectedStory : item
    );
    
    onUpdateSuccessStories(updatedStories);
    setIsEditStoryOpen(false);
  };
  
  const handleDeleteStory = (id: string) => {
    const updatedStories = successStories.filter(item => item.id !== id);
    onUpdateSuccessStories(updatedStories);
  };
  
  return (
    <div className="space-y-6">
      {/* Testimonials Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            {t('admin.testimonials', 'Témoignages')}
          </CardTitle>
          <CardDescription>
            {t('admin.testimonialsDescription', 'Gérez les témoignages des membres et partenaires de la coopérative')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-muted-foreground">
              {testimonials.length} {t('admin.testimonialsCount', 'témoignages')}
            </span>
            <Dialog open={isAddTestimonialOpen} onOpenChange={setIsAddTestimonialOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="flex items-center gap-1">
                  <PlusIcon className="h-4 w-4" />
                  {t('admin.addTestimonial', 'Ajouter un témoignage')}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{t('admin.newTestimonial', 'Nouveau témoignage')}</DialogTitle>
                  <DialogDescription>
                    {t('admin.newTestimonialDescription', 'Ajoutez un témoignage pour mettre en avant l\'expérience des membres')}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="person-name">{t('admin.personName', 'Nom de la personne')}</Label>
                    <Input 
                      id="person-name" 
                      value={newTestimonial.personName} 
                      onChange={(e) => setNewTestimonial({...newTestimonial, personName: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="person-role">{t('admin.personRole', 'Rôle ou fonction')}</Label>
                    <Input 
                      id="person-role" 
                      value={newTestimonial.role} 
                      onChange={(e) => setNewTestimonial({...newTestimonial, role: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="testimonial-content">{t('admin.testimonialContent', 'Contenu du témoignage')}</Label>
                    <Textarea 
                      id="testimonial-content" 
                      rows={4}
                      value={newTestimonial.content} 
                      onChange={(e) => setNewTestimonial({...newTestimonial, content: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="testimonial-date">{t('admin.date', 'Date')}</Label>
                    <Input 
                      id="testimonial-date" 
                      type="date"
                      value={newTestimonial.date} 
                      onChange={(e) => setNewTestimonial({...newTestimonial, date: e.target.value})}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddTestimonialOpen(false)}>
                    {t('admin.cancel', 'Annuler')}
                  </Button>
                  <Button onClick={handleAddTestimonial}>
                    {t('admin.add', 'Ajouter')}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          <ScrollArea className="h-[240px] rounded-md border p-4">
            {testimonials.length > 0 ? (
              <div className="space-y-4">
                {testimonials.map((testimonial) => (
                  <div key={testimonial.id} className="p-3 border rounded-md bg-card">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-medium">{testimonial.personName}</h4>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => {
                            setSelectedTestimonial(testimonial);
                            setIsEditTestimonialOpen(true);
                          }}
                        >
                          <PencilIcon className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive"
                          onClick={() => handleDeleteTestimonial(testimonial.id)}
                        >
                          <TrashIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm italic">"{testimonial.content}"</p>
                    <p className="text-xs text-muted-foreground mt-2">
                      {new Date(testimonial.date).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex justify-center items-center h-full text-muted-foreground">
                {t('admin.noTestimonials', 'Aucun témoignage disponible')}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
      
      {/* Edit Testimonial Dialog */}
      {selectedTestimonial && (
        <Dialog open={isEditTestimonialOpen} onOpenChange={setIsEditTestimonialOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t('admin.editTestimonial', 'Modifier le témoignage')}</DialogTitle>
              <DialogDescription>
                {t('admin.editTestimonialDescription', 'Modifiez les informations du témoignage')}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-person-name">{t('admin.personName', 'Nom de la personne')}</Label>
                <Input 
                  id="edit-person-name" 
                  value={selectedTestimonial.personName} 
                  onChange={(e) => setSelectedTestimonial({...selectedTestimonial, personName: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-person-role">{t('admin.personRole', 'Rôle ou fonction')}</Label>
                <Input 
                  id="edit-person-role" 
                  value={selectedTestimonial.role} 
                  onChange={(e) => setSelectedTestimonial({...selectedTestimonial, role: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-testimonial-content">{t('admin.testimonialContent', 'Contenu du témoignage')}</Label>
                <Textarea 
                  id="edit-testimonial-content" 
                  rows={4}
                  value={selectedTestimonial.content} 
                  onChange={(e) => setSelectedTestimonial({...selectedTestimonial, content: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-testimonial-date">{t('admin.date', 'Date')}</Label>
                <Input 
                  id="edit-testimonial-date" 
                  type="date"
                  value={selectedTestimonial.date} 
                  onChange={(e) => setSelectedTestimonial({...selectedTestimonial, date: e.target.value})}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditTestimonialOpen(false)}>
                {t('admin.cancel', 'Annuler')}
              </Button>
              <Button onClick={handleUpdateTestimonial}>
                {t('admin.save', 'Enregistrer')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
      
      <Separator />
      
      {/* Success Stories Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="h-5 w-5" />
            {t('admin.successStories', 'Histoires de réussite')}
          </CardTitle>
          <CardDescription>
            {t('admin.successStoriesDescription', 'Gérez les histoires de réussite et réalisations de la coopérative')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-muted-foreground">
              {successStories.length} {t('admin.successStoriesCount', 'histoires de réussite')}
            </span>
            <Dialog open={isAddStoryOpen} onOpenChange={setIsAddStoryOpen}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="flex items-center gap-1">
                  <PlusIcon className="h-4 w-4" />
                  {t('admin.addSuccessStory', 'Ajouter une histoire de réussite')}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{t('admin.newSuccessStory', 'Nouvelle histoire de réussite')}</DialogTitle>
                  <DialogDescription>
                    {t('admin.newSuccessStoryDescription', 'Ajoutez une histoire de réussite pour mettre en avant les accomplissements')}
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <Label htmlFor="story-title">{t('admin.title', 'Titre')}</Label>
                    <Input 
                      id="story-title" 
                      value={newStory.title} 
                      onChange={(e) => setNewStory({...newStory, title: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="story-description">{t('admin.description', 'Description')}</Label>
                    <Textarea 
                      id="story-description" 
                      rows={4}
                      value={newStory.description} 
                      onChange={(e) => setNewStory({...newStory, description: e.target.value})}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="story-impact">{t('admin.impact', 'Impact')}</Label>
                    <Input 
                      id="story-impact" 
                      value={newStory.impact || ''} 
                      onChange={(e) => setNewStory({...newStory, impact: e.target.value})}
                      placeholder={t('admin.impactPlaceholder', 'ex: 50 familles bénéficiaires')}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="story-image">{t('admin.imageUrl', 'URL de l\'image')}</Label>
                    <Input 
                      id="story-image" 
                      value={newStory.imageUrl || ''} 
                      onChange={(e) => setNewStory({...newStory, imageUrl: e.target.value})}
                      placeholder="/lovable-uploads/image.png"
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="story-date">{t('admin.date', 'Date')}</Label>
                    <Input 
                      id="story-date" 
                      type="date"
                      value={newStory.date} 
                      onChange={(e) => setNewStory({...newStory, date: e.target.value})}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddStoryOpen(false)}>
                    {t('admin.cancel', 'Annuler')}
                  </Button>
                  <Button onClick={handleAddStory}>
                    {t('admin.add', 'Ajouter')}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
          
          <ScrollArea className="h-[320px] rounded-md border p-4">
            {successStories.length > 0 ? (
              <div className="space-y-4">
                {successStories.map((story) => (
                  <div key={story.id} className="p-3 border rounded-md bg-card">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-medium">{story.title}</h4>
                        <p className="text-xs text-muted-foreground">
                          {new Date(story.date).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8"
                          onClick={() => {
                            setSelectedStory(story);
                            setIsEditStoryOpen(true);
                          }}
                        >
                          <PencilIcon className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive"
                          onClick={() => handleDeleteStory(story.id)}
                        >
                          <TrashIcon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {story.imageUrl && (
                      <div className="aspect-video rounded-md overflow-hidden mb-2">
                        <img 
                          src={story.imageUrl} 
                          alt={story.title} 
                          className="h-full w-full object-cover"
                        />
                      </div>
                    )}
                    
                    <p className="text-sm">{story.description}</p>
                    
                    {story.impact && (
                      <div className="mt-2 inline-block bg-muted px-2 py-1 rounded-md text-xs">
                        {t('admin.impact', 'Impact')}: {story.impact}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex justify-center items-center h-full text-muted-foreground">
                {t('admin.noSuccessStories', 'Aucune histoire de réussite disponible')}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
      
      {/* Edit Success Story Dialog */}
      {selectedStory && (
        <Dialog open={isEditStoryOpen} onOpenChange={setIsEditStoryOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t('admin.editSuccessStory', 'Modifier l\'histoire de réussite')}</DialogTitle>
              <DialogDescription>
                {t('admin.editSuccessStoryDescription', 'Modifiez les informations de l\'histoire de réussite')}
              </DialogDescription>
            </DialogHeader>
            
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-story-title">{t('admin.title', 'Titre')}</Label>
                <Input 
                  id="edit-story-title" 
                  value={selectedStory.title} 
                  onChange={(e) => setSelectedStory({...selectedStory, title: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-story-description">{t('admin.description', 'Description')}</Label>
                <Textarea 
                  id="edit-story-description" 
                  rows={4}
                  value={selectedStory.description} 
                  onChange={(e) => setSelectedStory({...selectedStory, description: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-story-impact">{t('admin.impact', 'Impact')}</Label>
                <Input 
                  id="edit-story-impact" 
                  value={selectedStory.impact || ''} 
                  onChange={(e) => setSelectedStory({...selectedStory, impact: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-story-image">{t('admin.imageUrl', 'URL de l\'image')}</Label>
                <Input 
                  id="edit-story-image" 
                  value={selectedStory.imageUrl || ''} 
                  onChange={(e) => setSelectedStory({...selectedStory, imageUrl: e.target.value})}
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="edit-story-date">{t('admin.date', 'Date')}</Label>
                <Input 
                  id="edit-story-date" 
                  type="date"
                  value={selectedStory.date} 
                  onChange={(e) => setSelectedStory({...selectedStory, date: e.target.value})}
                />
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditStoryOpen(false)}>
                {t('admin.cancel', 'Annuler')}
              </Button>
              <Button onClick={handleUpdateStory}>
                {t('admin.save', 'Enregistrer')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
