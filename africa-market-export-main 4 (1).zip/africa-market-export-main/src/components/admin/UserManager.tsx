
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { UserPlus, User, Users, Search, Trash, Settings, Check, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

// Types pour les utilisateurs
interface UserItem {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'editor' | 'viewer';
  lastLogin: Date | null;
  status: 'active' | 'inactive';
}

// Données de démonstration
const demoUsers: UserItem[] = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    role: 'admin',
    lastLogin: new Date('2023-08-15T10:30:00'),
    status: 'active',
  },
  {
    id: '2',
    name: 'Editor User',
    email: 'editor@example.com',
    role: 'editor',
    lastLogin: new Date('2023-08-12T15:45:00'),
    status: 'active',
  },
  {
    id: '3',
    name: 'Viewer User',
    email: 'viewer@example.com',
    role: 'viewer',
    lastLogin: new Date('2023-08-10T09:15:00'),
    status: 'active',
  },
  {
    id: '4',
    name: 'Inactive User',
    email: 'inactive@example.com',
    role: 'viewer',
    lastLogin: null,
    status: 'inactive',
  },
];

export default function UserManager() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [users, setUsers] = useState<UserItem[]>(demoUsers);
  const [filter, setFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Fonction pour changer le statut d'un utilisateur
  const toggleUserStatus = (id: string) => {
    setUsers(users.map(user => 
      user.id === id 
        ? { 
            ...user, 
            status: user.status === 'active' ? 'inactive' : 'active',
          } 
        : user
    ));
    
    const newStatus = users.find(user => user.id === id)?.status === 'active' ? 'inactive' : 'active';
    
    toast({
      title: t('admin.userStatusUpdated', 'Statut utilisateur mis à jour'),
      description: t(
        'admin.userIsNowStatus', 
        'L\'utilisateur est maintenant {{status}}', 
        { status: newStatus === 'active' ? t('admin.active', 'actif') : t('admin.inactive', 'inactif') }
      ),
    });
  };

  // Fonction pour changer le rôle d'un utilisateur
  const changeUserRole = (id: string, newRole: 'admin' | 'editor' | 'viewer') => {
    setUsers(users.map(user => 
      user.id === id 
        ? { ...user, role: newRole } 
        : user
    ));
    
    toast({
      title: t('admin.roleUpdated', 'Rôle mis à jour'),
      description: t(
        'admin.userRoleChanged', 
        'Le rôle de l\'utilisateur a été changé pour {{role}}', 
        { role: t(`admin.${newRole}`, newRole) }
      ),
    });
  };
  
  // Fonction pour supprimer un utilisateur
  const deleteUser = (id: string) => {
    setUsers(users.filter(user => user.id !== id));
    toast({
      title: t('admin.userDeleted', 'Utilisateur supprimé'),
      description: t('admin.userDeletedSuccess', 'L\'utilisateur a été supprimé avec succès.'),
    });
  };
  
  // Filtrer les utilisateurs
  let filteredUsers = users;
  
  if (filter !== 'all') {
    filteredUsers = users.filter(user => 
      filter === 'active' || filter === 'inactive' 
        ? user.status === filter
        : user.role === filter
    );
  }
  
  // Recherche d'utilisateurs
  if (searchQuery.trim() !== '') {
    const query = searchQuery.toLowerCase();
    filteredUsers = filteredUsers.filter(user => 
      user.name.toLowerCase().includes(query) || 
      user.email.toLowerCase().includes(query)
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold">{t('admin.userManagement', 'Gestion des utilisateurs')}</h2>
          <p className="text-muted-foreground">{t('admin.manageUserAccounts', 'Gérez les comptes d\'utilisateurs')}</p>
        </div>
        
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                {t('admin.filter', 'Filtrer')}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-background">
              <DropdownMenuItem onClick={() => setFilter('all')}>{t('admin.all', 'Tous')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('admin')}>{t('admin.admins', 'Administrateurs')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('editor')}>{t('admin.editors', 'Éditeurs')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('viewer')}>{t('admin.viewers', 'Visiteurs')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('active')}>{t('admin.active', 'Actifs')}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setFilter('inactive')}>{t('admin.inactive', 'Inactifs')}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <Button onClick={() => toast({
            title: t('admin.comingSoon', 'Fonctionnalité à venir'),
            description: t('admin.addUserNotAvailable', 'L\'ajout d\'utilisateur n\'est pas encore disponible.')
          })}>
            <UserPlus className="mr-2 h-4 w-4" />
            {t('admin.addUser', 'Ajouter un utilisateur')}
          </Button>
        </div>
      </div>
      
      <div className="flex items-center">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder={t('admin.searchUsers', 'Rechercher des utilisateurs...')}
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      <div className="grid gap-4">
        {filteredUsers.map(user => (
          <Card key={user.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="rounded-full bg-muted p-2">
                    <User className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle>{user.name}</CardTitle>
                    <CardDescription>{user.email}</CardDescription>
                  </div>
                </div>
                <div className="flex items-center">
                  <span className={`px-2 py-1 rounded-full text-xs mr-2 ${
                    user.status === 'active' 
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                  }`}>
                    {user.status === 'active' 
                      ? t('admin.active', 'Actif') 
                      : t('admin.inactive', 'Inactif')}
                  </span>
                  <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100">
                    {t(`admin.${user.role}`, user.role)}
                  </span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                {t('admin.lastLogin', 'Dernière connexion')}: {
                  user.lastLogin 
                    ? user.lastLogin.toLocaleString() 
                    : t('admin.neverLoggedIn', 'Jamais connecté')
                }
              </p>
            </CardContent>
            <CardFooter className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => toggleUserStatus(user.id)}>
                {user.status === 'active' 
                  ? t('admin.deactivate', 'Désactiver') 
                  : t('admin.activate', 'Activer')}
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline">
                    <Settings className="mr-2 h-4 w-4" />
                    {t('admin.changeRole', 'Changer de rôle')}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-background">
                  <DropdownMenuItem onClick={() => changeUserRole(user.id, 'admin')}>
                    {t('admin.admin', 'Administrateur')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => changeUserRole(user.id, 'editor')}>
                    {t('admin.editor', 'Éditeur')}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => changeUserRole(user.id, 'viewer')}>
                    {t('admin.viewer', 'Visiteur')}
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <Button variant="destructive" onClick={() => deleteUser(user.id)}>
                <Trash className="mr-2 h-4 w-4" />
                {t('admin.delete', 'Supprimer')}
              </Button>
            </CardFooter>
          </Card>
        ))}
        
        {filteredUsers.length === 0 && (
          <Card className="py-8">
            <CardContent className="flex flex-col items-center justify-center text-center">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">
                {searchQuery.trim() !== '' 
                  ? t('admin.noUsersMatchSearch', 'Aucun utilisateur ne correspond à votre recherche')
                  : t('admin.noUsersFound', 'Aucun utilisateur trouvé pour ce filtre')}
              </p>
              <Button variant="outline" onClick={() => {
                setFilter('all');
                setSearchQuery('');
              }}>
                {t('admin.showAllUsers', 'Afficher tous les utilisateurs')}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
