
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { LockKeyhole, LogOut } from 'lucide-react';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';

export default function NavbarAuthMenu() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { isAuthenticated, user, logout } = useAuth();
  const { toast } = useToast();

  const handleLogout = () => {
    logout();
    toast({
      title: t('auth.logoutSuccess', 'Déconnexion réussie'),
      description: t('auth.loggedOut', 'Vous avez été déconnecté'),
    });
    navigate('/');
  };

  return (
    <div className="flex items-center gap-2">
      {isAuthenticated ? (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="flex items-center gap-2">
              <LockKeyhole className="h-4 w-4" />
              {user?.name || t('navbar.admin', 'Administration')}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>{t('auth.loggedInAs', 'Connecté en tant que')}</DropdownMenuLabel>
            <DropdownMenuLabel className="font-normal text-xs">{user?.email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('/admin')}>
              {t('navbar.admin', 'Administration')}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              {t('auth.logout', 'Déconnexion')}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      ) : (
        <Button 
          variant="ghost" 
          className="flex items-center gap-2"
          onClick={() => navigate('/login')}
        >
          <LockKeyhole className="h-4 w-4" />
          {t('navbar.login', 'Connexion')}
        </Button>
      )}
    </div>
  );
}
