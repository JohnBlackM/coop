
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Star, Leaf } from 'lucide-react';

const AboutCooperatives = () => {
  const { t } = useTranslation();
  
  return (
    <section className="py-12">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-2xl md:text-3xl font-serif font-semibold text-forest-800 mb-4 text-center">
            {t('cooperativesShowcase.aboutTitle', 'À propos de nos coopératives')}
          </h2>
          
          <p className="text-gray-700 mb-6 text-center">
            {t('cooperativesShowcase.aboutDescription', 'Nos coopératives partenaires jouent un rôle essentiel dans notre chaîne d\'approvisionnement. Elles garantissent la qualité exceptionnelle de notre cacao tout en assurant des pratiques durables et équitables.')}
          </p>
          
          <Tabs defaultValue="impact" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="impact">{t('cooperativesShowcase.impactTab', 'Impact Social')}</TabsTrigger>
              <TabsTrigger value="quality">{t('cooperativesShowcase.qualityTab', 'Qualité')}</TabsTrigger>
              <TabsTrigger value="sustainability">{t('cooperativesShowcase.sustainabilityTab', 'Durabilité')}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="impact" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-forest-800 flex items-center gap-2">
                    <Users className="h-5 w-5" /> 
                    {t('cooperativesShowcase.impactTitle', 'Impact Social & Économique')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>{t('cooperativesShowcase.impactP1', 'Nos coopératives partenaires créent un impact positif significatif dans leurs communautés. Grâce au commerce équitable, les producteurs reçoivent une rémunération juste qui leur permet d\'améliorer leurs conditions de vie.')}</p>
                  <p>{t('cooperativesShowcase.impactP2', 'De nombreux projets communautaires sont financés grâce aux primes des certifications : construction d\'écoles, centres de santé, accès à l\'eau potable et formations pour les agriculteurs.')}</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="quality" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-forest-800 flex items-center gap-2">
                    <Star className="h-5 w-5" /> 
                    {t('cooperativesShowcase.qualityTitle', 'Excellence & Savoir-faire')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>{t('cooperativesShowcase.qualityP1', 'La qualité exceptionnelle de notre cacao provient du savoir-faire traditionnel de nos producteurs, enrichi par des techniques modernes de fermentation et de séchage qui développent des profils aromatiques complexes.')}</p>
                  <p>{t('cooperativesShowcase.qualityP2', 'Chaque coopérative possède ses méthodes uniques, transmises de génération en génération, pour cultiver et transformer les fèves de cacao en un produit d\'excellence reconnu internationalement.')}</p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="sustainability" className="pt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-forest-800 flex items-center gap-2">
                    <Leaf className="h-5 w-5" /> 
                    {t('cooperativesShowcase.sustainabilityTitle', 'Pratiques Durables')}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p>{t('cooperativesShowcase.sustainabilityP1', 'Nos coopératives s\'engagent pour un cacao respectueux de l\'environnement. Beaucoup pratiquent l\'agroforesterie, cultivant le cacao sous couvert forestier pour préserver la biodiversité et lutter contre la déforestation.')}</p>
                  <p>{t('cooperativesShowcase.sustainabilityP2', 'L\'agriculture biologique, la gestion durable de l\'eau et l\'absence de pesticides chimiques font partie des pratiques courantes qui assurent la santé des écosystèmes et la qualité supérieure du cacao.')}</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
};

export default AboutCooperatives;
