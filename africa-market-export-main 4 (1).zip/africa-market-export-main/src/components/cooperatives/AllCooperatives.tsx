
import { useTranslation } from 'react-i18next';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';
import { Cooperative } from '@/types/cooperative';

interface AllCooperativesProps {
  cooperatives: Cooperative[];
}

const AllCooperatives = ({ cooperatives }: AllCooperativesProps) => {
  const { t } = useTranslation();
  
  return (
    <section className="py-12 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-2xl md:text-3xl font-serif font-semibold text-forest-800 mb-8 text-center">
          {t('cooperativesShowcase.allCooperatives', 'Toutes les coopératives')}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {cooperatives.length > 0 ? (
            cooperatives.map(coop => (
              <Card key={coop.id} className="overflow-hidden border-forest-100 hover:shadow-md transition-shadow h-full flex flex-col">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={coop.mainImage} 
                    alt={coop.name} 
                    className="w-full h-full object-cover object-center hover:scale-105 transition-transform duration-500"
                  />
                </div>
                
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-serif text-forest-900">{coop.name}</CardTitle>
                  <CardDescription className="flex items-center gap-1">
                    <MapPin className="h-3 w-3 text-forest-500" />
                    {coop.country}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="pb-2 flex-grow">
                  <div className="flex flex-wrap gap-1 mb-3">
                    {coop.certifications.slice(0, 2).map(cert => (
                      <Badge key={cert} variant="outline" className="text-xs bg-forest-50 text-forest-700">
                        {cert}
                      </Badge>
                    ))}
                    {coop.certifications.length > 2 && (
                      <Badge variant="outline" className="text-xs bg-forest-50 text-forest-700">
                        +{coop.certifications.length - 2}
                      </Badge>
                    )}
                  </div>
                  
                  <p className="text-gray-700 text-sm line-clamp-3">{coop.description}</p>
                </CardContent>
                
                <CardFooter className="pt-0 mt-auto">
                  <Button variant="link" className="p-0 h-auto text-forest-700 hover:text-forest-900">
                    {t('cooperativesShowcase.readMore', 'En savoir plus')} →
                  </Button>
                </CardFooter>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-gray-500 text-lg">
                {t('cooperativesShowcase.noResults', 'Aucune coopérative ne correspond à votre recherche')}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default AllCooperatives;
