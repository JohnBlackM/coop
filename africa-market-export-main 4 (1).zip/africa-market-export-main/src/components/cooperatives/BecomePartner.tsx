
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';

const BecomePartner = () => {
  const { t } = useTranslation();
  
  return (
    <section className="py-12 bg-forest-800 text-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-2xl md:text-3xl font-serif font-semibold mb-4">
            {t('cooperativesShowcase.becomePartnerTitle', 'Vous êtes une coopérative de cacao ?')}
          </h2>
          
          <p className="mb-8 text-forest-100">
            {t('cooperativesShowcase.becomePartnerDesc', 'Rejoignez notre réseau de producteurs partenaires et bénéficiez d\'un accès privilégié au marché international, de relations commerciales équitables et durables.')}
          </p>
          
          <Button 
            asChild
            className="bg-white text-forest-800 hover:bg-forest-100 px-8 py-2"
          >
            <a href="/register-cooperative">
              {t('cooperativesShowcase.registerButton', 'Enregistrer votre coopérative')}
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default BecomePartner;
