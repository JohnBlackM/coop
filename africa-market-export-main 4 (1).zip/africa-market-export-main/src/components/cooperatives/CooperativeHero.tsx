
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Search } from 'lucide-react';

interface CooperativeHeroProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  filterCertification: string;
  setFilterCertification: (cert: string) => void;
}

const CooperativeHero = ({ 
  searchTerm, 
  setSearchTerm, 
  filterCertification, 
  setFilterCertification 
}: CooperativeHeroProps) => {
  const { t } = useTranslation();

  return (
    <section className="bg-gradient-to-b from-forest-50 to-white py-12 md:py-16">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold text-forest-900 mb-4">
            {t('cooperativesShowcase.heroTitle', 'Coopératives de Cacao')}
          </h1>
          <p className="text-lg md:text-xl text-forest-700 mb-8">
            {t('cooperativesShowcase.heroSubtitle', 'Découvrez les producteurs qui cultivent avec passion le meilleur cacao pour nos chocolats d\'exception')}
          </p>
          
          {/* Search & Filter */}
          <div className="flex flex-col md:flex-row justify-center gap-4 mb-8">
            <div className="relative w-full md:w-auto md:flex-grow max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-forest-500 h-5 w-5" />
              <input
                type="text"
                placeholder={t('cooperativesShowcase.searchPlaceholder', 'Rechercher une coopérative...')}
                className="pl-10 pr-4 py-2 w-full border border-forest-200 rounded-md focus:ring-2 focus:ring-forest-500 focus:border-transparent"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <select
              className="px-4 py-2 border border-forest-200 rounded-md bg-white focus:ring-2 focus:ring-forest-500 focus:border-transparent"
              value={filterCertification}
              onChange={(e) => setFilterCertification(e.target.value)}
            >
              <option value="">{t('cooperativesShowcase.allCertifications', 'Toutes certifications')}</option>
              <option value="Fairtrade">Fairtrade</option>
              <option value="Organic">Bio / Organic</option>
              <option value="Rainforest Alliance">Rainforest Alliance</option>
              <option value="UTZ">UTZ</option>
            </select>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CooperativeHero;
