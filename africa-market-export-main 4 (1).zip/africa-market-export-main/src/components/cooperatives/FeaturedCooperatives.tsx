
import { useTranslation } from 'react-i18next';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Users, Leaf, FileVideo, Coffee } from 'lucide-react';
import { Cooperative } from '@/types/cooperative';

interface FeaturedCooperativesProps {
  cooperatives: Cooperative[];
}

const FeaturedCooperatives = ({ cooperatives }: FeaturedCooperativesProps) => {
  const { t } = useTranslation();
  
  // Filter to show only featured cooperatives
  const featuredCooperatives = cooperatives.filter(coop => coop.featured);
  
  return (
    <section className="py-12">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-2xl md:text-3xl font-serif font-semibold text-forest-800 mb-8 text-center">
          {t('cooperativesShowcase.featuredTitle', 'Coopératives à l\'honneur')}
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {featuredCooperatives.map(coop => (
            <Card key={coop.id} className="overflow-hidden border-forest-100 hover:shadow-lg transition-shadow">
              <div className="aspect-video relative overflow-hidden">
                <img 
                  src={coop.mainImage} 
                  alt={coop.name} 
                  className="w-full h-full object-cover object-center transform hover:scale-105 transition-transform duration-500"
                />
                {coop.videoUrl && (
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-white/80 backdrop-blur-sm font-medium flex items-center gap-1">
                      <FileVideo className="h-3 w-3" />
                      {t('cooperativesShowcase.hasVideo', 'Vidéo disponible')}
                    </Badge>
                  </div>
                )}
              </div>
              
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl font-serif text-forest-900">{coop.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1 mt-1">
                      <MapPin className="h-4 w-4 text-forest-500" />
                      {coop.region}, {coop.country}
                    </CardDescription>
                  </div>
                  <div>
                    <Badge variant="outline" className="bg-forest-50 text-forest-700 border-forest-200">
                      {t('cooperativesShowcase.since', 'Depuis')} {coop.yearFounded}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-700">{coop.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {coop.certifications.map(cert => (
                      <Badge key={cert} className="bg-forest-100 text-forest-800 hover:bg-forest-200">
                        {cert}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="flex items-center gap-2">
                      <Users className="h-5 w-5 text-forest-600" />
                      <div>
                        <p className="text-sm text-gray-500">{t('cooperativesShowcase.members', 'Membres')}</p>
                        <p className="font-semibold text-forest-800">{coop.members}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Leaf className="h-5 w-5 text-forest-600" />
                      <div>
                        <p className="text-sm text-gray-500">{t('cooperativesShowcase.hectares', 'Hectares')}</p>
                        <p className="font-semibold text-forest-800">{coop.hectares}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              
              <CardFooter className="flex justify-between border-t border-forest-100 pt-4">
                <div className="flex gap-1 items-center text-forest-600">
                  <Coffee className="h-4 w-4" />
                  <span className="text-sm">{coop.varieties.join(', ')}</span>
                </div>
                <Button variant="outline" className="border-forest-200 text-forest-800 hover:bg-forest-50">
                  {t('cooperativesShowcase.viewDetails', 'Voir les détails')}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCooperatives;
