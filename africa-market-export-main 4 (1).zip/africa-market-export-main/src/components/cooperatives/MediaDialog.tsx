
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Cooperative, MediaItem } from '@/types/cooperative';

interface MediaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedCooperative: number | null;
  selectedMedia: 'photo' | 'video' | null;
  selectedMediaItem: MediaItem | null;
  cooperatives: Cooperative[];
}

const MediaDialog = ({ 
  open, 
  onOpenChange, 
  selectedCooperative, 
  selectedMedia, 
  selectedMediaItem,
  cooperatives
}: MediaDialogProps) => {
  const currentCooperative = selectedCooperative 
    ? cooperatives.find(c => c.id === selectedCooperative) 
    : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={selectedMedia === 'photo' ? "max-w-3xl" : "max-w-4xl"}>
        <DialogHeader>
          <DialogTitle>
            {selectedMediaItem?.caption}
          </DialogTitle>
          <DialogDescription>
            {selectedCooperative && currentCooperative && (
              <div className="flex items-center gap-2 mt-1">
                <Badge>{selectedMediaItem?.category}</Badge>
                <span className="text-sm text-gray-500">
                  {currentCooperative.name}
                </span>
              </div>
            )}
          </DialogDescription>
        </DialogHeader>
        
        {selectedMedia === 'photo' && selectedMediaItem && (
          <div className="mt-2 rounded-md overflow-hidden">
            <img 
              src={selectedMediaItem.url} 
              alt={selectedMediaItem.caption} 
              className="w-full h-auto max-h-[70vh] object-contain mx-auto"
            />
          </div>
        )}
        
        {selectedMedia === 'video' && selectedMediaItem && (
          <div className="mt-2 aspect-video w-full">
            <iframe
              className="w-full h-full border-0 rounded-md"
              src={selectedMediaItem.url}
              title={selectedMediaItem.caption}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default MediaDialog;
