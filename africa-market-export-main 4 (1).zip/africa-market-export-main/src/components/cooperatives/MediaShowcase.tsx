
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { ImageIcon, FileVideo } from 'lucide-react';
import { Cooperative, MediaItem } from '@/types/cooperative';

interface MediaShowcaseProps {
  cooperatives: Cooperative[];
  selectedMediaCategory: string;
  setSelectedMediaCategory: (category: string) => void;
  onOpenMediaDialog: (cooperative: number, mediaType: 'photo' | 'video', item: MediaItem) => void;
}

const MediaShowcase = ({ 
  cooperatives, 
  selectedMediaCategory, 
  setSelectedMediaCategory,
  onOpenMediaDialog
}: MediaShowcaseProps) => {
  const { t } = useTranslation();
  
  // Helper function to filter media by category
  const getFilteredMedia = (coop: Cooperative, type: 'photos' | 'videos') => {
    if (!coop.media || !coop.media[type]) return [];
    return selectedMediaCategory === 'all' 
      ? coop.media[type] 
      : coop.media[type].filter((item: MediaItem) => item.category === selectedMediaCategory);
  };
  
  return (
    <section className="py-12">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-2xl md:text-3xl font-serif font-semibold text-forest-800 mb-4 text-center">
          {t('cooperativesShowcase.mediaShowcase', 'Découvrez nos coopératives en images')}
        </h2>
        <p className="text-center text-gray-600 mb-8 max-w-3xl mx-auto">
          {t('cooperativesShowcase.mediaShowcaseDesc', 'Explorez les photos et vidéos de nos coopératives partenaires, montrant leurs plantations, leur travail quotidien et leurs produits')}
        </p>
        
        <div className="flex flex-wrap justify-center gap-2 mb-8">
          <Button 
            variant={selectedMediaCategory === 'all' ? "default" : "outline"} 
            onClick={() => setSelectedMediaCategory('all')}
            className="mb-2"
          >
            {t('cooperativesShowcase.allCategories', 'Toutes les catégories')}
          </Button>
          <Button 
            variant={selectedMediaCategory === 'plantation' ? "default" : "outline"} 
            onClick={() => setSelectedMediaCategory('plantation')}
            className="mb-2"
          >
            {t('cooperativesShowcase.plantations', 'Plantations')}
          </Button>
          <Button 
            variant={selectedMediaCategory === 'work' ? "default" : "outline"} 
            onClick={() => setSelectedMediaCategory('work')}
            className="mb-2"
          >
            {t('cooperativesShowcase.work', 'Travail')}
          </Button>
          <Button 
            variant={selectedMediaCategory === 'product' ? "default" : "outline"} 
            onClick={() => setSelectedMediaCategory('product')}
            className="mb-2"
          >
            {t('cooperativesShowcase.products', 'Produits')}
          </Button>
        </div>
        
        {cooperatives.map(coop => (
          <div key={`media-${coop.id}`} className="mb-12">
            <h3 className="text-xl font-serif font-semibold text-forest-800 mb-4 flex items-center gap-2">
              <span>{coop.name}</span>
              <Badge className="ml-2 bg-forest-100 text-forest-700">{coop.country}</Badge>
            </h3>
            
            <Tabs defaultValue="photos" className="w-full">
              <TabsList className="mb-6">
                <TabsTrigger value="photos" className="flex items-center gap-2">
                  <ImageIcon className="h-4 w-4" />
                  {t('cooperativesShowcase.photos', 'Photos')}
                  <Badge variant="outline" className="ml-1 text-xs">
                    {getFilteredMedia(coop, 'photos').length}
                  </Badge>
                </TabsTrigger>
                <TabsTrigger value="videos" className="flex items-center gap-2">
                  <FileVideo className="h-4 w-4" />
                  {t('cooperativesShowcase.videos', 'Vidéos')}
                  <Badge variant="outline" className="ml-1 text-xs">
                    {getFilteredMedia(coop, 'videos').length}
                  </Badge>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="photos">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {getFilteredMedia(coop, 'photos').length > 0 ? (
                    getFilteredMedia(coop, 'photos').map((photo: MediaItem) => (
                      <div 
                        key={photo.id} 
                        className="aspect-square overflow-hidden rounded-md border cursor-pointer relative group"
                        onClick={() => onOpenMediaDialog(coop.id, 'photo', photo)}
                      >
                        <img 
                          src={photo.url} 
                          alt={photo.caption} 
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-opacity flex items-end justify-start p-3">
                          <Badge className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 text-forest-900 text-xs backdrop-blur-sm">
                            {photo.category}
                          </Badge>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="col-span-full text-center py-6 text-gray-500">
                      {t('cooperativesShowcase.noPhotos', 'Aucune photo disponible dans cette catégorie')}
                    </p>
                  )}
                </div>
              </TabsContent>
              
              <TabsContent value="videos">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {getFilteredMedia(coop, 'videos').length > 0 ? (
                    getFilteredMedia(coop, 'videos').map((video: MediaItem) => (
                      <div key={video.id} className="aspect-video overflow-hidden rounded-md border">
                        <div className="relative pt-[56.25%] w-full cursor-pointer" onClick={() => onOpenMediaDialog(coop.id, 'video', video)}>
                          <iframe
                            className="absolute top-0 left-0 w-full h-full border-0"
                            src={video.url}
                            title={video.caption}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                          ></iframe>
                          <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/70 to-transparent">
                            <p className="text-white text-sm">{video.caption}</p>
                            <Badge className="mt-1 bg-forest-700/80">{video.category}</Badge>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="col-span-full text-center py-6 text-gray-500">
                      {t('cooperativesShowcase.noVideos', 'Aucune vidéo disponible dans cette catégorie')}
                    </p>
                  )}
                </div>
              </TabsContent>
            </Tabs>
            
            <Separator className="my-8" />
          </div>
        ))}
      </div>
    </section>
  );
};

export default MediaShowcase;
