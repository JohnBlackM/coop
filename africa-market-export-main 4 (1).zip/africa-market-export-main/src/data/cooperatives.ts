
import { Cooperative } from '@/types/cooperative';

// Sample cooperative data - In a real application, this would come from an API
export const cooperatives: Cooperative[] = [
  {
    id: 1,
    name: "Cacao Equitable",
    country: "Ivory Coast",
    region: "Abengourou",
    yearFounded: 2008,
    members: 247,
    hectares: 650,
    certifications: ["Fairtrade", "Organic", "Rainforest Alliance"],
    varieties: ["Forastero", "Trinitario"],
    description: "Coopérative fondée sur des principes de développement durable et de commerce équitable, offrant un cacao de haute qualité cultivé dans des conditions respectueuses de l'environnement.",
    mainImage: "/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png",
    gallery: [
      "/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png",
      "/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png",
    ],
    media: {
      photos: [
        { id: 'p1', url: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png', caption: 'Plantation de cacao', category: 'plantation' },
        { id: 'p2', url: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png', caption: 'Récolte des cabosses', category: 'work' },
        { id: 'p3', url: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png', caption: 'Cacao séché', category: 'product' },
      ],
      videos: [
        { id: 'v1', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Visite de la plantation', category: 'plantation' },
        { id: 'v2', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Processus de fermentation', category: 'work' },
      ]
    },
    story: "Née de la volonté de 50 producteurs de s'unir face aux défis du marché, notre coopérative a grandi pour devenir un acteur majeur du cacao durable en Côte d'Ivoire.",
    featured: true,
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    testimonials: [
      {
        id: "t1",
        personName: "Marie Konan",
        role: "Productrice",
        content: "Depuis que j'ai rejoint la coopérative, mes revenus sont plus stables et je peux envoyer tous mes enfants à l'école.",
        date: "2022-05-15"
      },
      {
        id: "t2",
        personName: "Kouassi Yao",
        role: "Directeur de production",
        content: "Notre engagement pour la qualité nous a permis d'accéder à de nouveaux marchés internationaux et d'obtenir de meilleures conditions pour nos membres.",
        date: "2023-02-10"
      }
    ],
    successStories: [
      {
        id: "s1",
        title: "Construction d'une nouvelle école",
        description: "Grâce aux primes du commerce équitable, nous avons financé la construction d'une école primaire qui accueille aujourd'hui 120 enfants de notre communauté.",
        imageUrl: "/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png",
        date: "2021-09-01",
        impact: "Accès à l'éducation pour 120 enfants"
      },
      {
        id: "s2",
        title: "Certification biologique",
        description: "Après trois ans d'efforts, 80% de nos parcelles ont obtenu la certification biologique, permettant une valorisation de notre cacao et une meilleure protection de l'environnement.",
        date: "2020-03-15",
        impact: "Amélioration des revenus de 200 producteurs"
      }
    ],
    status: "published"
  },
  {
    id: 2,
    name: "Association des Producteurs de Cacao Bio",
    country: "Ghana",
    region: "Western Region",
    yearFounded: 2012,
    members: 184,
    hectares: 420,
    certifications: ["Organic", "UTZ"],
    varieties: ["Criollo", "Forastero"],
    description: "Producteurs spécialisés dans la culture biologique du cacao, avec un accent particulier sur la préservation des variétés ancestrales et les techniques traditionnelles.",
    mainImage: "/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png",
    gallery: [
      "/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png",
      "/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png",
    ],
    media: {
      photos: [
        { id: 'p4', url: '/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png', caption: 'Vue aérienne', category: 'plantation' },
        { id: 'p5', url: '/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png', caption: 'Fèves de cacao', category: 'product' },
      ],
      videos: []
    },
    story: "Notre association a commencé comme un petit groupe d'agriculteurs déterminés à cultiver sans pesticides. Aujourd'hui, nous sommes fiers de notre réputation de cacao bio d'exception.",
    featured: false,
    testimonials: [
      {
        id: "t3",
        personName: "Abena Mensah",
        role: "Productrice fondatrice",
        content: "Quand nous avons commencé, beaucoup pensaient que l'agriculture biologique n'était pas viable à grande échelle. Aujourd'hui, nous prouvons chaque jour que c'est possible.",
        date: "2021-11-20"
      }
    ],
    successStories: [
      {
        id: "s3",
        title: "Programme de formation agroécologique",
        description: "Notre programme de formation a permis à 50 jeunes agriculteurs d'apprendre les techniques de l'agroécologie et de démarrer leur propre production biologique.",
        date: "2022-07-10",
        impact: "50 nouveaux producteurs formés aux pratiques biologiques"
      }
    ],
    status: "published"
  },
  {
    id: 3,
    name: "Coopérative des Cultivateurs de Cacao",
    country: "Cameroon",
    region: "Central Region",
    yearFounded: 2015,
    members: 120,
    hectares: 380,
    certifications: ["Fairtrade", "Rainforest Alliance"],
    varieties: ["Trinitario"],
    description: "Coopérative jeune et dynamique mettant l'accent sur l'innovation dans les techniques de fermentation pour développer des profils aromatiques uniques et complexes.",
    mainImage: "/lovable-uploads/90f235e6-7e39-4eb0-9a73-f15e83903d5d.png",
    gallery: [
      "/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png",
      "/lovable-uploads/4cf03012-4e4c-4972-bdf5-0cd930d80457.png",
    ],
    media: {
      photos: [
        { id: 'p6', url: '/lovable-uploads/e95b61db-5654-4eeb-9958-937528b259fe.png', caption: 'Cabosses de cacao', category: 'product' },
      ],
      videos: [
        { id: 'v3', url: 'https://www.youtube.com/embed/dQw4w9WgXcQ', caption: 'Processus d\'écabossage', category: 'work' },
      ]
    },
    story: "Fondée par un groupe de jeunes agriculteurs passionnés, notre coopérative combine savoirs ancestraux et techniques modernes pour un cacao d'excellence.",
    featured: true,
    testimonials: [],
    successStories: [],
    status: "published"
  }
];
