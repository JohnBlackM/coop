
import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// Import translation files
import enTranslation from './locales/en/translation.json';
import frTranslation from './locales/fr/translation.json';
import esTranslation from './locales/es/translation.json';
import zhTranslation from './locales/zh/translation.json';
import ruTranslation from './locales/ru/translation.json';

// Get saved language from localStorage or use French as default
const savedLanguage = localStorage.getItem('i18n-language') || 'fr';

// Save default language if not already set
if (!localStorage.getItem('i18n-language')) {
  localStorage.setItem('i18n-language', 'fr');
}

// Force language reload on page change to ensure consistency
const forceLanguageReload = () => {
  const currentLang = localStorage.getItem('i18n-language') || 'fr';
  i18n.changeLanguage(currentLang);
};

// Apply language reload on route changes
window.addEventListener('popstate', forceLanguageReload);

i18n
  // detect user language
  .use(LanguageDetector)
  // pass the i18n instance to react-i18next
  .use(initReactI18next)
  // init i18next
  .init({
    debug: false,
    fallbackLng: 'fr', // Set French as default fallback
    lng: savedLanguage, // Use saved language or French by default
    interpolation: {
      escapeValue: false, // not needed for react as it escapes by default
    },
    detection: {
      order: ['localStorage', 'navigator'],
      lookupLocalStorage: 'i18n-language',
      caches: ['localStorage'],
    },
    resources: {
      en: {
        translation: enTranslation
      },
      fr: {
        translation: frTranslation
      },
      es: {
        translation: esTranslation
      },
      zh: {
        translation: zhTranslation
      },
      ru: {
        translation: ruTranslation
      }
    }
  });

// Initial language force load
forceLanguageReload();

export default i18n;
