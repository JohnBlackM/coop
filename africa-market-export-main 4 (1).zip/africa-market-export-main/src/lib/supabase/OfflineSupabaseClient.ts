
import { toast } from '@/hooks/use-toast';

/**
 * Fallback class for Supabase operations when connection fails
 */
export class OfflineSupabaseClient {
  constructor() {
    console.info('Initializing Offline Supabase Client');
  }

  async from(table: string) {
    console.info(`Opération Supabase simulée: table=${table}`);
    return {
      select: async () => {
        console.info(`SELECT depuis ${table}`);
        return { data: [], error: null };
      },
      insert: async (data: any) => {
        console.info(`INSERT dans ${table}`, data);
        return { data: null, error: null };
      },
      update: async (data: any) => {
        console.info(`UPDATE dans ${table}`, data);
        return { data: null, error: null };
      },
      delete: async () => {
        console.info(`DELETE depuis ${table}`);
        return { data: null, error: null };
      },
      eq: (column: string, value: any) => {
        console.info(`EQ sur ${table}, ${column}=${value}`);
        return {
          select: async () => {
            console.info(`SELECT avec EQ depuis ${table}`);
            return { data: [], error: null };
          },
          delete: async () => {
            console.info(`DELETE avec EQ depuis ${table}`);
            return { data: null, error: null };
          },
          update: async (data: any) => {
            console.info(`UPDATE avec EQ depuis ${table}`, data);
            return { data: null, error: null };
          }
        };
      }
    };
  }
  
  storage = {
    from: (bucket: string) => ({
      upload: async (path: string, data: any) => {
        console.info(`UPLOAD vers ${bucket}/${path}`);
        return { data: { path }, error: null };
      },
      getPublicUrl: (path: string) => {
        console.info(`GET PUBLIC URL pour ${bucket}/${path}`);
        return { data: { publicUrl: '' } };
      },
      download: async (path: string) => {
        console.info(`DOWNLOAD depuis ${bucket}/${path}`);
        return { data: null, error: null };
      }
    }),
    listBuckets: async () => {
      console.info(`LIST BUCKETS`);
      return { data: [{ name: 'images', id: 'images' }], error: null };
    },
    createBucket: async (name: string, options?: any) => {
      console.info(`CREATE BUCKET ${name}`, options);
      return { data: { name }, error: null };
    }
  };
  
  channel(name: string) {
    console.info(`Canal simulé: ${name}`);
    return {
      on: () => this,
      subscribe: () => ({ unsubscribe: () => {} }),
    };
  }
}
