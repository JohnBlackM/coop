import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/types/supabase';
import { OfflineSupabaseClient } from './OfflineSupabaseClient';

// Utiliser les valeurs du fichier integrations/supabase/client.ts
const SUPABASE_URL = "https://vqpskgybrzmpyledddft.supabase.co";
const SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZxcHNrZ3licnptcHlsZWRkZGZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE2OTMyNDgsImV4cCI6MjA1NzI2OTI0OH0.ZU6LX9HSz21pKyTIUUzjVfdnwPxNe9HINMWn3VhhsRM";

// Create Supabase client with error handling
let supabaseInstance: ReturnType<typeof createClient<Database>> | null = null;
let offlineMode = false;

try {
  if (SUPABASE_URL && SUPABASE_ANON_KEY) {
    supabaseInstance = createClient<Database>(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
    console.info('Client Supabase initialisé avec succès');
  } else {
    console.warn('Utilisation du client Supabase hors ligne en raison de variables d\'environnement manquantes');
    offlineMode = true;
  }
} catch (error) {
  console.error('Erreur lors de l\'initialisation du client Supabase:', error);
  console.warn('Passage en mode client Supabase hors ligne');
  offlineMode = true;
}

// Export the Supabase client or fallback to offline client
export const supabase = supabaseInstance || new OfflineSupabaseClient() as unknown as ReturnType<typeof createClient<Database>>;
export const isOfflineMode = offlineMode;

/**
 * Helper function to generate proper image URLs
 * @param imageUrl The image URL path from the database
 * @returns The complete URL for the image
 */
export const getImageUrl = (imageUrl: string): string => {
  // If it's already a complete URL or a local path, return it as is
  if (imageUrl.startsWith('http') || imageUrl.startsWith('/')) {
    return imageUrl;
  }
  
  // If we're in offline mode, use a fallback image path
  if (offlineMode) {
    return `/placeholders/${imageUrl}`;
  }
  
  // Otherwise, construct the storage URL
  return `${SUPABASE_URL}/storage/v1/object/public/${imageUrl}`;
};
