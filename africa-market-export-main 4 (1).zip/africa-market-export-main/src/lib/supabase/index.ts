
// Import core functionalities
import { supabase, isOfflineMode, getImageUrl } from './client';
import { initializeStorage, isStorageAvailable } from './storageUtils';
import { syncDataWithSupabase } from './syncUtils';
import { toast } from '@/hooks/use-toast';

// Export core functionalities
export { supabase, isOfflineMode, getImageUrl };
export { initializeStorage, isStorageAvailable };
export { syncDataWithSupabase };

// Function to display offline mode toasts
export const showOfflineToasts = () => {
  if (isOfflineMode) {
    // Check environment variables directly
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
    
    if (!supabaseUrl || !supabaseAnonKey) {
      toast({
        title: "Offline mode",
        description: "Supabase environment variables are missing. Operating in offline mode.",
        variant: "default",
      });
    } else {
      toast({
        title: "Connection error",
        description: "Unable to connect to Supabase. Offline mode activated.",
        variant: "destructive",
      });
    }
  }
};
