
import { toast } from '@/hooks/use-toast';
import { supabase } from './client';

/**
 * Checks if storage functionality is available
 */
export const isStorageAvailable = () => {
  return 'storage' in supabase && typeof supabase.storage.listBuckets === 'function';
};

/**
 * Initializes storage buckets if needed
 */
export const initializeStorage = async () => {
  try {
    if (!supabase) {
      throw new Error("Client Supabase non initialisé");
    }
    
    // Check if storage is available
    if (!isStorageAvailable()) {
      console.info('Mode hors ligne : Simulation de l\'initialisation du stockage');
      return;
    }
    
    const { data: buckets, error: listError } = await supabase
      .storage
      .listBuckets();
    
    if (listError) {
      console.warn('Erreur lors de la liste des buckets:', listError);
      return; // Continue without throwing, to avoid blocking the app
    }
    
    const imagesBucketExists = buckets?.some(bucket => bucket.name === 'images');
    
    if (!imagesBucketExists) {
      const { error: createError } = await supabase
        .storage
        .createBucket('images', {
          public: true,
          fileSizeLimit: 10485760, // 10MB
        });
      
      if (createError) {
        console.warn('Erreur lors de la création du bucket:', createError);
        return; // Continue without throwing
      }
      
      console.info('Bucket de stockage "images" créé');
    }
  } catch (error) {
    console.error('Erreur lors de l\'initialisation du stockage:', error);
    // Using a more gentle toast that won't block the app
    toast({
      title: "Information stockage",
      description: "Le stockage d'images fonctionne en mode local.",
      variant: "default",
    });
  }
};

/**
 * Gets a public URL for an image, handling both online and offline modes
 */
export const getImageUrl = (path: string) => {
  // If it's already a full URL or a local path, return it as is
  if (path.startsWith('http') || path.startsWith('/')) {
    return path;
  }
  
  // If storage is available, try to get the public URL
  if (isStorageAvailable()) {
    try {
      const { data } = supabase.storage.from('images').getPublicUrl(path);
      return data.publicUrl;
    } catch (error) {
      console.warn('Erreur lors de la récupération de l\'URL publique:', error);
      // Fall back to local path
      return `/lovable-uploads/${path.split('/').pop()}`;
    }
  }
  
  // Fallback to local path for offline mode
  return `/lovable-uploads/${path.split('/').pop()}`;
};
