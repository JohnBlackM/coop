
import { toast } from '@/hooks/use-toast';
import { supabase, isOfflineMode } from './client';

/**
 * Synchronizes local data with Supabase
 */
export const syncDataWithSupabase = async () => {
  try {
    if (isOfflineMode) {
      toast({
        title: "Mode hors ligne",
        description: "Synchronisation impossible en mode hors ligne. Connectez-vous à Supabase pour synchroniser les données.",
        variant: "default",
      });
      return false;
    }
    
    const localCooperatives = localStorage.getItem('cooperatives');
    const pendingCooperatives = localStorage.getItem('pendingCooperatives');
    
    if (localCooperatives) {
      const cooperatives = JSON.parse(localCooperatives);
      
      for (const coop of cooperatives) {
        const { data: existingCoops } = await supabase
          .from('cooperatives')
          .select('id')
          .eq('name', coop.name);
        
        if (!existingCoops || existingCoops.length === 0) {
          await supabase
            .from('cooperatives')
            .insert({
              ...coop,
              status: 'published',
              createdAt: new Date().toISOString()
            });
          
          console.info(`Synchronized cooperative: ${coop.name}`);
        }
      }
    }
    
    if (pendingCooperatives) {
      const cooperatives = JSON.parse(pendingCooperatives);
      
      for (const coop of cooperatives) {
        const { data: existingCoops } = await supabase
          .from('cooperatives')
          .select('id')
          .eq('name', coop.name);
        
        if (!existingCoops || existingCoops.length === 0) {
          await supabase
            .from('cooperatives')
            .insert({
              ...coop,
              status: 'pending',
              createdAt: new Date().toISOString()
            });
          
          console.info(`Synchronized pending cooperative: ${coop.name}`);
        }
      }
    }

    const localProducts = localStorage.getItem('products');
    
    if (localProducts) {
      const products = JSON.parse(localProducts);
      
      for (const product of products) {
        const { data: existingProducts } = await supabase
          .from('products')
          .select('id')
          .eq('name', product.name);
        
        if (!existingProducts || existingProducts.length === 0) {
          await supabase
            .from('products')
            .insert({
              ...product,
              createdAt: new Date().toISOString()
            });
          
          console.info(`Synchronized product: ${product.name}`);
        }
      }
    }

    toast({
      title: "Synchronisation réussie",
      description: "Toutes les données ont été transférées vers Supabase.",
    });
    
    return true;
  } catch (error) {
    console.error('Error synchronizing data with Supabase:', error);
    toast({
      title: "Erreur de synchronisation",
      description: "Impossible de synchroniser les données avec Supabase. Veuillez réessayer plus tard.",
      variant: "destructive",
    });
    return false;
  }
};
