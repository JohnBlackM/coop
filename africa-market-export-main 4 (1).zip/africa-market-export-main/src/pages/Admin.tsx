
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Settings, Users, List, Database, Image, Coffee, Bell, ShoppingBag, RefreshCw } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import ContentManager from '@/components/admin/ContentManager';
import UserManager from '@/components/admin/UserManager';
import SettingsPanel from '@/components/admin/SettingsPanel';
import { useToast } from '@/hooks/use-toast';
import ImageManager from '@/components/admin/ImageManager';
import CooperativeManager from '@/components/admin/CooperativeManager';
import ProductManager from '@/components/admin/ProductManager';
import { Badge } from '@/components/ui/badge';
import { Cooperative } from '@/types/cooperative';
import UserProfileMenu from '@/components/admin/UserProfileMenu';
import { syncDataWithSupabase } from '@/lib/supabase';

export default function Admin() {
  const { t } = useTranslation();
  const [currentTab, setCurrentTab] = useState<string>('content');
  const { toast } = useToast();
  const [pendingCount, setPendingCount] = useState(0);
  const { user } = useAuth();
  const [isSyncing, setIsSyncing] = useState(false);

  // Vérifier s'il y a des coopératives en attente d'approbation
  useEffect(() => {
    try {
      const storedCoops = localStorage.getItem('pendingCooperatives');
      if (storedCoops) {
        const pendingCooperatives: Cooperative[] = JSON.parse(storedCoops);
        setPendingCount(pendingCooperatives.length);
        
        if (pendingCooperatives.length > 0) {
          toast({
            title: t('admin.pendingCooperatives', 'Coopératives en attente'),
            description: t('admin.pendingCooperativesDesc', 'Il y a des coopératives en attente d\'approbation'),
          });
        }
      }
    } catch (error) {
      console.error("Error checking pending cooperatives:", error);
    }
  }, [t, toast]);

  const handleTabChange = (value: string) => {
    setCurrentTab(value);
  };

  const handleSyncData = async () => {
    setIsSyncing(true);
    try {
      await syncDataWithSupabase();
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="container mx-auto py-10 px-4 md:px-6">
      <div className="flex flex-col space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">{t('admin.title', 'Administration')}</h1>
            <p className="text-muted-foreground mt-2">
              {t('admin.subtitle', 'Gérez le contenu et les paramètres de votre site')}
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Button 
              onClick={handleSyncData} 
              variant="outline"
              disabled={isSyncing}
              className="flex items-center gap-2"
            >
              <RefreshCw className={`h-4 w-4 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing 
                ? t('admin.syncing', 'Synchronisation...') 
                : t('admin.syncWithSupabase', 'Synchroniser avec Supabase')}
            </Button>
            <UserProfileMenu />
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>{t('admin.dashboard', 'Tableau de bord')}</CardTitle>
            <CardDescription>
              {t('admin.dashboardDescription', 'Accédez aux outils de gestion de contenu et d\'administration')}
              {user && (
                <span className="block mt-1">
                  {t('admin.loggedInAs', 'Connecté en tant que')}: <strong>{user.name}</strong> ({user.role})
                </span>
              )}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={currentTab} onValueChange={handleTabChange} className="w-full">
              <TabsList className="grid grid-cols-8 mb-8">
                <TabsTrigger value="content" className="flex items-center gap-2">
                  <List className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.content', 'Contenu')}</span>
                </TabsTrigger>
                <TabsTrigger value="cooperatives" className="flex items-center gap-2">
                  <Coffee className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.cooperatives', 'Coopératives')}</span>
                  {pendingCount > 0 && (
                    <Badge variant="destructive" className="ml-1 h-5 w-5 p-0 flex items-center justify-center rounded-full">
                      {pendingCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="pending" className="flex items-center gap-2">
                  <Bell className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.pending', 'À valider')}</span>
                  {pendingCount > 0 && (
                    <Badge variant="destructive" className="ml-1 h-5 w-5 p-0 flex items-center justify-center rounded-full">
                      {pendingCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="products" className="flex items-center gap-2">
                  <ShoppingBag className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.products', 'Produits')}</span>
                </TabsTrigger>
                <TabsTrigger value="users" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.users', 'Utilisateurs')}</span>
                </TabsTrigger>
                <TabsTrigger value="images" className="flex items-center gap-2">
                  <Image className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.images', 'Images')}</span>
                </TabsTrigger>
                <TabsTrigger value="database" className="flex items-center gap-2">
                  <Database className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.database', 'Base de données')}</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  <span className="hidden md:inline">{t('admin.settings', 'Paramètres')}</span>
                </TabsTrigger>
              </TabsList>

              <TabsContent value="content" className="space-y-4">
                <ContentManager />
              </TabsContent>

              <TabsContent value="cooperatives" className="space-y-4">
                <CooperativeManager initialTab="published" />
              </TabsContent>
              
              <TabsContent value="pending" className="space-y-4">
                <CooperativeManager initialTab="pending" />
              </TabsContent>
              
              <TabsContent value="products" className="space-y-4">
                <ProductManager />
              </TabsContent>

              <TabsContent value="users" className="space-y-4">
                <UserManager />
              </TabsContent>

              <TabsContent value="images" className="space-y-4">
                <ImageManager />
              </TabsContent>

              <TabsContent value="database" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>{t('admin.database', 'Base de données')}</CardTitle>
                    <CardDescription>
                      {t('admin.databaseDescription', 'Gestion et visualisation des données')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={() => toast({
                        title: t('admin.comingSoon', 'Fonctionnalité à venir'),
                        description: t('admin.databaseModuleNotAvailable', 'Le module de base de données n\'est pas encore disponible.'),
                      })}
                    >
                      {t('admin.viewDatabase', 'Afficher la base de données')}
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="settings" className="space-y-4">
                <SettingsPanel />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
