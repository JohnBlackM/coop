
import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Helmet } from 'react-helmet-async';
import { useToast } from '@/hooks/use-toast';

import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import CooperativeHero from '@/components/cooperatives/CooperativeHero';
import AboutCooperatives from '@/components/cooperatives/AboutCooperatives';
import FeaturedCooperatives from '@/components/cooperatives/FeaturedCooperatives';
import AllCooperatives from '@/components/cooperatives/AllCooperatives';
import BecomePartner from '@/components/cooperatives/BecomePartner';

import { Cooperative } from '@/types/cooperative';
import { supabase, isOfflineMode, getImageUrl } from '@/lib/supabase';
import { cooperatives as localCooperatives } from '@/data/cooperatives';

const CooperativesShowcase = () => {
  const { t } = useTranslation();
  const [cooperatives, setCooperatives] = useState<Cooperative[]>(localCooperatives);
  const [isLoading, setIsLoading] = useState(true);
  const [isSupabaseAvailable, setIsSupabaseAvailable] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCertification, setFilterCertification] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const fetchCooperatives = async () => {
      setIsLoading(true);
      try {
        const { data, error } = await supabase
          .from('cooperatives')
          .select('*')
          .eq('status', 'published');

        if (error) {
          console.warn("Error loading cooperatives from Supabase:", error);
          setIsSupabaseAvailable(false);
          // Process local data with proper image URLs
          const processedCoops = localCooperatives.map(coop => ({
            ...coop,
            mainImage: getImageUrl(coop.mainImage),
            gallery: coop.gallery.map(img => getImageUrl(img))
          }));
          setCooperatives(processedCoops);
          return;
        }

        if (data && data.length > 0) {
          // Process data with proper image URLs
          const processedData = data.map(coop => {
            const typedCoop = {
              ...coop,
              status: coop.status as Cooperative['status'],
              mainImage: getImageUrl(coop.mainImage || ''),
              gallery: Array.isArray(coop.gallery) ? coop.gallery.map(img => getImageUrl(img)) : []
            };
            return typedCoop;
          });
          setCooperatives(processedData);
        } else {
          // Process local data with proper image URLs
          const processedCoops = localCooperatives.map(coop => ({
            ...coop,
            mainImage: getImageUrl(coop.mainImage),
            gallery: coop.gallery.map(img => getImageUrl(img))
          }));
          console.info("No cooperatives found in database, using local data");
          setCooperatives(processedCoops);
        }
      } catch (error) {
        console.error("Failed to fetch cooperatives:", error);
        setIsSupabaseAvailable(false);
        // Process local data with proper image URLs
        const processedCoops = localCooperatives.map(coop => ({
          ...coop,
          mainImage: getImageUrl(coop.mainImage),
          gallery: coop.gallery.map(img => getImageUrl(img))
        }));
        setCooperatives(processedCoops);
        toast({
          title: t('cooperativesShowcase.error', 'Erreur'),
          description: t('cooperativesShowcase.errorLoading', 'Erreur lors du chargement des coopératives'),
          variant: 'destructive'
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchCooperatives();
  }, [t, toast]);

  return (
    <>
      <Helmet>
        <title>{t('cooperativesShowcase.pageTitle', 'Nos Coopératives | Angara')}</title>
        <meta 
          name="description" 
          content={t('cooperativesShowcase.metaDescription', 'Découvrez les coopératives partenaires d\'Angara, engagées dans une agriculture durable et équitable.')} 
        />
      </Helmet>
      
      <div className="min-h-screen flex flex-col">
        <Navbar />
        
        <main className="flex-grow">
          <CooperativeHero 
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            filterCertification={filterCertification}
            setFilterCertification={setFilterCertification}
          />
          
          {isLoading ? (
            <div className="py-20 flex justify-center">
              <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : (
            <>
              {!isSupabaseAvailable && (
                <div className="container mx-auto px-4 mt-4">
                  <div className="p-3 bg-amber-100 text-amber-800 rounded-md text-sm text-center">
                    {t('cooperativesShowcase.offlineMode', 'Mode déconnecté: Affichage des données locales')}
                  </div>
                </div>
              )}
              
              <AboutCooperatives />
              <FeaturedCooperatives cooperatives={cooperatives.filter(coop => coop.featured)} />
              <AllCooperatives cooperatives={cooperatives} />
              <BecomePartner />
            </>
          )}
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default CooperativesShowcase;
