
import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import ProductShowcase from '@/components/ProductShowcase';
import WhyChooseUs from '@/components/WhyChooseUs';
import HowItWorks from '@/components/HowItWorks';
import AngaraPromotion from '@/components/AngaraPromotion';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';
import { cooperatives } from '@/data/cooperatives';
import { getImageUrl } from '@/lib/supabase';
import AllCooperatives from '@/components/cooperatives/AllCooperatives';
import FeaturedCooperatives from '@/components/cooperatives/FeaturedCooperatives';
import AboutCooperatives from '@/components/cooperatives/AboutCooperatives';

const Index = () => {
  // Process cooperatives for display with proper image URLs
  const processedCooperatives = cooperatives.map(coop => ({
    ...coop,
    mainImage: getImageUrl(coop.mainImage),
    gallery: coop.gallery.map(img => getImageUrl(img))
  }));

  useEffect(() => {
    // Intersection Observer for reveal animations
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
        }
      });
    }, observerOptions);

    const revealElements = document.querySelectorAll('.reveal-animation');
    revealElements.forEach(el => observer.observe(el));

    // Handle hash navigation on page load
    const handleHashNavigation = () => {
      const hash = window.location.hash;
      if (hash) {
        const id = hash.replace('#', '');
        const element = document.getElementById(id);
        if (element) {
          setTimeout(() => {
            window.scrollTo({
              top: element.offsetTop - 80, // Offset for navbar height
              behavior: 'smooth'
            });
          }, 300);
        }
      }
    };

    handleHashNavigation();

    return () => {
      revealElements.forEach(el => observer.unobserve(el));
    };
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="overflow-hidden">
        <Hero />
        <section id="products">
          <ProductShowcase />
        </section>
        <section id="why-us">
          <WhyChooseUs />
        </section>
        <section id="how-it-works">
          <HowItWorks />
        </section>
        <section id="cooperatives" className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-serif font-semibold text-center mb-12">Nos Coopératives</h2>
            <AboutCooperatives />
            <FeaturedCooperatives cooperatives={processedCooperatives.filter(coop => coop.featured)} />
            <AllCooperatives cooperatives={processedCooperatives} />
          </div>
        </section>
        <section id="register-cooperative">
          <AngaraPromotion />
        </section>
        <section id="contact">
          <ContactSection />
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Index;
