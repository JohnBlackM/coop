import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Coffee, Lock } from 'lucide-react';

export default function Login() {
  const { t } = useTranslation();
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  
  // Récupérer l'URL de redirection depuis l'état de navigation ou utiliser l'admin par défaut
  const from = location.state?.from?.pathname || '/admin';
  
  // Si l'utilisateur est déjà connecté, le rediriger vers sa destination
  useEffect(() => {
    if (isAuthenticated) {
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, from]);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const success = await login(email, password);
      
      if (success) {
        toast({
          title: t('login.success', 'Connexion réussie'),
          description: t('login.redirecting', 'Vous êtes maintenant connecté'),
        });
        navigate(from, { replace: true });
      } else {
        setError(t('login.invalidCredentials', 'Email ou mot de passe incorrect'));
        toast({
          variant: 'destructive',
          title: t('login.failed', 'Échec de la connexion'),
          description: t('login.invalidCredentials', 'Email ou mot de passe incorrect'),
        });
      }
    } catch (err) {
      setError(t('login.error', 'Une erreur est survenue lors de la connexion'));
      toast({
        variant: 'destructive',
        title: t('login.error', 'Erreur'),
        description: t('login.systemError', 'Une erreur système est survenue'),
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container flex items-center justify-center min-h-screen py-10 px-4 md:px-6">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex justify-center mb-4">
            <div className="rounded-full bg-primary/10 p-4">
              <Lock className="h-10 w-10 text-primary" />
            </div>
          </div>
          <CardTitle className="text-2xl text-center">{t('login.title', 'Connexion Admin')}</CardTitle>
          <CardDescription className="text-center">
            {t('login.instructions', 'Connectez-vous pour accéder à l\'administration')}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">{t('login.email', 'Email')}</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@example.com"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">{t('login.password', 'Mot de passe')}</Label>
              </div>
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            
            {error && (
              <div className="p-3 rounded-md bg-destructive/10 text-destructive text-sm">
                {error}
              </div>
            )}
            
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? t('login.loggingIn', 'Connexion en cours...') : t('login.login', 'Se connecter')}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="flex flex-col space-y-4">
          <div className="text-sm text-muted-foreground text-center">
            <p>{t('login.demoCredentials', 'Identifiants de démonstration:')}</p>
            <p>Email: admin@example.com</p>
            <p>{t('login.password', 'Mot de passe')}: password123</p>
          </div>
          <Button variant="outline" className="w-full" onClick={() => navigate('/')}>
            <Coffee className="mr-2 h-4 w-4" />
            {t('login.backToSite', 'Retour au site')}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
