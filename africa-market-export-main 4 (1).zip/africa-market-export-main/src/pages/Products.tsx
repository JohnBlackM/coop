
import { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { useTranslation } from 'react-i18next';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import ProductShowcase from '@/components/ProductShowcase';
import { ChevronDown } from 'lucide-react';

const Products = () => {
  const { t } = useTranslation();
  const [showScrollIndicator, setShowScrollIndicator] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setShowScrollIndicator(false);
      } else {
        setShowScrollIndicator(true);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <>
      <Helmet>
        <title>{t('products.pageTitle', 'Our Products')}</title>
        <meta name="description" content={t('products.metaDescription', 'Discover our range of high-quality products from African cooperatives.')} />
      </Helmet>
      
      <div className="flex flex-col min-h-screen">
        <Navbar />
        
        <main className="flex-grow">
          <section className="bg-gradient-to-b from-forest-900 to-forest-800 text-white py-24">
            <div className="container mx-auto px-4 text-center">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 animate-fade-up">
                {t('products.heroTitle', 'Our Products')}
              </h1>
              <p className="text-xl md:text-2xl max-w-3xl mx-auto animate-fade-up" style={{ animationDelay: '0.2s' }}>
                {t('products.heroDescription', 'Discover exceptional products directly sourced from African cooperatives')}
              </p>
              
              {showScrollIndicator && (
                <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
                  <ChevronDown className="h-8 w-8 text-white opacity-70" />
                </div>
              )}
            </div>
          </section>
          
          <ProductShowcase />
        </main>
        
        <Footer />
      </div>
    </>
  );
};

export default Products;
