
// Type definitions for cooperatives

export interface MediaItem {
  id: string;
  url: string;
  caption: string;
  category: 'plantation' | 'work' | 'product';
}

export interface CooperativeMedia {
  photos: MediaItem[];
  videos: MediaItem[];
}

export interface Testimonial {
  id: string;
  personName: string;
  role: string;
  content: string;
  date: string;
}

export interface SuccessStory {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  date: string;
  impact?: string;
}

export type PublicationStatus = 'draft' | 'pending' | 'published' | 'rejected';

export interface Cooperative {
  id: number;
  name: string;
  country: string;
  region: string;
  yearFounded: number;
  members: number;
  hectares: number;
  certifications: string[];
  varieties: string[];
  description: string;
  mainImage: string;
  gallery: string[];
  media: CooperativeMedia;
  story: string;
  featured: boolean;
  videoUrl?: string;
  testimonials?: Testimonial[];
  successStories?: SuccessStory[];
  status: PublicationStatus; // Changed from optional to required with specific type
  contactInfo?: string;
  createdAt?: string;
}
