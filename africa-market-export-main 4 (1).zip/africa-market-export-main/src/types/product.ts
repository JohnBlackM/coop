
// Type definitions for products

export interface Product {
  id: string;
  name: string;
  category: 'cocoa' | 'coffee';
  description: string;
  imageUrl: string;
  featured: boolean;
  status: 'draft' | 'published';
  createdAt: string;
  deleteImage?: boolean; // Optional flag to track image deletion
  price?: number;        // Optional price field
  origin?: string;       // Optional origin country
}

// Helper function to validate and sanitize the status field
export function validateProductStatus(status: string): 'draft' | 'published' {
  return status === 'published' ? 'published' : 'draft';
}

// Helper function to ensure a product conforms to the Product type
export function validateProduct(product: any): Product {
  return {
    id: product.id || `prod_${Date.now()}`,
    name: product.name || '',
    category: product.category === 'coffee' ? 'coffee' : 'cocoa',
    description: product.description || '',
    imageUrl: product.imageUrl || '',
    featured: Boolean(product.featured),
    status: validateProductStatus(product.status),
    createdAt: product.createdAt || new Date().toISOString(),
    deleteImage: product.deleteImage,
    price: product.price,
    origin: product.origin
  };
}
