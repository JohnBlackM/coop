
export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      products: {
        Row: {
          id: string
          name: string
          category: 'cocoa' | 'coffee'
          description: string
          imageUrl: string
          featured: boolean
          status: 'draft' | 'published'
          createdAt: string
          price?: number
          origin?: string
        }
        Insert: {
          id?: string
          name: string
          category: 'cocoa' | 'coffee'
          description: string
          imageUrl?: string
          featured?: boolean
          status?: 'draft' | 'published'
          createdAt?: string
          price?: number
          origin?: string
        }
        Update: {
          id?: string
          name?: string
          category?: 'cocoa' | 'coffee'
          description?: string
          imageUrl?: string
          featured?: boolean
          status?: 'draft' | 'published'
          createdAt?: string
          price?: number
          origin?: string
        }
      }
      cooperatives: {
        Row: {
          id: number
          name: string
          country: string
          region: string
          yearFounded: number
          members: number
          hectares: number
          certifications: string[]
          varieties: string[]
          description: string
          mainImage: string
          gallery: string[]
          story: string
          featured: boolean
          status: 'draft' | 'pending' | 'published' | 'rejected'
          contactInfo?: string
          createdAt: string
          media: {
            photos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
            videos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
          }
          videoUrl?: string
          testimonials?: {
            id: string
            personName: string
            role: string
            content: string
            date: string
          }[]
          successStories?: {
            id: string
            title: string
            description: string
            imageUrl?: string
            date: string
            impact?: string
          }[]
        }
        Insert: {
          id?: number
          name: string
          country: string
          region: string
          yearFounded: number
          members: number
          hectares: number
          certifications: string[]
          varieties: string[]
          description: string
          mainImage: string
          gallery: string[]
          story: string
          featured?: boolean
          status?: 'draft' | 'pending' | 'published' | 'rejected'
          contactInfo?: string
          createdAt?: string
          media?: {
            photos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
            videos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
          }
          videoUrl?: string
          testimonials?: {
            id: string
            personName: string
            role: string
            content: string
            date: string
          }[]
          successStories?: {
            id: string
            title: string
            description: string
            imageUrl?: string
            date: string
            impact?: string
          }[]
        }
        Update: {
          id?: number
          name?: string
          country?: string
          region?: string
          yearFounded?: number
          members?: number
          hectares?: number
          certifications?: string[]
          varieties?: string[]
          description?: string
          mainImage?: string
          gallery?: string[]
          story?: string
          featured?: boolean
          status?: 'draft' | 'pending' | 'published' | 'rejected'
          contactInfo?: string
          createdAt?: string
          media?: {
            photos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
            videos: {
              id: string
              url: string
              caption: string
              category: 'plantation' | 'work' | 'product'
            }[]
          }
          videoUrl?: string
          testimonials?: {
            id: string
            personName: string
            role: string
            content: string
            date: string
          }[]
          successStories?: {
            id: string
            title: string
            description: string
            imageUrl?: string
            date: string
            impact?: string
          }[]
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
